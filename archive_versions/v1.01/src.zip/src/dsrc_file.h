/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/

#ifndef _DSRC_FILE_H
#define _DSRC_FILE_H

#include "defs.h"
#include "fastq.h"
#include "lz.h"
#include "superblock.h"
#include <vector>
#include <string>

// ********************************************************************************************
//
// ********************************************************************************************
class DsrcFile 
{
public:
	static const uint32 MIN_LZ_MEMORY_SIZE_MB		= 1 << 6;
	static const uint32 DEFAULT_LZ_MEMORY_SIZE_MB	= 1 << 10;
	static const uint32 MAX_LZ_MEMORY_SIZE_MB		= 1 << 16;

	static const uint32 MIN_LZ_COMPRESSION_LEVEL	= LZ_LEVEL_1;
	static const uint32 DEFAULT_LZ_COMPRESSION_LEVEL= LzMatcher::DEFAULT_COMPRESSION_LEVEL;
	static const uint32 MAX_LZ_COMPRESSION_LEVEL	= LZ_LEVEL_3;
	static const uint32 LZ_LEVEL_SEQ_LENGTH[];

	static const uint32 MIN_SB_SIZE					= 512;
	static const uint32 DEFAULT_SB_SIZE				= Superblock::DEFAULT_SIZE;
	static const uint32 MAX_SB_SIZE					= 1 << 30;

	static const uint32 MIN_BLOCK_SIZE				= 4;
	static const uint32 DEFAULT_BLOCK_SIZE			= Block::DEFAULT_SIZE;
	static const uint32 MAX_BLOCK_SIZE				= 1 << 17;

	DsrcFile();
	~DsrcFile();

	bool StartCompress(const char* out_filename);
	bool WriteRecord(const FastqRecord &rec);
	bool FinishCompress();

	bool StartDecompress(const char* file_name);
	bool ReadNextRecord(FastqRecord &rec);
	bool FinishDecompress();

	bool StartExtract(const char* file_name);
	bool ExtractRecord(FastqRecord &rec, uint64 rec_id);
	bool FinishExtract();

	void Reset(bool resetSb = true);

	int64 GetFilePos() const { return bit_stream.GetPos(); }
	int64 GetFileSize() const { return bit_stream.GetSize(); }

	bool IsLzMatching() const { return try_lz; }
	bool SetLzMatching(bool lz);

	uint32 GetLzMemorySize() const { return lz_max_memory_size; }
	bool SetLzMemorySize(uint32 lz_mem);

#if !(FEATURE_DISABLED_IN_V_100)
	uint32 GetLzCompressionLevel() const { return lz_compression_level; }
	bool SetLzCompressionLevel(uint32 level);
	bool SetSuperblockSize(uint32 sb_size);
	bool SetBlockSize(uint32 block_size);
#endif

	uint32 GetSuperblockSize() const { return sb_size; }
	uint32 GetBlockSize() const { return block_size; }

	bool IsFileProcessing() const { return opened; }
	bool IsOpened() const { return opened; }

	bool IsError() const { return is_error; }
	const std::string GetError() const { return error_msg; }

	void ClearError()
	{
		error_msg.clear();
		is_error = false;
	}

	static std::string GetVersionString()
	{
		static std::string version("v-1_000");
		return version;
	}

protected:
	void SetError(const char* msg)
	{
		error_msg += msg;
		is_error = true;
	}

private:
	static const uint32 ENDING_HEADER_OFFSET		= 25;

#if (RESERVE_BYTES_PER_DSRCFILE)
	static const uint32 HEADER_RESERVED_BYTES		= 32;
#endif

	BitStream bit_stream;
	LzMatcher lz_matcher;

	bool opened;
	FileModeEnum file_mode;

	Superblock* superblock;
	Superblock* superblock_lz;		// superblock only for extracting LZ-matches of single records
	uint64 rec_count;
	uint64 sb_count;
	uint32 sb_size;
	uint32 block_size;
	uint64 ext_cur_sb_id;

	bool try_lz;
	uint32 lz_max_memory_size;
	uint32 lz_compression_level;
	bool is_error;
	std::string error_msg;

	uint64 header_pos;
	uint64 header_sb_count;
	uint64 header_b_count;
	uint32 block_offset_bit_len;
	std::vector<uint64> sb_file_pos;
	std::vector<uint32> block_file_pos;

	bool ExtractLzRecord(FastqRecord &rec, uint64 rec_id);
};

#endif
