/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/
#ifndef _PY_DSRC_FILE_H
#define _PY_DSRC_FILE_H

#include "py_base.h"
#include "py_fastq.h"
#include "dsrc_file.h"

namespace pydsrc
{

// ********************************************************************************************
//
// ********************************************************************************************
class PyDsrcFile	// pure C++ to Python wrapper
{
public:
	PyDsrcFile() {}
	~PyDsrcFile() {}

	void StartCompress(const char* out_filename)
	{ 
		TryExecute(dsrc.StartCompress(out_filename)); 
	}
	void FinishCompress()
	{ 
		TryExecute(dsrc.FinishCompress()); 
	}
	void WriteRecord(const PyFastqRecord &rec)
	{
		FastqRecord fq_rec;
		rec.Export(fq_rec);
		TryExecute(dsrc.WriteRecord(fq_rec));
	}

	void StartDecompress(const char* file_name)
	{
		TryExecute(dsrc.StartDecompress(file_name)); 
	}
	bool ReadNextRecord(PyFastqRecord &rec)
	{
		FastqRecord fq_rec;
		if (!dsrc.ReadNextRecord(fq_rec))
			return false;
		if (dsrc.IsError())
		{
			PyException ex(dsrc.GetError());
			dsrc.ClearError();
			throw ex;
		}
		rec.Import(fq_rec);
		return true;
	}
	void FinishDecompress()
	{
		TryExecute(dsrc.FinishDecompress()); 
	}

	void StartExtract(const char* file_name)
	{
		TryExecute(dsrc.StartExtract(file_name)); 
	}
	void ExtractRecord(PyFastqRecord &rec, uint64 rec_id)
	{
		FastqRecord fq_rec;
		TryExecute(dsrc.ExtractRecord(fq_rec, rec_id));
		rec.Import(fq_rec);
	}
	//void ExtractSuperblock(boost::python::list &sb_rec, uint64 sb_id);
	void FinishExtract() 
	{ 
		TryExecute(dsrc.FinishExtract()); 
	}

	void Reset() 
	{ 
		dsrc.Reset(); 
	}

	//bool Eof() const { return dsrc.Eof(); }
	int64 GetFilePos() const 
	{
		return dsrc.GetFilePos(); 
	}
	int64 GetFileSize() const 
	{
		return dsrc.GetFileSize(); 
	}

	void SetLzMatching(bool use_lz) 
	{
		TryExecute(dsrc.SetLzMatching(use_lz)); 
	}
	bool IsLzMatching() const 
	{
		return dsrc.IsLzMatching(); 
	}
	void SetLzMemorySize(uint32 lz_mem) 
	{
		TryExecute(dsrc.SetLzMemorySize(lz_mem)); 
	}
	uint32 GetLzMemorySize() const 
	{
		return dsrc.GetLzMemorySize(); 
	}

#if !(FEATURE_DISABLED_IN_V_100)
	void SetLzCompressionLevel(LzCompressionLevel lz_lvl) 
	{ 
		TryExecute(dsrc.SetLzCompressionLevel((uint32)lz_lvl)); 
	}
	LzCompressionLevel GetLzCompressionLevel() const 
	{
		return (LzCompressionLevel)dsrc.GetLzCompressionLevel(); 
	}
	void SetSuperblockSize(uint32 sb_size) 
	{
		TryExecute(dsrc.SetSuperblockSize(sb_size)); 
	}
	void SetBlockSize(uint32 block_size) 
	{
		TryExecute(dsrc.SetBlockSize(block_size)); 
	}
#endif

	uint32 GetSuperblockSize() const 
	{
		return dsrc.GetSuperblockSize(); 
	}
	uint32 GetBlockSize() const 
	{
		return dsrc.GetBlockSize(); 
	}

private:
	DsrcFile dsrc;

	void TryExecute(bool val)
	{
		if (!val || dsrc.IsError())
		{
			// conditional error check
			PyException ex(dsrc.GetError());
			dsrc.ClearError();
			throw ex;
		}
	}
};

} // namespace pydsrc

#endif
