/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/

#include "main.h"
#include <vector>
#include <iostream>
#include <string>
#include <string.h>
#include <stdio.h>

int taskId;
Param additional_param;
Compressor* dsrc = NULL;

const std::string programVersion = "1.01";
const std::string buildDate = "06.05.2012";

// ********************************************************************************************
void usage()
{
	using std::cout;

	cout << "*** DNA Sequence Reads Compressor ***\n";
	cout << "*    version: " + programVersion + " @ " + buildDate + "     *\n";
	cout << "\n";
	cout << "Usage:\n";
	cout << "  dsrc <mode> [options] <input_file_name> <output_file_name>\n";
	cout << "\n";
	cout << "Modes:\n";
	cout << "  c - compression\n";
	cout << "  d - decompression\n";
	cout << "  e - extraction\n";
	cout << "\n";
	cout << "Compression options:\n";
	cout << "  -c     - perform CRC32 check (about twice slower compression)\n";
	cout << "  -l     - try LZ matches (about twice slower compression, but a bit stronger)\n";
	cout << "  -lm<n> - use at most <n> MB for finding LZ matches\n";
	cout << "           (default: " << DsrcFile::DEFAULT_LZ_MEMORY_SIZE_MB << ", min: "
		<< DsrcFile::MIN_LZ_MEMORY_SIZE_MB << ", max: " << DsrcFile::MAX_LZ_MEMORY_SIZE_MB << ")\n";
	cout << "           about the same amount of memory will be necessary to decompress the file\n";
	cout << "           <n> must be power of 2\n";
#if !(FEATURE_DISABLED_IN_V_100)
	cout << "  -lv<n> - use Lz <n> compression level indicating minimum length of DNA sequence required for Lz inserting\n";
	cout << "           (default: " << DsrcFile::DEFAULT_LZ_COMPRESSION_LEVEL << " (" << DsrcFile::LZ_LEVEL_SEQ_LENGTH[DsrcFile::DEFAULT_LZ_COMPRESSION_LEVEL] << ")"
		<< ", min: " << DsrcFile::MIN_LZ_COMPRESSION_LEVEL << " (" << DsrcFile::LZ_LEVEL_SEQ_LENGTH[DsrcFile::MIN_LZ_COMPRESSION_LEVEL] << ")"
		<< ", max: " << DsrcFile::MAX_LZ_COMPRESSION_LEVEL << " (" << DsrcFile::LZ_LEVEL_SEQ_LENGTH[DsrcFile::MAX_LZ_COMPRESSION_LEVEL] << ")" << ")\n";
	cout << "  -sn<n> - extract only records from superblock number n\n";
	cout << "  -ss<n> - store <n> records per superblock for compression\n";
	cout << "           (default: " << Compressor::DEFAULT_SB_SIZE << ", min: " 
		<< Compressor::MIN_SB_SIZE << ", max: " << Compressor::MAX_SB_SIZE << ")\n";
	cout << "           <n> must be power of 2\n";
	cout << "  -bs<n> - store <n> records per block for compression\n";
	cout << "           (default: " << Compressor::DEFAULT_BLOCK_SIZE << ", min: "
		<< Compressor::MIN_BLOCK_SIZE << ", max: " << Compressor::MAX_BLOCK_SIZE << ")\n";
	cout << "           <n> must be power of 2\n";
#endif
	cout << "\n";
	cout << "Extraction options:\n";
	cout << "  -rn<n> - extract only record number n\n";
	cout << "\n";
	cout << "Examples:\n";
	cout << "  dsrc c -c SRR001471.fastq SRR001471.dsrc\n";
	cout << "  dsrc c -l -lm2048 SRR001471.fastq SRR001471.dsrc\n";
	//cout << "  dsrc e -ss1024 SRR001471.fastq SRR001471.dsrc\n";
	cout << "  dsrc d SRR001471.dsrc SRR001471.out\n";
	cout << "  dsrc e -r532 SRR001471.dsrc SRR001471.out\n";
	//cout << "  dsrc d -sn4 SRR001471.dsrc SRR001471.out\n";
}


bool parse_params(int argc, char* argv[])
{
	if (dsrc == NULL)
		return false;

	taskId = -1;
	memset(&additional_param, 0, sizeof(Param));

	if (strcmp(argv[1], "c") == 0)
		taskId = TASK_COMPRESS;
	else if (strcmp(argv[1], "d") == 0)
		taskId = TASK_DECOMPRESS;
	else if (strcmp(argv[1], "e") == 0)
		taskId = TASK_EXTRACT;
	else
		return false;

	for (int32 i = 2; i < argc-2; ++i)
	{
		if (strcmp(argv[i], "-c") == 0)
		{
			if (!dsrc->SetCrc32Checking(true))
				return false;
			continue;
		}
		if (strncmp(argv[i], "-lm", 3) == 0)
		{
			if (!dsrc->SetLzMemorySize(atoi(argv[i]+3)))
				return false;
			continue;
		}
		if (strcmp(argv[i], "-l") == 0)
		{
			if (!dsrc->SetLzMatching(true))
				return false;
			continue;
		}
#if !(FEATURE_DISABLED_IN_V_100)
		if (strncmp(argv[i], "-lv", 3) == 0)
		{
			if (!dsrc->SetLzCompressionLevel(atoi(argv[i]+3)))
				return false;
			continue;
		}
		if (strncmp(argv[i], "-ss", 3) == 0)
		{
			if (!dsrc->SetSuperblockSize(atoi(argv[i]+3)))
				return false;
			continue;
		}
		if (strncmp(argv[i], "-bs", 3) == 0)
		{
			if (!dsrc->SetBlockSize(atoi(argv[i]+3)))
				return false;
			continue;
		}
		if (strncmp(argv[i], "-sn", 3) == 0)
		{
			sscanf(argv[i]+3, "%llu", &additional_param.par64)
				continue;
		}
#endif
		if (strncmp(argv[i], "-rn", 3) == 0)
		{
			sscanf(argv[i]+3, "%llu", &additional_param.par64);
			continue;
		}
	}

	return true;
}

bool run_dsrc(int argc, char* argv[])
{
	if (dsrc == NULL)
		return false;

	switch (taskId)
	{
		case TASK_COMPRESS:		return dsrc->Compress(argv[argc-2], argv[argc-1]);
		case TASK_DECOMPRESS:	return dsrc->Decompress(argv[argc-2], argv[argc-1]);
		case TASK_EXTRACT:		return dsrc->ExtractRecord(argv[argc-2], argv[argc-1], additional_param.par64);
	}

	return false;
}

// ********************************************************************************************
//
// ********************************************************************************************
int main(int argc, char* argv[])
{
	if (argc < 4 || strcmp(argv[argc-1], argv[argc-2]) == 0)
	{
		usage();
		return 0;
	}

	dsrc = new Compressor();

	if (!parse_params(argc, argv))
	{
		usage();
	}
	else
	{
		run_dsrc(argc, argv);
	}

	delete dsrc;
	return 0;
}
