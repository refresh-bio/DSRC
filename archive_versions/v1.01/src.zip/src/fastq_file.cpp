/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/
#include "defs.h"
#include "fastq_file.h"
#include <stdio.h>

// ********************************************************************************************
FastqFile::FastqFile() 
	:	file_crc()
	,	records_crc()
	,	check_crc32(false)
	,	file(NULL)
	,	file_pos(0)
	,	file_size(0)
	,	io_buffer(new uchar[IO_BUFFER_SIZE])
	,	io_buffer_pos(-1)
	,	io_buffer_size(0)
	,	file_mode(FILE_MODE_NONE)
	,	io_eof(false)
{

};

// ********************************************************************************************
FastqFile::~FastqFile() 
{
	delete[] io_buffer;
	if (file)
	{
		fclose(file);
	}
}

// ********************************************************************************************
bool FastqFile::ReadBuffer()
{
	io_buffer_size = (uint32) fread(io_buffer, 1, IO_BUFFER_SIZE, file);
	if (io_buffer_size == 0)
	{
		io_eof = true;
		return 0;
	}
	io_buffer_pos = 0;
	return 1;
}

// ********************************************************************************************
bool FastqFile::WriteBuffer()
{
	if ((int32)fwrite(io_buffer, 1, IO_BUFFER_SIZE, file) != IO_BUFFER_SIZE)
		return false;
	io_buffer_pos = 0;
	return true;
}

// ********************************************************************************************
bool FastqFile::Open(const char *file_name)
{
	if ((file = my_fopen(file_name, "rb")) != NULL)
		file_mode = FILE_MODE_READ;

	if (file_mode != FILE_MODE_READ)
		return false;

	if (check_crc32)
	{
		file_crc.Reset();
		records_crc.Reset();
	}

	my_fseek(file, 0, SEEK_END);
	file_size = my_ftell(file);
	my_fseek(file, 0, SEEK_SET);

	io_buffer_pos = -1;
	io_buffer_size = 0;
	io_eof = false;
	file_pos = 0;

	return true;
}

// ********************************************************************************************
bool FastqFile::Create(const char *file_name)
{
	if ((file = my_fopen(file_name, "wb")) != NULL)
		file_mode = FILE_MODE_WRITE;

	if (check_crc32)
	{
		file_crc.Reset();
		records_crc.Reset();
	}

	io_buffer_pos = 0;
	io_buffer_size = 0;
	file_pos = 0;
	file_size = 0;
	io_eof = false;
	return file_mode == FILE_MODE_WRITE;
}

// ********************************************************************************************
bool FastqFile::Close()
{
	if (!file)
		return false;

	if (file_mode == FILE_MODE_WRITE && io_buffer_pos > 0)
	{
		fwrite(io_buffer, 1, io_buffer_pos, file);
		file_size = file_pos;
	}
	fclose(file);
	file = NULL;

	return true;
}

// ********************************************************************************************
bool FastqFile::ReadTitle(FastqRecord &rec)
{
	uint32 i = 0;
	for (;;)
	{
		int32 c = Getc();
		if (c == FILE_EOF)
			break;

		if (c != '\n' && c != '\r')
		{
			if (i >= rec.title_size)
			{
				rec.Extend(rec.title, rec.title_size);
			}
 			rec.title[i++] = (uchar) c;
		}
		else if (i > 0)
		{
			break;
		}
	}
	rec.title[i] = 0;
	rec.title_len = i;
	return i > 0 && rec.title[0] == '@';
}

// ********************************************************************************************
bool FastqFile::Readsequence(FastqRecord &rec)
{
	uint32 i = 0;
	int32 c;

	if (rec.sequence_breaks)
	{
		delete rec.sequence_breaks;
		rec.sequence_breaks = NULL;
	}
	uint32 last_eol_pos = 0;
	uint32 sequence_break = 0;

	for (;;)
	{
		c = Peek();

		if (c == '+')
			break;

		Getc();
		if (c == FILE_EOF)
			break;

		if (c != '\n' && c != '\r')
		{
			if (i >= rec.sequence_size)
			{
				rec.Extend(rec.sequence, rec.sequence_size);
			}
			rec.sequence[i++] = (uchar) c;
		}
		else
		{
			if (last_eol_pos != i)
			{
				if (sequence_break)
				{
					if (!rec.sequence_breaks)
					{
						rec.sequence_breaks = new std::vector<int>;
					}
					rec.sequence_breaks->push_back(sequence_break);
				}
				else
				{
					sequence_break = i - last_eol_pos;
				}
				last_eol_pos = i;
			}
		}
	}
	rec.sequence[i] = 0;
	rec.sequence_len = i;
	return true;
}

// ********************************************************************************************
// Todo: Verify (plus == title)
bool FastqFile::ReadPlus(FastqRecord &rec)
{
	uint32 i = 0;
	int32 c;
	for (;;)
	{
		c = Getc();
		if (c == FILE_EOF)
			break;

		if (c != '\n' && c != '\r')
		{
			if (i >= rec.plus_size)
			{
				rec.Extend(rec.plus, rec.plus_size);
			}
			rec.plus[i++] = (uchar) c;
		}
		else if (i > 0)
		{
			break;
		}
	}
	rec.plus[i] = 0;
	rec.plus_len = i;
	return i > 0;
}

// ********************************************************************************************
bool FastqFile::ReadQuality(FastqRecord &rec)
{
	uint32 i;
	uint32 last_eol_pos = 0;

	if (rec.quality_breaks)
	{
		delete rec.quality_breaks;
		rec.quality_breaks = NULL;
	}

	if (rec.sequence_size > rec.quality_size)
		rec.ExtendTo(rec.quality, rec.quality_size, rec.sequence_size);

	for (i = 0; i < rec.sequence_len;)
	{
		int32 c = Getc();
		if (c == FILE_EOF)
			break;

		if (c != '\n' && c != '\r')
		{
			rec.quality[i++] = (uchar)c;
		}
		else
		{
			if (last_eol_pos != i)
			{
				if (!rec.quality_breaks)
				{
					rec.quality_breaks = new std::vector<int>;
				}
				rec.quality_breaks->push_back(i - last_eol_pos);
				last_eol_pos = i;
			}
		}
	}
	Getc();	// get the newline

	rec.quality[i] = 0;
	rec.quality_len = i;
	return (i == rec.sequence_len);
}
