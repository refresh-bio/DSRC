/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/
#ifndef _PY_FASTQ_FILE_H
#define _PY_FASTQ_FILE_H

#include "py_base.h"
#include "py_fastq.h"
#include "fastq_file.h"

namespace pydsrc
{

// ********************************************************************************************
//
// ********************************************************************************************
class PyFastqFile : public FastqFile
{
public:
	PyFastqFile() {}
	~PyFastqFile() {}

	bool ReadNextRecord(PyFastqRecord &rec);
	bool WriteRecord(PyFastqRecord &rec);

private:
	bool ReadTitle(PyFastqRecord &rec);
	bool ReadPlus(PyFastqRecord &rec);
	bool Readsequence(PyFastqRecord &rec);
	bool ReadQuality(PyFastqRecord &rec);

	bool Puts(const std::vector<uchar>& str, bool eol = true)
	{
		return FastqFile::Puts(&str[0], str.size(), eol);
	}

	bool Puts(const std::vector<uchar>& str, const std::vector<int32>& line_breaks)
	{
		return FastqFile::Puts(&str[0], str.size(), &line_breaks);
	}
};

} // pydsrc

#endif
