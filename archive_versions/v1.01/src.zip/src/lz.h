/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/

#ifndef _LZ_H
#define _LZ_H

#include "defs.h"
#include <vector>

#define USE_MODIFIED_HASHING_COMPRESS	1
#define USE_MODIFIED_HASHING_DECOMPRESS 1

// ********************************************************************************************
//
// ********************************************************************************************
struct LzMatch 
{
	uint32 rec_no;
	uint32 rec_offset;
	uint32 length;
};

// ********************************************************************************************
class LzMatcher 
{
public:
	LzMatcher();
	~LzMatcher();

	static const uint32 DEFAULT_COMPRESSION_LEVEL = 2;
	static const uint32 LEVEL_SEQ_LENGTH[];

	//static const uint64 DEFAULT_MAX_LZ_MEMORY_SIZE	= 1ull << 62;
	static const uint64 DEFAULT_MAX_LZ_MEMORY_SIZE = (1ull << 32) * 32;

	static const double LOG_PROB_THR;

	void Reset();

	uint64 GetMaxMemory() const { return max_lz_memory_size; };
	void SetMaxMemory(uint64 mem) { max_lz_memory_size = mem; }

	void SetCompressionLevel(uint32 level);
	uint32 GetCompressionLevel() const {return compression_level;}

	uint32 GetMinMatchLen() const {return min_match_len; }

	bool InsertEncoding(uint64 rec_no, uchar *sequence, uint32 sequence_len, uchar *quality, uint32 quality_len);
	bool FindMatch(uchar *sequence, uint32 sequence_len, uchar *quality, uint32 quality_len, 
		uint32 &rec_no, uint32 &rec_offset, uint32 &match_len);

	bool InsertDecoding(uint64 rec_no, uchar *sequence, uint32 sequence_len, uchar *quality, uint32 quality_len);
	bool DecodeMatch(uchar *sequence, uint32 rec_no, uint32 rec_offset, uint32 match_len, 
		uint32 sequence_len);

private:
	struct HashTable
	{
		static const uint32 INITIAL_SIZE = 2;
		static const double DEFAULT_MAX_FILL_FACTOR;

		struct Entry
		{
			uint64 buffer_pos;
			uint32 rec_no;
			uint32 rec_offset;
		};
		Entry* data;

		uint32 size;
		uint32 size_mask;
		uint32 elems;
		uint32 max_elems;
		uint64 memory_size;
		double max_fill_factor;

		HashTable()
		:	data(0),
			size(0),
			size_mask(0),
			elems(0),
			max_elems(0),
			memory_size(0),
			max_fill_factor(0)
		{}

		~HashTable()
		{
			if (data)
				delete[] data;
		}
	};

	HashTable hash_table;
	uint32 hash_value;
	std::vector<uchar*> buffer;
	uint64 buf_memory_size;
	int32 cur_part;
	uint32 part_pos;
	bool frozen;
	uint32 min_factor;

	uint64 max_lz_memory_size;

	uint32 min_match_len;
	uint32 search_step_size;
	uint32 part_size_exp;
	uint32 part_size;
	uint32 part_size_mask;
	uint32 max_col_entry;
	uint32 compression_level;

	double log_phred[256];

	// no copy ctor
	LzMatcher(const LzMatcher& ) {}

	void Initialize();
	void PreparePhred();

	void PrepareNextPart();
	void ResizeHT_Encode();
	bool InsertHT_Encode(uchar *str, uint64 buffer_pos, uint64 rec_no, uint32 rec_offset, 
		bool force_insert = false);

	void ResizeHT_Decode();
	void InsertHT_Decode(uint64 buffer_pos, uint32 rec_no);

	inline uint32 Hash1(uchar *str);
	inline uint32 Hash1_fast(uchar *str);
	inline uint32 Hash2(uchar *str);
	inline uint32 HashI(uint32 h);
};


// ********************************************************************************************
uint32 LzMatcher::Hash1(uchar *str)
{
	// Bernstein
	hash_value = 0;
	for (uint32 i = 0; i < min_match_len; ++i)
	{
		hash_value = (hash_value << 5) + hash_value + str[i];
	}

	return hash_value & hash_table.size_mask;
}

// ********************************************************************************************
// Berstein hash for 1-byte shift of window (faster than Hash1)
uint32 LzMatcher::Hash1_fast(uchar *str)
{
	// Bernstein
	hash_value -= str[-1] * min_factor;
	hash_value = (hash_value << 5) + hash_value + str[min_match_len-1];

	return hash_value & hash_table.size_mask;
}

// ********************************************************************************************
uint32 LzMatcher::Hash2(uchar* /*str*/)
{
	return 1;
}

// ********************************************************************************************
// Robert Jenkins' 32-bit uint hash function 
uint32 LzMatcher::HashI(uint32 h)
{
	h = (h+0x7ed55d16) + (h<<12);
	h = (h^0xc761c23c) ^ (h>>19);
	h = (h+0x165667b1) + (h<<5);
	h = (h+0xd3a2646c) ^ (h<<9);
	h = (h+0xfd7046c5) + (h<<3);
	h = (h^0xb55a4f09) ^ (h>>16);
	return h;
}

#endif
