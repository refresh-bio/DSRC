/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/

#ifndef _BLOCK_H
#define _BLOCK_H

#include "bit_stream.h"
#include "fastq.h"
#include "huffman.h"
#include "field.h"
#include "lz.h"

#if (D_COMPUTE_RECORDS_CRC_PER_BLOCK)
#	include "crc.h"
#endif

#include <set>
#include <vector>

// ********************************************************************************************
//
// ********************************************************************************************
class Block 
{
public:
	static const uint32 DEFAULT_SIZE = 32;

	inline Block(uint32 block_size, uint64 _b_start_rec_no, uint32 _rec_count = 0);
	inline ~Block();

	inline void InsertRecord(const FastqRecord &rec, uint32& max_seq_len, uint32& min_seq_len,
		uint32& max_qua_len, uint32& min_qua_len, std::vector<uint32> &dna_occ, uint32 &fastq_flags, 
		std::vector<uint32> &quality_occ);

	inline void Reset(uint64 _b_start_rec_no, uint32 _rec_count = 0);

	void Process(BitStream &bit_stream, LzMatcher &lz_matcher, std::vector<Field> &fields, 
		uint32 n_field, uint32 _fastq_flags, uchar *sym_code, HuffmanEncoder::Code *sym_huf_codes, 
		uchar *qua_code, HuffmanEncoder::Code **qua_huf_codes, uint32 max_run_len, 
		HuffmanEncoder::Code **run_huf_codes, uint32 n_qualities, uint32 global_sequence_len,
		uint32 max_quality_length, uint32 block_no, uint32 _quality_stats_mode);

	void Read(BitStream &bit_stream, LzMatcher &lz_matcher, std::vector<Field> &fields, uint32 n_field,
		uint32 fastq_flags, std::vector<uchar> &symbols, HuffmanEncoder *Huffman_sym,
		std::vector<uchar> &qualities, std::vector<HuffmanEncoder*> &Huffman_qua, 
		uint32 max_run_len, std::vector<HuffmanEncoder*> &Huffman_run, uint32 n_qualities, 
		uint32 _global_max_sequence_length, uint32 max_quality_length, 
		uint32 block_no, uint32 quality_stats_mode, bool extracting = false);

	void MakeRLE();
	void MakeUnRLE();

	inline void Resize(uint32 new_size);

	uint32 GetRecordCount() const
	{ 
		return rec_count;	// not always rec_count == records.size()
	}
	std::vector<FastqRecord>& GetRawRecords()
	{ 
		return records; 
	}
	FastqRecord& GetRawRecord(int32 rec_id)
	{ 
		return records[rec_id]; 
	}
	FastqRecord& GetLastRecord()
	{ 
		my_assert(rec_count > 0);
		return records[rec_count - 1]; 
	}
	std::vector<LzMatch>& GetLzMatches() 
	{
		return lz_matches; 
	}
	LzMatch& GetLzMatch(int32 rec_id) 
	{
		return lz_matches[rec_id]; 
	}
	uchar* GetRunStream() const 
	{
		return run_stream; 
	}
	uint32 GetRunStreamLength() const 
	{
		return run_stream_len;
	}
	uchar* GetQualityStream() const 
	{
		return qua_stream; 
	}
	uint32 GetQualityStreamLength() const 
	{
		return qua_stream_len; 
	}

private:
	uint64 b_start_rec_no;
	uint32 rec_count;
	uint32 global_max_sequence_length;

	uchar *qua_stream;
	uchar *run_stream;
	uint32 qua_stream_len;
	uint32 run_stream_len;

	std::vector<FastqRecord> records;
	std::vector<LzMatch> lz_matches;
	std::vector<uint32> no_of_amb;
	std::vector<int32> prev_value;	// tmp buffer

#if (D_COMPUTE_RECORDS_CRC_PER_BLOCK)
	Crc32Hasher crc_hasher;
#endif

	void StoreTitle(BitStream &bit_stream, std::vector<Field> &fields, int32 block_no, bool is_num_fields_constant);
	void StoreQualityPlain(BitStream &bit_stream, uchar *qua_code, HuffmanEncoder::Code **qua_huf_codes, int32 n_qualities, bool trucated_hashes);
	void StoreQualityRLE(BitStream &bit_stream, uchar *qua_code, HuffmanEncoder::Code **qua_huf_codes, HuffmanEncoder::Code **run_huf_codes, 
		int32 n_qualities);

	void StoreLzMatches(BitStream &bit_stream, LzMatcher &lz_matcher);
	void StoreDNAPlain(BitStream &bit_stream, LzMatcher &lz_matcher, uchar *sym_code, bool try_lz);
	void StoreDNAHuf(BitStream &bit_stream, LzMatcher &lz_matcher, uchar *sym_code, HuffmanEncoder::Code *sym_huf_codes, bool try_lz);

	void ReadTitle(BitStream &bit_stream, std::vector<Field> &fields, uint32 n_fields, int32 block_no, bool is_num_fields_constant);
	void ReadQualityPlain(BitStream &bit_stream, std::vector<uchar> &qualities, 
		std::vector<HuffmanEncoder*> &Huffman_qua, int32 n_qualities, bool trucated_hashes,  bool uses_const_delta);
	void ReadQualityRLE(BitStream &bit_stream, std::vector<uchar> &qualities,
		std::vector<HuffmanEncoder*> &Huffman_qua, int32 n_qualities, std::vector<HuffmanEncoder*> &Huffman_run, int32 max_run_len);
	
	void ReadLzMatches(BitStream &bit_stream, LzMatcher &lz_matcher);
	void ReadDNAPlain(BitStream &bit_stream, LzMatcher &lz_matcher, std::vector<uchar> &symbols, bool try_lz, bool extracting = false);
	void ReadDNAHuf(BitStream &bit_stream, LzMatcher &lz_matcher, std::vector<uchar> &symbols, HuffmanEncoder *Huffman_sym, bool try_lz, bool extracting = false);

	void FindLzMatches(LzMatcher &lz_matcher);
	inline void DecodeLzMatches(LzMatcher &lz_matcher, uint32 rec_no);
	inline void DecodeLzMatches_Insert(LzMatcher &lz_matcher, uint32 rec_no);

	// no copy ctor and assign operator
	Block(const Block& ) {}
	Block& operator=(const Block& ) {return *this;}

#if (D_RESERVE_BYTES_PER_BLOCK)
	static const uint32 RESERVED_BYTES	= 4;
#endif

#if (D_COMPUTE_RECORDS_CRC_PER_BLOCK)
	uint32 ComputeRecordsCrc32();
#endif
};

// ********************************************************************************************
Block::Block(uint32 block_size, uint64 _b_start_rec_no, uint32 _rec_count) 
	:	b_start_rec_no(_b_start_rec_no)
	,	rec_count(_rec_count)
	,	global_max_sequence_length(0)
	,	qua_stream(NULL)
	,	run_stream(NULL)
	,	qua_stream_len(0)
	,	run_stream_len(0)
{
	records.resize(block_size);
};

// ********************************************************************************************
Block::~Block()
{
	if (qua_stream)
		delete[] qua_stream;

	if (run_stream)
		delete[] run_stream;
}

// ********************************************************************************************
void Block::Reset(uint64 _b_start_rec_no, uint32 _rec_count)
{
	b_start_rec_no = _b_start_rec_no;
	rec_count = _rec_count;

	if (qua_stream)
	{
		delete[] qua_stream;
		qua_stream = NULL;
	}

	if (run_stream)
	{
		delete[] run_stream;
		run_stream = NULL;
	}
}

// ********************************************************************************************
void Block::InsertRecord(const FastqRecord &rec, uint32& max_seq_len, uint32& min_seq_len, uint32& max_qua_len, 
	uint32& min_qua_len, std::vector<uint32> &dna_occ, uint32 &fastq_flags, std::vector<uint32> &/*quality_occ*/)
{
	records[rec_count++].Set(rec);
	FastqRecord& local_rec = records[rec_count-1];
	AmbCodes::Transfer(local_rec);		//:HACK: moved from I/O, untransferring at DSRC scope !!

	//:TODO: move to pre-processing stage @ superblock
	for (uint32 i = 0; i < local_rec.sequence_len; ++i)
	{
		++dna_occ[local_rec.sequence[i]];
	}

	if (local_rec.quality_len > max_qua_len)
		max_qua_len = local_rec.quality_len;

	if (local_rec.quality_len < min_qua_len)
		min_qua_len = local_rec.quality_len;

	if (local_rec.sequence_len > max_seq_len)
		max_seq_len = local_rec.sequence_len;

	if (local_rec.sequence_len < min_seq_len)
		min_seq_len = local_rec.sequence_len;

	if (local_rec.plus_len != 1)
		fastq_flags &= ~FLAG_PLUS_ONLY;
}

// ********************************************************************************************
void Block::DecodeLzMatches(LzMatcher &lz_matcher, uint32 rec_no)
{		
	if (lz_matches[rec_no].length)
	{
		lz_matcher.DecodeMatch(records[rec_no].sequence, lz_matches[rec_no].rec_no, lz_matches[rec_no].rec_offset, lz_matches[rec_no].length,
			records[rec_no].sequence_len);
	}
}

// ********************************************************************************************
void Block::DecodeLzMatches_Insert(LzMatcher &lz_matcher, uint32 rec_no)
{
	if (records[rec_no].lz_inserted)
	{
		lz_matcher.InsertDecoding(b_start_rec_no+rec_no, records[rec_no].sequence, records[rec_no].sequence_len, records[rec_no].quality, 
			records[rec_no].quality_len);
	};
}

// ********************************************************************************************
void Block::Resize(uint32 new_size)
{
	if (records.size() == new_size)
		return;

	records.resize(new_size);
}

#endif

