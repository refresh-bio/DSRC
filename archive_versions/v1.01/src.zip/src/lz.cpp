/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/

#include "lz.h"
#include <map>
#include <vector>
#include <algorithm>
#include <cmath>

#define EMPTY	0


const double LzMatcher::LOG_PROB_THR = -1.0;
const double LzMatcher::HashTable::DEFAULT_MAX_FILL_FACTOR = 0.7;

const uint32 LzMatcher::LEVEL_SEQ_LENGTH[] = {0, 24, 36, 60};	// 0 is invalid

// ********************************************************************************************
LzMatcher::LzMatcher()
:	max_lz_memory_size(LzMatcher::DEFAULT_MAX_LZ_MEMORY_SIZE)
{
	Initialize();
	SetCompressionLevel(LzMatcher::DEFAULT_COMPRESSION_LEVEL);

	// min_factor is computed to rapidly compute hash value when moving sliding window over sequence
	min_factor = 1;
	for (uint32 i = 0; i < min_match_len-1; ++i)
	{
		min_factor *= 33;
	}

	PreparePhred();
}

// ********************************************************************************************
LzMatcher::~LzMatcher()
{
	Reset();
}


// ********************************************************************************************
void LzMatcher::Initialize()
{
	// Prepare buffer for sequence data
	buffer.clear();
	buf_memory_size = 0;

	hash_value = 0;
	part_pos = 0;

	cur_part = -1;
	frozen = false;

	hash_table.size = HashTable::INITIAL_SIZE;
	hash_table.size_mask = hash_table.size - 1;
	hash_table.max_fill_factor = HashTable::DEFAULT_MAX_FILL_FACTOR;
	hash_table.elems = 0;
	hash_table.max_elems = 0;
	if (!hash_table.data)
		hash_table.data = new HashTable::Entry[hash_table.size];
	hash_table.memory_size = hash_table.size * sizeof(HashTable::Entry);

	for (uint32 i = 0; i < hash_table.size; ++i)
	{
		hash_table.data[i].buffer_pos = EMPTY;
	}
}

// ********************************************************************************************
void LzMatcher::Reset()
{
	// Release buffer for sequence data
	for (uint32 i = 0; i < buffer.size(); ++i)
	{
		if (buffer[i])
			delete[] buffer[i];
	}
	buffer.clear();

	if (hash_table.data)
	{
		delete[] hash_table.data;
		hash_table.data = 0;
	}

	Initialize();
}

// ********************************************************************************************
void LzMatcher::PreparePhred()
{
	for (int32 i = 0; i < 34; ++i)
	{
		log_phred[i] = -10;
	}
	for (int32 i = 34; i < 127; ++i)
	{
		log_phred[i] = log10(1.0 - pow(10, -(i-33)/10.0));
	}
	for (int32 i = 127; i < 256; ++i)
	{
		log_phred[i] = -10;
	}
}

// ********************************************************************************************
void LzMatcher::PrepareNextPart()
{
	if ((cur_part+2) * part_size + hash_table.memory_size >= max_lz_memory_size)
	{
		frozen = true;
		return;
	}

	buffer.push_back(new uchar[part_size]);
	++cur_part;
	part_pos = 1;		

	buf_memory_size = (cur_part+1) * part_size;
}

// ********************************************************************************************
void LzMatcher::ResizeHT_Encode()
{
	uint32 old_ht_size = hash_table.size;
	HashTable::Entry *old_hash_table = hash_table.data;

	uint64 new_size = hash_table.size << 1;
	
	if (new_size <= (HashTable::INITIAL_SIZE << 1))			// resized for the first time
	{
		//hash_table.size = part_size;
		new_size = part_size >> 8;
		old_ht_size = 0;
	}

	uint64 new_ht_memory = new_size * sizeof(HashTable::Entry);
	if (buf_memory_size + hash_table.memory_size + new_ht_memory >= max_lz_memory_size)
	{
		frozen = true;
		return;
	}

	hash_table.size = (uint32)new_size;
	hash_table.memory_size = new_ht_memory;
	
	hash_table.size_mask = hash_table.size - 1;
	hash_table.max_elems = (uint32) (hash_table.size * hash_table.max_fill_factor);
	hash_table.data = new HashTable::Entry[hash_table.size];
	hash_table.elems = 0;

	std::fill((uchar*)hash_table.data, (uchar*)hash_table.data + hash_table.size * sizeof(HashTable::Entry), 0);
	
	for (uint32 i = 0; i < old_ht_size; ++i)
	{
		HashTable::Entry &ent = old_hash_table[i];
		if (ent.buffer_pos != EMPTY)
		{
			InsertHT_Encode(&buffer[ent.buffer_pos >> part_size_exp][ent.buffer_pos & part_size_mask],
				ent.buffer_pos, ent.rec_no, ent.rec_offset, false);
		}
	}

	if (old_hash_table)
	{
		delete[] old_hash_table;
	}
}

// ********************************************************************************************
bool LzMatcher::InsertHT_Encode(uchar *str, uint64 buffer_pos, uint64 rec_no, uint32 rec_offset, 
	bool force_insert)
{
	if (frozen)
		return false;

	if (rec_no >= (1ull << 32))
		return false;

	if (hash_table.elems >= hash_table.max_elems)
		ResizeHT_Encode();

	uint32 col_num = 0;
	uint32 h1 = Hash1(str + rec_offset);
	
#if (USE_MODIFIED_HASHING_COMPRESS)
	uint32 h = h1 & hash_table.size_mask;

	while (hash_table.data[h].buffer_pos != EMPTY && col_num < max_col_entry)
	{
		h1 = HashI(h1);
		h = h1 & hash_table.size_mask;
		++col_num;
	}
#else
	const uint32 h2 = 1;
	uint32 h = h1 & hash_table.size_mask;

	while (hash_table.data[h].buffer_pos != EMPTY && col_num < max_col_entry)
	{
		h = (h + h2) & hash_table.size_mask;
		++col_num;
	}
#endif

	if (col_num > max_col_entry && !force_insert)
		return false;

	hash_table.data[h].buffer_pos = buffer_pos;
	hash_table.data[h].rec_no = (uint32) rec_no;
	hash_table.data[h].rec_offset = rec_offset;

	hash_table.elems++;

	return true;
}

// ********************************************************************************************
void LzMatcher::ResizeHT_Decode()
{
	uint64 old_ht_size = hash_table.size;
	HashTable::Entry *old_hash_table = hash_table.data;

	uint64 new_size = hash_table.size << 1;

	if (new_size <= (HashTable::INITIAL_SIZE << 1))			// resized for the first time
	{
		//hash_table.size = part_size;
		new_size = part_size >> 8;
		old_ht_size = 0;
	}

	uint64 new_ht_memory = new_size * sizeof(HashTable::Entry);

	// no size check if exceeds MAX_LZ_MEM

	hash_table.size = (uint32)new_size;
	hash_table.memory_size = new_ht_memory;

	hash_table.size_mask = hash_table.size - 1;
	hash_table.max_elems = (uint32)(hash_table.size * hash_table.max_fill_factor);
	hash_table.data = new HashTable::Entry[hash_table.size];
	hash_table.elems = 0;
	
	std::fill((uchar*)hash_table.data, (uchar*)hash_table.data + hash_table.size * sizeof(HashTable::Entry), 0);
	
	for (uint32 i = 0; i < old_ht_size; ++i)
	{
		if (old_hash_table[i].buffer_pos != EMPTY)
			InsertHT_Decode(old_hash_table[i].buffer_pos, old_hash_table[i].rec_no);
	}

	if (old_hash_table)
		delete[] old_hash_table;
}


// ********************************************************************************************
void LzMatcher::InsertHT_Decode(uint64 buffer_pos, uint32 rec_no)
{
	if (frozen)
		return;

	if (hash_table.elems >= hash_table.max_elems)
		ResizeHT_Decode();

#if (USE_MODIFIED_HASHING_DECOMPRESS)
	uint32 h1 = HashI((uint32)(rec_no & 0xFFFFFFFF));
	uint32 h = h1 & hash_table.size_mask;

	while (hash_table.data[h].buffer_pos != EMPTY) 
	{
		h1 = HashI(h1);
		h = h1 & hash_table.size_mask;
	}
#else
	const uint32 h1 = rec_no & hash_table.size_mask;
	const uint32 h2 = 1;
	uint32 h = h1;
	
	while (hash_table.data[h].buffer_pos != EMPTY) 
	{
		h = (h + h2) & hash_table.size_mask;
	}

#endif

	hash_table.data[h].buffer_pos = buffer_pos;
	hash_table.data[h].rec_no = rec_no;

	hash_table.elems++;
}

// ********************************************************************************************
bool LzMatcher::InsertEncoding(uint64 rec_no, uchar *sequence, uint32 sequence_len, uchar *quality, uint32 quality_len)
{
	if (frozen)
		return false;

	if (rec_no >= (1ull << 32))
		return false;

	if (cur_part < 0 || part_pos + sequence_len + 1 > part_size)
	{
		PrepareNextPart();
		if (frozen)
			return false;
	}

	int64 buffer_pos = (cur_part << part_size_exp) + part_pos;
	bool inserted = false;

	uint32 len = MIN(sequence_len, quality_len);
	for (uint32 i = 0; i + min_match_len < len; i += search_step_size)
	{
		double log_prob_cor = 0.0;

		for (uint32 j = 0; j < min_match_len && log_prob_cor > LOG_PROB_THR; ++j)
		{
			log_prob_cor += log_phred[quality[i+j]];
		}
		if (log_prob_cor > LOG_PROB_THR)
		{
			inserted |= InsertHT_Encode(sequence, buffer_pos, rec_no, i);
		}
	}
	
	if (inserted)
	{
		std::copy(sequence, sequence+sequence_len+1, &buffer[cur_part][part_pos]);
		part_pos += sequence_len+1;
	}

	return inserted;
}

// ********************************************************************************************
bool LzMatcher::FindMatch(uchar *sequence, uint32 sequence_len, uchar *quality, uint32 /*quality_len*/, 
	uint32 &rec_no, uint32 &rec_offset, uint32 &match_len)
{
	if (sequence_len < min_match_len)
		return false;

	double log_prob_cor = 0.0;

	for (uint32 i = 0; i < min_match_len-1; ++i)
	{
		log_prob_cor += log_phred[quality[i]];
	}

	if (log_prob_cor < LzMatcher::LOG_PROB_THR)
		return false;

	uint32 best_len = 0;

	for (uint32 i = 0; i < search_step_size; ++i)
	{
		if (i + search_step_size > sequence_len)
			break;

		log_prob_cor += log_phred[quality[i+min_match_len-1]];
		if (log_prob_cor < LzMatcher::LOG_PROB_THR)
			break;

#if (!USE_MODIFIED_HASHING_COMPRESS)
		const uint32 h2 = 1;
#endif

		uint32 h1;
		if (i > 0)
		{
			h1 = Hash1_fast(sequence+i);
		}
		else
		{
			h1 = Hash1(sequence+i);
		}

		uint32 h = h1;

		while (hash_table.data[h].buffer_pos != EMPTY)
		{
			uint32 match_offset = hash_table.data[h].rec_offset;
			if (match_offset < i)
			{
#if (USE_MODIFIED_HASHING_COMPRESS)
				h1 = HashI(h1);
				h = h1 & hash_table.size_mask;
#else
				h = (h + h2) & hash_table.size_mask;	// (1)
#endif
				continue;
			}

			uint32 match_pos = (uint32) (hash_table.data[h].buffer_pos & part_size_mask);
			uchar *buffer_sequence = &buffer[hash_table.data[h].buffer_pos >> part_size_exp][match_pos+match_offset-i];
			const uint32 minj = MIN(sequence_len, 255+min_match_len);	// why hardcoded len+255?

			uint32 cur_len;
			for (cur_len = 0; cur_len < minj; ++cur_len)
			{
				if (buffer_sequence[cur_len] != sequence[cur_len] || quality[cur_len] >= 128)
					break;
			}

			if (cur_len > best_len)
			{
				best_len = cur_len;
				rec_no = hash_table.data[h].rec_no;
				rec_offset = match_offset-i;
			}

#if (USE_MODIFIED_HASHING_COMPRESS)
			h1 = HashI(h1);
			h = h1 & hash_table.size_mask;
#else
			h = (h + h2) & hash_table.size_mask;	// (2)
#endif

		}				
		
	}

	match_len = best_len;

	return best_len >= min_match_len;
}

// ********************************************************************************************
bool LzMatcher::InsertDecoding(uint64 rec_no, uchar *sequence, uint32 sequence_len, uchar* /*quality*/, uint32 /*quality_len*/)
{
	if (rec_no >= (1ull << 32))
		return false;

	if (cur_part < 0 || part_pos + sequence_len + 1 > part_size)
		PrepareNextPart();

	if (frozen)
		return false;

	std::copy(sequence, sequence+sequence_len+1, &buffer[cur_part][part_pos]);
	
	int64 buffer_pos = (cur_part << part_size_exp) + part_pos;

	InsertHT_Decode(buffer_pos, (uint32) rec_no);
	part_pos += sequence_len+1;

	return true;
}

// ********************************************************************************************
bool LzMatcher::DecodeMatch(uchar *sequence, uint32 rec_no, uint32 rec_offset, uint32 match_len, uint32 /*sequence_len*/)
{

#if (USE_MODIFIED_HASHING_DECOMPRESS)
	uint32 h1 = HashI(rec_no);
	uint32 h = h1 & hash_table.size_mask;

	while (hash_table.data[h].buffer_pos != EMPTY && hash_table.data[h].rec_no != rec_no) 
	{
		h1 = HashI(h1);
		h = h1 & hash_table.size_mask;
	}
#else
	const uint32 h1 = rec_no & hash_table.size_mask;
	const uint32 h2 = 1;
	uint32 h = h1;
	
	while (hash_table.data[h].buffer_pos != EMPTY && hash_table.data[h].rec_no != rec_no)
	{
		h = (h + h2) & hash_table.size_mask;
	}
#endif

	if (hash_table.data[h].buffer_pos == EMPTY)
		return false;
	
	std::copy(&buffer[hash_table.data[h].buffer_pos >> part_size_exp][(hash_table.data[h].buffer_pos & part_size_mask) + rec_offset],
		&buffer[hash_table.data[h].buffer_pos >> part_size_exp][(hash_table.data[h].buffer_pos & part_size_mask) + rec_offset]+match_len, sequence);

	return true;
} 

// ********************************************************************************************
void LzMatcher::SetCompressionLevel(uint32 level)
{
	switch (level)
	{
		case LZ_LEVEL_1:
			min_match_len = LEVEL_SEQ_LENGTH[LZ_LEVEL_1];
			max_col_entry = 8;
			compression_level = LZ_LEVEL_1;
			break;

		case LZ_LEVEL_3:
			min_match_len = LEVEL_SEQ_LENGTH[LZ_LEVEL_3];
			max_col_entry = 12;
			compression_level = LZ_LEVEL_3;
			break;

		default:
		case LZ_LEVEL_2:
			min_match_len = LEVEL_SEQ_LENGTH[LZ_LEVEL_2];
			max_col_entry = 10;
			compression_level = LZ_LEVEL_2;
			break;
	}

	search_step_size = min_match_len / 3;
	part_size_exp = 24;
	part_size = 1ull << part_size_exp;
	part_size_mask = part_size - 1;
}