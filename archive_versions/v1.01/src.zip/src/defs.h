/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/

#ifndef _DEFS_H
#define _DEFS_H

#define BIT(x)							(1 << (x))
#define MIN(x,y)						((x) <= (y) ? (x) : (y))
#define MAX(x,y)						((x) >= (y) ? (x) : (y))
#define ABS(x)							((x) >=  0  ? (x) : -(x))
#define SIGN(x)							((x) >=  0  ?  1  : -1)
#define INVALID_BYTE					0xAA
#define INVALID_DWORD					0xAAAAAAAA
#define RESERVE_BYTES_PER_DSRCFILE		1

#define FEATURE_DISABLED_IN_V_100		1


#if defined (_WIN32)
#	define _CRT_SECURE_NO_WARNINGS

#	pragma warning(disable : 4996) // D_SCL_SECURE
#	pragma warning(disable : 4244) // conversion uint64 to uint32
//#	pragma warning(disable : 4267)

#	define my_fopen	fopen
#	define my_fseek	_fseeki64
#	define my_ftell	_ftelli64
#else
#	define my_fopen	fopen
#	define my_fseek	fseek
#	define my_ftell	ftell
#endif

typedef unsigned char uchar;
typedef int int32;
typedef unsigned int uint32;
typedef long long int64;
typedef unsigned long long uint64;


#if defined(DEBUG) || defined(_DEBUG)
#	include <assert.h>
#	define my_assert(x) assert(x)
#	define D_RESERVE_BYTES_PER_BLOCK		1
#	define D_RESERVE_BYTES_PER_SUPERBLOCK	1
#	define D_COMPUTE_RECORDS_CRC_PER_BLOCK	1
#else
#	define my_assert(x)
#	define D_RESERVE_BYTES_PER_BLOCK		0
#	define D_RESERVE_BYTES_PER_SUPERBLOCK	0
#	define D_COMPUTE_RECORDS_CRC_PER_BLOCK	0
#endif


// ********************************************************************************************
enum FileModeEnum
{
	FILE_MODE_NONE = 0, 
	FILE_MODE_READ, 
	FILE_MODE_WRITE, 
	FILE_MODE_READ_RA, 
}; 

enum MemoryModeEnum
{
	MEM_MODE_NONE = 0, 
	MEM_MODE_READ, 
	MEM_MODE_WRITE, 
}; 

enum QualityEnum
{
	QUALITY_PLAIN = 0, 
	QUALITY_RLE, 
	QUALITY_PLAIN_TRUNC
};

enum FastqFlags
{
	FLAG_TRY_LZ					= BIT(0),
	FLAG_DNA_PLAIN				= BIT(1),
	FLAG_CONST_NUM_FIELDS		= BIT(2),
	FLAG_PLUS_ONLY				= BIT(3),
	FLAG_USE_DELTA				= BIT(4),
	FLAG_DELTA_CONSTANT			= BIT(5),
	FLAG_DELTA_NO_BEGIN_NUC		= BIT(6),
	FLAG_VARIABLE_LENGTH		= BIT(7),
	FLAG_LINE_BREAKS			= BIT(8),
};

enum VerboseLevel
{
	VERBOSE_NONE				= 0,
	VERBOSE_ERRORS				= BIT(0),
	VERBOSE_WARNINGS			= BIT(1) | VERBOSE_ERRORS,
	VERBOSE_INFO				= BIT(2) | VERBOSE_ERRORS | VERBOSE_WARNINGS,
};

enum LzCompressionLevel
{
	LZ_LEVEL_1 = 1,
	LZ_LEVEL_2,
	LZ_LEVEL_3,
};

// ********************************************************************************************
struct FastqRecord;
struct LzMatch;
struct Field;
struct LzMatch;

class BitMemory;
class BitStream;
class HuffmanEncoder;
class Block;
class Superblock;
class FastqFile;
class LzMatcher;
class Crc32Hasher;

class DsrcFile;
class Compressor;
class FastqCrc32OutStream;

#endif

