/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/
#ifndef _PY_BASE_H
#define _PY_BASE_H

#include "defs.h"

#include <exception>
#include <string>
#include <vector>

#include <boost/python/detail/wrap_python.hpp>		// must be included before <Python>
#include <boost/python/list.hpp>
#include <boost/python/extract.hpp>


namespace pydsrc
{
namespace py = boost::python;

// ********************************************************************************************
struct PyFastqRecord;

class PyException;
class PyFastqFile;
class PyDsrcFile;
class PyCompressor;


// ********************************************************************************************
inline void clear_list(py::list& l)
{
	int32 len = py::len(l);
	if (len > 0)
	{
		l.slice(0, len).del();
	}
}

// ********************************************************************************************
inline void shrink_list(py::list& l, int32 new_len)
{
	int32 len = py::len(l);
	my_assert(len > 0 && len > new_len);
	l.slice(new_len, len).del();
}

// ********************************************************************************************
inline void check_error()
{
	if (PyErr_Occurred())
		py::throw_error_already_set();
}

// ********************************************************************************************
template<typename _Ty>
inline py::list vector_to_list(const std::vector<_Ty>& v)
{
	py::list outlist;
	for (typename std::vector<_Ty>::const_iterator i = v.begin(); i != v.end(); ++i)
	{
		outlist.append(*i);
	}
	return outlist;
}

// ********************************************************************************************
template<typename _Ty>
inline std::vector<_Ty> list_to_vector(const py::list& l)		// boost: obj cannot be const
{
	std::vector<_Ty> outv;
	outv.reserve(py::len(l));
	for (int32 i = 0; i != (const int32)py::len(l); ++i)
	{
		outv.push_back(py::extract<_Ty>(l[i]));
	}
	return outv;
}


// ********************************************************************************************
//
// ********************************************************************************************
class PyException : public std::exception
{
	std::string message;

public:
	PyException(const char* msg) : message(msg) {}
	PyException(const std::string& msg) : message(msg) {}
	virtual ~PyException() throw() {}

	const char* what() const throw() { return message.c_str(); }	// for std::exception interface

	static void translate(const PyException& e)
	{
		PyErr_SetString(PyExc_RuntimeError, e.what());
	}
};

} // pydsrc

#endif
