/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/
#include "defs.h"
#include "compressor.h"
#include <ostream>
#include <stdio.h>
#include <time.h>

// ********************************************************************************************
//
// ********************************************************************************************
Compressor::Compressor(std::ostream& _log_stream, std::ostream& _err_stream)
	: 	dsrc_file()
	,	fastq_file()
	,	crc_buffer()
	,	log_stream(_log_stream)
	,	err_stream(_err_stream)
	,	check_crc32(false)
	,	verbose_level(VERBOSE_INFO)
{
	log_stream.precision(2);
	log_stream.width(6);
	log_stream.setf(std::ios::fixed, std::ios::floatfield);
}

// ********************************************************************************************
Compressor::~Compressor()
{

}

// ********************************************************************************************
bool Compressor::SetCrc32Checking(bool state)
{
	if (dsrc_file.IsOpened())
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: cannot set while processing\n";
		return false;
	}

	check_crc32 = state;
	return true;
}

// ********************************************************************************************
bool Compressor::SetLzMatching(bool match)
{
	if (dsrc_file.IsOpened())
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: cannot set while processing\n";
		return false;
	}
	if (!dsrc_file.SetLzMatching(match))
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: " << dsrc_file.GetError();
		return false;
	}
	return true;
}


// ********************************************************************************************
bool Compressor::SetLzMemorySize(uint32 lz_mem)
{
	if (dsrc_file.IsOpened())
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: cannot set while processing\n";
		return false;
	}
	if (!dsrc_file.SetLzMemorySize(lz_mem))
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: " << dsrc_file.GetError();
		return false;
	}
	return true;
}

#if !(FEATURE_DISABLED_IN_V_100)
// ********************************************************************************************
bool Compressor::SetLzCompressionLevel(uint32 level)
{
	if (dsrc_file.IsOpened())
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: cannot set while processing\n";
		return false;
	}
	if (!dsrc_file.SetLzCompressionLevel(level))
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: " << dsrc_file.GetError();
		return false;
	}
	return true;
}
#endif

// ********************************************************************************************
bool Compressor::Compress(const char *in_file_name, const char *out_file_name)
{
	clock_t t0 = clock();

	fastq_file.SetCrc32Checking(check_crc32);
	if (!fastq_file.Open(in_file_name))
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: cannot open input file: " << in_file_name << '\n';
		return false;
	}

	if (!dsrc_file.StartCompress(out_file_name))
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: " << dsrc_file.GetError() << '\n';
		dsrc_file.Reset(false);
		return false;
	}
	
	int64 fastq_size = fastq_file.GetFileSize();

	if (IsVerboseLevel(VERBOSE_INFO))
		log_stream << "Compressing " << in_file_name << " of size " << fastq_size / 1000000 << "MB\n";

	clock_t t1 = clock();
	int64 fastq_pos;
	int64 dsrc_pos;
	FastqRecord rec;
	int64 rec_no = 0;

	if (IsVerboseLevel(VERBOSE_INFO))
	{
		while (fastq_file.ReadNextRecord(rec))
		{
			dsrc_file.WriteRecord(rec);
			++rec_no;

			if ((rec_no & ((dsrc_file.GetSuperblockSize()<<1)-1)) == 0)
			{
				fastq_pos = fastq_file.GetFilePos();
				dsrc_pos = dsrc_file.GetFilePos();
				log_stream << "\rProcessed " << fastq_pos / 1000000 << "MB (";
				log_stream << (100.0f * fastq_pos / fastq_size) << "%)";
				float duration = (float)(clock() - t1) / CLOCKS_PER_SEC;
				if (duration > 0.0f)
				{
					float speed = fastq_pos / 1000000.0f / duration;
					log_stream << "   Speed: " << speed << "MB/s";
				}
				if (dsrc_pos)
				{
					log_stream << "   Comp. factor: " << (float) fastq_pos / dsrc_pos << " ";
				}
			}
		}
	}
	else
	{
		while (fastq_file.ReadNextRecord(rec))
		{
			dsrc_file.WriteRecord(rec);
			rec_no++;
		}
	}

	dsrc_file.FinishCompress();
	fastq_file.Close();

	if (dsrc_file.IsError())
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: " << dsrc_file.GetError() << '\n';
		dsrc_file.Reset(false);
		return false;
	}

	dsrc_pos = dsrc_file.GetFilePos();
	fastq_pos = fastq_file.GetFilePos();

	if (IsVerboseLevel(VERBOSE_INFO))
	{
		log_stream << "\rProcessed " << fastq_pos / 1000000 << "MB (";
		log_stream << (100.0f * fastq_pos / fastq_size) << "%)";
		float duration = (float) (clock() - t1) / CLOCKS_PER_SEC;
		if (duration > 0.0f)
		{
			float speed = fastq_pos /  1000000.0f / duration;
			log_stream << "   Speed: " << speed << "MB/s";
		}
		if (dsrc_pos)
		{
			log_stream << "   Comp. factor: " << (float) fastq_pos / dsrc_pos << " ";
		}
		log_stream << "\n";
	}

	if (!IsCrc32Checking())
	{
		if (IsVerboseLevel(VERBOSE_INFO))
		{
			log_stream << "Completed!\n";
			log_stream << "Input file size:        " << fastq_size << '\n';
			log_stream << "Compressed file size:   " << dsrc_pos << '\n';
			log_stream << "Compression factor:     " << (float) fastq_pos / dsrc_pos << '\n';
			log_stream << "Processing time:        " << (float) (clock() - t0) / CLOCKS_PER_SEC << "s \n";
		}
		return true;
	}

	if (IsVerboseLevel(VERBOSE_INFO))
	{
		log_stream << "Completed compression!\n";
		log_stream << "Compression time:        " << (float) (clock() - t0) / CLOCKS_PER_SEC << "s \n";
		log_stream << "Begin CRC32 check\n";
	}

	uint32 fastq_file_crc = fastq_file.GetFileCrc32Hash();
	uint32 fastq_records_crc = fastq_file.GetRecordsCrc32Hash();

	if (!dsrc_file.StartDecompress(out_file_name))
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: " << dsrc_file.GetError() << '\n';
		dsrc_file.Reset(false);
		return false;
	}

	crc_buffer.Open();

	rec.Reset();
	if (IsVerboseLevel(VERBOSE_INFO))
	{
		uint32 r = 0;
		while (dsrc_file.ReadNextRecord(rec))
		{
			crc_buffer.WriteRecord(rec);
			if ((r & ((dsrc_file.GetSuperblockSize()<<1)-1)) == 0)
			{
				log_stream << "\rProgress: " << 100.0f * r / rec_no << "%";
			}
			r++;
		}
		log_stream << "\rProgress: " << 100.0f * r / rec_no << "%\n";
	}
	else
	{
		while (dsrc_file.ReadNextRecord(rec))
		{
			crc_buffer.WriteRecord(rec);
		}
	}

	dsrc_file.FinishDecompress();
	crc_buffer.Close();

	uint32 comp_file_crc = crc_buffer.GetFileCrc32Hash();
	uint32 comp_records_crc = crc_buffer.GetRecordsCrc32Hash();

	std::string err_msg;

	if (fastq_records_crc != comp_records_crc)
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
		{
			char ff_crc_str[32];
			char cf_crc_str[32];
			sprintf(ff_crc_str, "%x", fastq_records_crc);
			sprintf(cf_crc_str, "%x", comp_records_crc);

			err_stream << "Error: compressed and decompressed records data CRC32 checksums mismatch!\n";
			err_stream << "Input file records CRC32: " << ff_crc_str << '\n';
			err_stream << "Decompressed file records CRC32: " << cf_crc_str << '\n';
		}
	}
	else
	{
		if (IsVerboseLevel(VERBOSE_INFO))
			log_stream << "Files records CRC32 checksum match\n";
	}

	if (fastq_file_crc != comp_file_crc)
	{
		if (IsVerboseLevel(VERBOSE_WARNINGS))
		{
			char ff_crc_str[32];
			char cf_crc_str[32];
			sprintf(ff_crc_str, "%x", fastq_file_crc);
			sprintf(cf_crc_str, "%x", comp_file_crc);
			log_stream << "Warning: compressed and decompressed file CRC32 checksums mismatch\n";
			log_stream << "Input file data CRC32: " << ff_crc_str << '\n';
			log_stream << "Decompressed file data CRC32: " << cf_crc_str << '\n';
		}
	}
	else
	{
		if (IsVerboseLevel(VERBOSE_INFO))
			log_stream << "Files data CRC32 checksum match\n";
	}

	if (IsVerboseLevel(VERBOSE_INFO))
	{
		log_stream << "Finished!\n";
		log_stream << "Input file size:         " << fastq_size << "\n";
		log_stream << "Compressed file size:    " << dsrc_pos << "\n";
		log_stream << "Compression factor:      " << (float) fastq_pos / dsrc_pos << "\n";
		log_stream << "Overall processing time: " << (float) (clock() - t0) / CLOCKS_PER_SEC << " s\n\n";
	}

	return true;
}

//****************************************************************************************
bool Compressor::Decompress(const char *in_file_name, const char *out_file_name)
{
	const clock_t t0 = clock();
	if (!fastq_file.Create(out_file_name))
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: cannot create output file: " << out_file_name << '\n';
		return false;
	}

	if (!dsrc_file.StartDecompress(in_file_name))
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: " << dsrc_file.GetError();
		dsrc_file.Reset(false);
		return false;
	}
	
	uint64 dsrc_size = dsrc_file.GetFileSize();

	if (IsVerboseLevel(VERBOSE_INFO))
		log_stream << "Decompressing " << in_file_name << " of size " << dsrc_size / 1000000 << "MB\n";

	const clock_t t1 = clock();
	int64 dsrc_pos;
	int64 fastq_pos;
	FastqRecord rec;

	if (IsVerboseLevel(VERBOSE_INFO))
	{
		int64 rec_no = 0;
		while (dsrc_file.ReadNextRecord(rec))
		{
			fastq_file.WriteRecord(rec);
			rec_no++;
			if ((rec_no & ((dsrc_file.GetSuperblockSize()<<1)-1)) == 0)
			{
				fastq_pos = fastq_file.GetFilePos();
				dsrc_pos = dsrc_file.GetFilePos();
				log_stream << "\rProcessed " << dsrc_pos / 1000000 << "MB (";
				log_stream << (100.0f * dsrc_pos / dsrc_size) << "%)";

				float duration = (float) (clock() - t1) / CLOCKS_PER_SEC;
				if (duration > 0.0f)
				{
					float speed = fastq_pos / 1000000.0f / duration;
					log_stream << "   Speed: " << speed << "MB/s";
				}

				if (dsrc_pos > 0)
				{
					log_stream << "   Comp. factor: " << (float) fastq_pos / dsrc_pos << " ";
				}
			}
		}
	}
	else
	{
		while (dsrc_file.ReadNextRecord(rec))
		{
			fastq_file.WriteRecord(rec);
		}
	}

	dsrc_file.FinishDecompress();
	fastq_file.Close();

	if (dsrc_file.IsError())
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: " << dsrc_file.GetError() << '\n';
		dsrc_file.Reset(false);
		return false;
	}

	dsrc_pos = dsrc_size;
	fastq_pos = fastq_file.GetFilePos();

	if (IsVerboseLevel(VERBOSE_INFO))
	{
		log_stream << "\rProcessed " << dsrc_pos / 1000000 << "MB (";
		log_stream <<	(100.0f * dsrc_pos / dsrc_size) << "%)";
		float duration = (float) (clock() - t1) / CLOCKS_PER_SEC;
		if (duration > 0.0f)
		{
			float speed = fastq_pos / 1000000.0f / duration;
			log_stream << "   Speed: " << speed << "MB/s";
		}
		if (dsrc_pos > 0)
		{
			log_stream << "   Comp. factor: " << (float) fastq_pos / dsrc_pos << " ";
		}
		log_stream << "\n";
		log_stream << "Completed!\n";
		log_stream << "Processing time: " << (float) (clock() - t0) / CLOCKS_PER_SEC << "s \n";
	}
	
	return true;
}

//****************************************************************************************
bool Compressor::ExtractRecord(const char *in_file_name, const char *out_file_name, uint64 rec_id)
{
	if (!fastq_file.Create(out_file_name))
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Cannot create output file: " << out_file_name << '\n';
		return false;
	}

	if (!dsrc_file.StartExtract(in_file_name))
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: " << dsrc_file.GetError();
		dsrc_file.Reset(false);
		return false;
	}
	
	if (IsVerboseLevel(VERBOSE_INFO))
		log_stream << "Extracting record from " << in_file_name << " of size " << dsrc_file.GetFileSize() / 1000000 << "MB\n";

	FastqRecord rec;
	dsrc_file.ExtractRecord(rec, rec_id);
	fastq_file.WriteRecord(rec);

	dsrc_file.FinishExtract();
	fastq_file.Close();

	if (dsrc_file.IsError())
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: " << dsrc_file.GetError() << '\n';
		dsrc_file.Reset(false);
		return false;
	}

	if (IsVerboseLevel(VERBOSE_INFO))
		log_stream << "Completed!\n";

	return true;
} 


//****************************************************************************************
bool Compressor::ExtractRange(const char *in_file_name, const char *out_file_name, std::vector<uint64> rec_ids)
{
	clock_t t0 = clock();
	if (!fastq_file.Create(out_file_name))
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: Cannot create output file: " << out_file_name << '\n';
		return false;
	}

	if (!dsrc_file.StartExtract(in_file_name))
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: " << dsrc_file.GetError();
		dsrc_file.Reset(false);
		return false;
	}
	
	if (IsVerboseLevel(VERBOSE_INFO))
		log_stream << "Extracting records from " << in_file_name << " of size " << dsrc_file.GetFileSize() / 1000000 << "MB\n";

	FastqRecord rec;
	sort(rec_ids.begin(), rec_ids.end());
	for (std::vector<uint64>::const_iterator i = rec_ids.begin(); i != rec_ids.end(); ++i)
	{
		dsrc_file.ExtractRecord(rec, *i);
		fastq_file.WriteRecord(rec);
	}

	dsrc_file.FinishExtract();
	fastq_file.Close();

	if (dsrc_file.IsError())
	{
		if (IsVerboseLevel(VERBOSE_ERRORS))
			err_stream << "Error: " << dsrc_file.GetError() << '\n';
		dsrc_file.Reset(false);
		return false;
	}

	if (IsVerboseLevel(VERBOSE_INFO))
	{
		log_stream << "Completed!\n";
		log_stream << "Processing time: " << (float) (clock() - t0) / CLOCKS_PER_SEC << "s \n";
	}

	return true;
}

