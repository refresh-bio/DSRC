#ifndef H_MAIN
#define H_MAIN

enum ret_codes {RET_ERR = -1, RET_OK};

int compress_file();
int decompress_file();
int extract_records();

#endif
