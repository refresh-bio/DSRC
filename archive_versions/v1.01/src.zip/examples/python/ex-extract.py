from pydsrc import *
from time import clock

filename_in = "SRR001471.dsrc"
filename_out = "SRR001471.ext.fastq"

t0 = clock()

# start extraction of dsrc archive
dsrc = DsrcFile()
dsrc.StartExtract(filename_in)

# create output fastq file
fastq = FastqFile()
fastq.Create(filename_out)

rec = FastqRecord()
# using psuedo random numbers ;)

for id in [2124, 18000, 2126, 10]:
	dsrc.ExtractRecord(rec, id)
	fastq.WriteRecord(rec)

# finish extraction and close archive
dsrc.FinishExtract()

# flush and close output file
fastq.Close()

t = (clock() - t0)
print "Processing time: ", "%.1f"%t, 's'
