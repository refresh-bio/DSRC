from pydsrc import *

filename_in = "SRR001471.fastq"
filename_dsrc = "SRR001471.dsrc"
filename_test = "SRR001471.test.fastq"
filename_ext = "SRR001471.ext.fastq"

# create and configure DSRC compressor
dsrc = Compressor()

# show only error messages
dsrc.VerboseLevel = VERBOSE_ERRORS

# enable Lz-Matching with max. of 4096 MB memory
dsrc.LzMatching = True
dsrc.LzMemorySize = 4096

# enable CRC32 control checksum check
dsrc.Crc32Checking = True

# compress 'filename_in' file in FASTQ format
# and save the DSRC archive as 'filename_dsrc'
dsrc.Compress(filename_in, filename_dsrc)

# decompress 'filename_dsrc' DSRCarchive
# and save the output as 'filename_test' in FASTQ format
dsrc.Decompress(filename_dsrc, filename_test)

# extract record of number '40' from 'filename_dsrc' DSRC archive
# saving record to 'filename_ext' file in FASTQ format
dsrc.ExtractRecord(filename_dsrc, filename_ext, 40)