from pydsrc import *
from time import clock

filename_in = "SRR001471.dsrc"
filename_out = "SRR001471.result.fastq"

t0 = clock()

# start decompression of dsrc archive 
dsrc = DsrcFile()
dsrc.StartDecompress(filename_in)

# create output fastq file
fastq = FastqFile()
fastq.Create(filename_out)

print "Decompressing", filename_in, "of size", dsrc.Size/1000000, "MB"

# read all records from dsrc archive and write them to output fastq file
rec = FastqRecord()
while dsrc.ReadNextRecord(rec):
	fastq.WriteRecord(rec)

# finish decompression of dsrc archive - perform cleanup and close file
dsrc.FinishDecompress()

# flush and close output file
fastq.Close()	

# print some results ;)
t = (clock() - t0)
fq_size = fastq.Position

if t > 0.0:
	s = fq_size / t / 1000000.0
	print "Speed:\t\t\t", "%.2f"%s, "MB/s"
if dsrc.Size > 0:
	print "Comp. factor:\t\t", "%.2f"%(1.0*fq_size/dsrc.Size)	
print "Processing time:\t", "%.1f"%t, 's'
