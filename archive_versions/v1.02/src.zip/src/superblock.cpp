/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/

#include "defs.h"
#include "superblock.h"
#include <algorithm>
#include <string.h>
#include <time.h>


// ********************************************************************************************
Superblock::Superblock(uint32 _sb_size, uint32 _block_size, uint64 _sb_start_rec_no, uint32 _global_max_sequence_length)
	:	b_count(0)
	,	b_no(0)
	,	rec_count(0)
	,	rec_no(0)
	,	sb_start_rec_no(_sb_start_rec_no)
	,	sb_size(_sb_size)
	,	block_size(_block_size)
	,	n_field(0)
	,	no_of_symbols(0)
	,	no_of_qualities(0)
	,	quality_stats_mode(QUALITY_PLAIN)
	,	min_quality_len((uint32) -1)
	,	max_quality_length(0)
	,	min_sequence_length((uint32) -1)
	,	max_sequence_length(0)
	,	max_run_len(0)
	,	global_max_sequence_length(_global_max_sequence_length)
	,	sequence_start(0)
	,	quality_start(0)
	,	sym_huf_codes(NULL)
	,	Huffman_sym(NULL)
	,	qua_huf_codes(NULL)
	,	raw_qua_huf_codes(NULL)
	,	run_huf_codes(NULL)
	,	raw_run_huf_codes(NULL)
	,	quality_stats(NULL)
	,	raw_quality_stats(NULL)
	,	sym_stats(NULL)
	,	run_stats(NULL)	
	,	raw_run_stats(NULL)
	,	sb_file_pos(0)
{
	dna_occ.resize(256);
	quality_occ.resize(256);

	blocks.resize(sb_size / block_size);
	for (uint32 i = 0; i < sb_size / block_size; ++i)
	{
		blocks[i] = NULL;
	}

	// default flags
	fastq_flags = FLAG_PLUS_ONLY | FLAG_DNA_PLAIN;
}

// ********************************************************************************************
Superblock::~Superblock() 
{
	for (uint32 i = 0; i < blocks.size(); ++i)
		delete blocks[i];
	blocks.clear();
	Reset();
}

// ********************************************************************************************
void Superblock::Reset(uint64 _sb_start_rec_no, int32 _global_max_sequence_length, int32 single_block) 
{
	// Release memory for fields data
	fields.clear();
	n_field = 0;

	if (_global_max_sequence_length >= 0)
	{
		global_max_sequence_length = _global_max_sequence_length;
	}

	// Release Huffman trees - DNA symbols
	if (Huffman_sym)
	{
		delete Huffman_sym;
		Huffman_sym = NULL;
		delete[] sym_huf_codes;
		sym_huf_codes = NULL;
	}

	// Release Huffman trees - codes
	for (uint32 i = 0; i < Huffman_qua.size(); ++i)
	{
		delete Huffman_qua[i];
	}

	Huffman_qua.clear();
	if (qua_huf_codes)
	{
		delete[] qua_huf_codes;
		delete[] raw_qua_huf_codes;
		qua_huf_codes = NULL;
		raw_qua_huf_codes = NULL;
	}

	// Release Huffman trees - runs
	for (uint32 i = 0; i < Huffman_run.size(); ++i)
		delete Huffman_run[i];

	Huffman_run.clear();
	if (run_huf_codes)
	{
		delete[] run_huf_codes;
		delete[] raw_run_huf_codes;
		run_huf_codes = NULL;
		raw_run_huf_codes = NULL;
	}

	// Release blocks
	if (single_block < 0)
	{
		for (uint32 i = 0; i < blocks.size(); ++i)
		{
			if (!blocks[i])
			{
				blocks[i] = new Block(block_size, i*block_size + _sb_start_rec_no);
			}
			blocks[i]->Reset(_sb_start_rec_no + i*block_size);
		}
	}
	else
	{
		if (!blocks[single_block])
		{
			blocks[single_block] = new Block(block_size, single_block*block_size + _sb_start_rec_no);
		}
		blocks[single_block]->Reset(_sb_start_rec_no + single_block*block_size);
	}
	b_count = 0;

	// Release memory for DNA and quality stats
	if (sym_stats)
	{
		delete[] sym_stats;
		sym_stats = NULL;
	}

	if (quality_stats)
	{
		delete[] quality_stats;
		delete[] raw_quality_stats;
		quality_stats = NULL;
		raw_quality_stats = NULL;
	}

	if (run_stats)
	{
		delete[] run_stats;
		delete[] raw_run_stats;
		run_stats = NULL;
		raw_run_stats = NULL;
	}

	fill_n(dna_occ.begin(), 256, 0);
	fill_n(quality_occ.begin(), 256, 0);
	
	fastq_flags = FLAG_PLUS_ONLY | FLAG_DNA_PLAIN;
	quality_stats_mode = QUALITY_PLAIN;
	min_quality_len = (uint32) -1;			// max uint
	max_quality_length = 0;
	max_run_len = 0;
	min_sequence_length = (uint32) -1;
	max_sequence_length = 0;

	// Initialize record counters
	rec_count = 0;
	sb_start_rec_no = _sb_start_rec_no;
}

// ********************************************************************************************
void Superblock::Process(BitStream &bit_stream, LzMatcher &lz_matcher, bool try_lz)
{
	AnalyzeDeltaAndTransferAmb();

	if (try_lz && max_sequence_length > lz_matcher.GetMinMatchLen())
	{
		fastq_flags |= FLAG_TRY_LZ;
	}
	else
	{
		fastq_flags &= ~FLAG_TRY_LZ;
	}

	AnalyzeTitles();

	ComputeStatsDNAandPlus();

	quality_stats_mode = ChoosequenceualityMethod();
	if (quality_stats_mode == QUALITY_RLE)
	{
		ComputeStatsQualityRLE();
	}
	else
	{
		ComputeStatsQualityPlain();
	}

	// get sb position
	sb_file_pos = bit_stream.GetPos();

#if (D_RESERVE_BYTES_PER_SUPERBLOCK)
	{
		uchar bytes[Superblock::RESERVED_BYTES];
		std::fill(bytes, bytes+Superblock::RESERVED_BYTES, INVALID_BYTE);
		bit_stream.PutBytes(bytes, Superblock::RESERVED_BYTES);
	}
#endif

	// store data
	bit_stream.PutWord(rec_count);
	//bit_stream.PutWord(max_sequence_length);
	bit_stream.PutWord(max_quality_length);
	bit_stream.PutWord(global_max_sequence_length);
	bit_stream.PutByte((uchar) symbols.size());
	bit_stream.PutByte((uchar) quality_stats_mode);
	bit_stream.PutByte((uchar) qualities.size());
	bit_stream.PutWord(fastq_flags);

	if ((fastq_flags & (FLAG_USE_DELTA | FLAG_DELTA_CONSTANT)) == (FLAG_USE_DELTA | FLAG_DELTA_CONSTANT))
	{
		bit_stream.PutByte(sequence_start);
		bit_stream.PutByte(quality_start);
	}

	if (quality_stats_mode == QUALITY_RLE)
	{
		bit_stream.PutByte((uchar) max_run_len);
	}

	if ((fastq_flags & FLAG_DNA_PLAIN) == 0)
	{
		ComputeDNAHuffman();
	}
	StoreDNA(bit_stream);

	// Compute and store qualities
	if (quality_stats_mode == QUALITY_RLE)
	{
		ComputeQualityRLEHuffman();
		StoreQualityRLE(bit_stream);
	}
	else
	{
		ComputeQualityPlainHuffman();
		StoreQualityPlain(bit_stream);
	}

	StoreTitle(bit_stream);

	// Block data
	file_pos.clear();
	for (uint32 i = 0; i < b_count; ++i)
	{
		file_pos.push_back((uint32) (bit_stream.GetPos() - sb_file_pos));
		blocks[i]->Process(bit_stream, lz_matcher, fields, n_field, fastq_flags, 
			sym_code, sym_huf_codes, qua_code, qua_huf_codes, max_run_len, run_huf_codes, 
			(uint32) qualities.size(), global_max_sequence_length, max_quality_length, 
			i, quality_stats_mode);
	}
	
	if (sym_huf_codes)
	{
		delete[] sym_huf_codes;
		sym_huf_codes = NULL;
	}

	if (qua_huf_codes)
	{
		delete[] qua_huf_codes;
		delete[] raw_qua_huf_codes;
		qua_huf_codes = NULL;
		raw_qua_huf_codes = NULL;
	}

	if (run_huf_codes)
	{
		delete[] run_huf_codes;
		delete[] raw_run_huf_codes;
		run_huf_codes = NULL;
		raw_run_huf_codes = NULL;
	}
}

// ********************************************************************************************
bool Superblock::Read(BitStream &bit_stream, LzMatcher &lz_matcher, int32 block_id, uint64 file_pos, bool extract)
{
	uint32 tmp;

#if (D_RESERVE_BYTES_PER_SUPERBLOCK)
	{
		uchar bytes[Superblock::RESERVED_BYTES];
		bit_stream.GetBytes(bytes, Superblock::RESERVED_BYTES);
		for (uint32 i = 0; i < Superblock::RESERVED_BYTES; ++i)
		{
			my_assert(bytes[i] == INVALID_BYTE);
		}
	}
#endif

	// check if exceeds file
	bit_stream.GetWord(rec_count);
	b_count = (rec_count + block_size - 1) / block_size;

	//bit_stream.GetWord(max_sequence_length);
	bit_stream.GetWord(max_quality_length);
	bit_stream.GetWord(global_max_sequence_length);
	//my_assert(max_sequence_length <= global_max_sequence_length);

	bit_stream.GetByte(no_of_symbols);
	my_assert(no_of_symbols <= 256);

	bit_stream.GetByte(quality_stats_mode);
	my_assert(quality_stats_mode < 4);

	bit_stream.GetByte(no_of_qualities);
	my_assert(no_of_qualities <= 256);

	bit_stream.GetWord(fastq_flags);
	my_assert(fastq_flags < 1 << 8);

	bool use_delta_constant = (fastq_flags & (FLAG_USE_DELTA | FLAG_DELTA_CONSTANT)) ==  (FLAG_USE_DELTA | FLAG_DELTA_CONSTANT);
	if (use_delta_constant)
	{
		bit_stream.GetByte(tmp);
		my_assert(tmp < 256);
		sequence_start = (uchar) tmp;

		bit_stream.GetByte(tmp);
		my_assert(tmp < 256);
		quality_start = (uchar) tmp;
	}

	if (quality_stats_mode == QUALITY_RLE)
	{
		bit_stream.GetByte(max_run_len);
		my_assert(max_run_len <= 256);
	}

	ReadDNA(bit_stream);

	if (quality_stats_mode == QUALITY_RLE)
	{
		ReadQualityRLE(bit_stream);
	}
	else
	{
		ReadQualityPlain(bit_stream);
	}

	
	ReadTitle(bit_stream);

	for (uint32 i = 0; i < fields.size(); ++i)
	{
		fields[i].block_desc.resize(b_count);
	}

	if (block_id < 0)	// read all
	{
		for (uint32 i = 0; i < b_count; ++i)
		{
			uint32 block_recs = rec_count - i*block_size;
			if (block_recs > block_size)
			{
				block_recs = block_size;
			}
			blocks[i]->Reset(sb_start_rec_no + i*block_size, block_recs);
			blocks[i]->Read(bit_stream, lz_matcher, fields, n_field,fastq_flags, 
				symbols, Huffman_sym, qualities, Huffman_qua, max_run_len, Huffman_run, 
				(uint32) qualities.size(), global_max_sequence_length, max_quality_length, 
				i, quality_stats_mode, extract);
		}
	}
	else
	{
		bit_stream.SetPos(file_pos);
		uint32 block_recs = rec_count - block_id*block_size;
		if (block_recs > block_size)
		{
			block_recs = block_size;
		}

		blocks[block_id]->Reset(sb_start_rec_no+block_id*block_size, block_recs);
		blocks[block_id]->Read(bit_stream, lz_matcher, fields, n_field, fastq_flags,
			symbols, Huffman_sym, qualities, Huffman_qua, max_run_len, Huffman_run, 
			(uint32) qualities.size(), global_max_sequence_length, max_quality_length, 
			block_id, quality_stats_mode, true);
	}

	// do not UnDelta before LzMatching, as sequences are badly joined
	// on compress:		T[...]0|0102
	// on UnDelta:		T[...]C|ACCT
	// on decompress:	T[???]x|ACCT
	// on Delta:		T[???]4|3102
	// on LzCopy:		T[...]0|3102		<-- invaid '3'
	if (!extract)
	{
		UndeltaAndUntransferAmb();
	}

	if (qua_huf_codes)
	{
		delete[] qua_huf_codes;
		delete[] raw_qua_huf_codes;
		qua_huf_codes = NULL;
		raw_qua_huf_codes = NULL;
	}

	if (run_huf_codes)
	{
		delete[] run_huf_codes;
		delete[] raw_run_huf_codes;
		run_huf_codes = NULL;
		raw_run_huf_codes = NULL;
	}

	if (sym_stats)
	{
		delete[] sym_stats;
		sym_stats = NULL;
	}

	if (quality_stats)
	{
		delete[] quality_stats;
		delete[] raw_quality_stats;
		quality_stats = NULL;
		raw_quality_stats = NULL;
	}

	rec_no = 0;
	b_no   = 0;

	fields.clear();

	return true;
}

// ********************************************************************************************
void Superblock::ComputeStatsDNAandPlus()
{
	fastq_flags &= ~(FLAG_LINE_BREAKS | FLAG_VARIABLE_LENGTH);

	bool is_length_variable = min_quality_len != max_quality_length;
	is_length_variable &= min_sequence_length != max_sequence_length;

	bool are_line_breaks = false;
	for (uint32 i = 0; i < blocks.size(); ++i)
	{
		std::vector<FastqRecord>& records = blocks[i]->GetRawRecords();
		for (uint32 j = 0; j < blocks[i]->GetRecordCount(); ++j)
		{
			are_line_breaks |= records[j].sequence_breaks || records[j].quality_breaks;
		}
	}

	symbols.clear();

	int32 sym_idx = 0;
	for (uint32 i = 0; i < 256; ++i)
	{
		if (dna_occ[i])
		{
			symbols.push_back((uchar) i);
			sym_code[i] = (uchar)sym_idx++;
		}
	}

	if (sym_stats)
	{
		delete[] sym_stats;
	}
	sym_stats = new uint32[symbols.size()];
	for (uint32 i = 0; i < symbols.size(); ++i)
	{
		sym_stats[i] = dna_occ[symbols[i]];
	}

	if (symbols.size() > 4)
	{
		fastq_flags &= ~FLAG_DNA_PLAIN;
		//fastq_flags &= ~FLAG_TRY_LZ;
	}
	else
	{
		std::vector<uint32> sym_tmp(dna_occ.begin(), dna_occ.end());
		std::sort(sym_tmp.begin(), sym_tmp.end());

		if (sym_tmp[0] > sym_tmp[2] + sym_tmp[3])
		{
			fastq_flags &= ~FLAG_DNA_PLAIN;
		}
		else
		{
			fastq_flags |= FLAG_DNA_PLAIN;
		}
	}

	if (is_length_variable)
		fastq_flags |= FLAG_VARIABLE_LENGTH;

	if (are_line_breaks)
		fastq_flags |= FLAG_LINE_BREAKS;
}

// ********************************************************************************************
void Superblock::ComputeStatsQualityPlain()
{
	bool alphabet_qua[256] = {false};

	// Find alphabets qualities
	// Find also sequence_len
	for (uint32 i = 0; i < b_count; ++i)
	{
		std::vector<FastqRecord>& records = blocks[i]->GetRawRecords();
		for (uint32 j = 0; j < blocks[i]->GetRecordCount(); ++j)
		{
			uchar *cur_quality = records[j].quality;
			uint32 cur_quality_len = records[j].quality_len;
			if (quality_stats_mode == QUALITY_PLAIN)
			{
				for (uint32 k = 0; k < cur_quality_len; ++k)
				{
					alphabet_qua[cur_quality[k]] = true;
				}
			}
			else
			{
				uint32 r = 0;
				for (uint32 k = 0; k < cur_quality_len; ++k)
				{
					alphabet_qua[cur_quality[k]] = true;

					if (cur_quality[k] != '#')
						r = k;
				}
				records[j].rec_th_len = r+1;
			}
		}
	}

	qualities.clear();

	uint32 qua_idx = 0;
	for (uint32 i = 0; i < 256; ++i)
	{
		if (alphabet_qua[i])
		{
			qualities.push_back((uchar) i);
			qua_code[i] = (uchar) qua_idx++;
		}
	}

	quality_stats = new uint32*[max_quality_length+1];
	raw_quality_stats = new uint32[(max_quality_length+1)*qua_idx];
	
	for (uint32 i = 0; i <= max_quality_length; ++i)
	{
		quality_stats[i] = raw_quality_stats+i*qua_idx;
	}
	for (uint32 i = 0; i < (max_quality_length+1)*qua_idx; ++i)
	{
		raw_quality_stats[i] = 0;
	}
	for (uint32 i = 0; i < b_count; ++i)
	{
		std::vector<FastqRecord>& records = blocks[i]->GetRawRecords();
		for (uint32 j = 0; j < blocks[i]->GetRecordCount(); ++j)
		{
			uint32 qua_len = records[j].quality_len;
			uint32 qua_len_th = records[j].rec_th_len;
			uchar *cur_quality = records[j].quality;
			if (quality_stats_mode == QUALITY_PLAIN)
			{
				for (uint32 k = 0; k < qua_len; ++k)
				{
					quality_stats[k+1][qua_code[cur_quality[k]]]++;
					quality_stats[0][qua_code[cur_quality[k]]]++;
				}
			}
			else
			{
				for (uint32 k = 0; k < qua_len_th; ++k)
				{
					quality_stats[k+1][qua_code[cur_quality[k]]]++;
					quality_stats[0][qua_code[cur_quality[k]]]++;
				}
			}
		}
	}
}

// ********************************************************************************************
void Superblock::AnalyzeDeltaAndTransferAmb()
{
	// analyze delta
	AnalyzeDelta();

	fill_n(dna_occ.begin(), 256, 0);

	const bool is_delta_constant = (fastq_flags & FLAG_DELTA_CONSTANT) != 0;
	const bool has_no_begin_nuc = (fastq_flags & FLAG_DELTA_NO_BEGIN_NUC) != 0;

	if ((fastq_flags & FLAG_USE_DELTA) != 0)
	{
		//MakeUndelta();

		for (uint32 i = 0; i < b_count; ++i)
		{
			std::vector<FastqRecord>& records = blocks[i]->GetRawRecords();
			for (uint32 j = 0; j < blocks[i]->GetRecordCount(); ++j)
			{
				FastqRecord& rec = records[j];

				Superblock::UnDeltaRecord(rec, dna_occ, is_delta_constant, has_no_begin_nuc);

				AmbCodes::Transfer(rec);

				if (rec.quality_len > max_quality_length)
					max_quality_length = rec.quality_len;

				if (rec.quality_len < min_quality_len)
					min_quality_len = rec.quality_len;

				if (rec.sequence_len > max_sequence_length)
					max_sequence_length = rec.sequence_len;

				if (rec.sequence_len < min_sequence_length)
					min_sequence_length = rec.sequence_len;
			}
		}
	}
	else
	{
		for (uint32 i = 0; i < b_count; ++i)
		{
			std::vector<FastqRecord>& records = blocks[i]->GetRawRecords();
			for (uint32 j = 0; j < blocks[i]->GetRecordCount(); ++j)
			{
				FastqRecord& rec = records[j];

				AmbCodes::Transfer(rec);

				for (uint32 k = 0; k < rec.sequence_len; ++k)
				{
					++dna_occ[rec.sequence[k]];
				}

				if (rec.quality_len > max_quality_length)
					max_quality_length = rec.quality_len;

				if (rec.quality_len < min_quality_len)
					min_quality_len = rec.quality_len;

				if (rec.sequence_len > max_sequence_length)
					max_sequence_length = rec.sequence_len;

				if (rec.sequence_len < min_sequence_length)
					min_sequence_length = rec.sequence_len;
			}
		}
	}

	if (max_sequence_length > global_max_sequence_length)
	{
		global_max_sequence_length = max_sequence_length;
	}
}

// ********************************************************************************************
void Superblock::UndeltaAndUntransferAmb(int32 block_id)
{
	uint32 i_start = 0;
	uint32 i_stop  = b_count;

	if (block_id >= 0)
	{
		i_start = block_id;
		i_stop  = i_start+1;
	}

	if ((fastq_flags & FLAG_USE_DELTA) != 0)
	{
		const bool has_no_begin_nuc = (fastq_flags & FLAG_DELTA_NO_BEGIN_NUC) != 0;

		uchar *seq_buffer = new uchar[global_max_sequence_length+2];
		uchar *qua_buffer = new uchar[max_quality_length+2];

		if ((fastq_flags & FLAG_DELTA_CONSTANT) != 0)
		{
			for (uint32 i = i_start; i < i_stop; ++i)
			{
				std::vector<FastqRecord>& records = blocks[i]->GetRawRecords();
				for (uint32 j = 0; j < blocks[i]->GetRecordCount(); ++j)
				{
					Superblock::DeltaRecord(records[j], true, sequence_start, quality_start, has_no_begin_nuc);

					AmbCodes::UnTransfer(records[j]);
				}
			}
		}
		else
		{
			for (uint32 i = i_start; i < i_stop; ++i)
			{
				std::vector<FastqRecord>& records = blocks[i]->GetRawRecords();
				for (uint32 j = 0; j < blocks[i]->GetRecordCount(); ++j)
				{
					Superblock::DeltaRecord(records[j], false, records[j].sequence[0], records[j].quality[0], has_no_begin_nuc);

					AmbCodes::UnTransfer(records[j]);
				}
			}
		}

		delete[] seq_buffer;
		delete[] qua_buffer;
	}
	else
	{
		for (uint32 i = i_start; i < i_stop; ++i)
		{
			std::vector<FastqRecord>& records = blocks[i]->GetRawRecords();
			for (uint32 j = 0; j < blocks[i]->GetRecordCount(); ++j)
			{
				AmbCodes::UnTransfer(records[j]);
			}
		}
	}
}

// ********************************************************************************************
void Superblock::ComputeStatsQualityRLE()
{
	for (uint32 i = 0; i < b_count; ++i)
	{
		blocks[i]->MakeRLE();
	}
	
	bool alphabet_qua[256] = {false};
	bool alphabet_run_len[256] = {false};

	std::fill(alphabet_qua, alphabet_qua+256, false);

	// Find qualities alphabet and run alphabet
	for (uint32 i = 0; i < b_count; ++i)
	{
		uchar *cur_run_stream = blocks[i]->GetRunStream();
		uchar *cur_qua_stream = blocks[i]->GetQualityStream();
		uint32 cur_run_stream_len = blocks[i]->GetRunStreamLength();
		for (uint32 j = 0; j < cur_run_stream_len; ++j)
		{
			alphabet_qua[cur_qua_stream[j]]     = true;
			alphabet_run_len[cur_run_stream[j]] = true;
		}
	}

	qualities.clear();
	max_run_len = 0;
	
	uint32 qua_idx = 0;
	qualities.push_back(0);
	qua_code[0] = (uchar) qua_idx++;
	for (uint32 i = 0; i < 256; ++i)
	{
		if (alphabet_qua[i])
		{
			qualities.push_back((uchar) i);
			qua_code[i] = (uchar) qua_idx++;
		}

		if (alphabet_run_len[i])
			max_run_len = i;
	}
	max_run_len++;

	quality_stats = new uint32*[qua_idx];
	raw_quality_stats = new uint32[qua_idx*qua_idx];
	run_stats = new uint32*[qua_idx];
	raw_run_stats = new uint32[qua_idx * max_run_len];
	
	for (uint32 i = 0; i < qua_idx; ++i)
	{
		quality_stats[i] = raw_quality_stats+i*qua_idx;
	}

	for (uint32 i = 0; i < qua_idx; ++i)
	{
		run_stats[i] = raw_run_stats+i*max_run_len;
	}

	for (uint32 i = 0; i < qua_idx*qua_idx; ++i)
	{
		raw_quality_stats[i] = 0;
	}

	for (uint32 i = 0; i < max_run_len*qua_idx; ++i)
	{
		raw_run_stats[i] = 0;
	}
	
	for (uint32 i = 0; i < b_count; ++i)
	{
		uchar *qua_stream = blocks[i]->GetQualityStream();
		uchar *run_stream = blocks[i]->GetRunStream();
		uchar prev = 0;
		for (uint32 j = 0; j < blocks[i]->GetQualityStreamLength(); ++j)
		{
			my_assert(prev < qua_idx);
			my_assert(qua_code[qua_stream[j]] < qua_idx);
			quality_stats[prev][qua_code[qua_stream[j]]]++;
			run_stats[qua_code[qua_stream[j]]][run_stream[j]]++;
			prev = qua_code[qua_stream[j]];
		}
	}
}

// ********************************************************************************************
void Superblock::AllocateStats()
{
	symbols.clear();
	qualities.clear();

	if (quality_stats_mode == QUALITY_RLE)
	{
		quality_stats     = new uint32*[no_of_qualities];
		raw_quality_stats = new uint32[no_of_qualities*no_of_qualities];
		run_stats         = new uint32*[no_of_qualities];
		raw_run_stats     = new uint32[no_of_qualities*max_run_len];
		for (uint32 i = 0; i < no_of_qualities; ++i)
		{
			quality_stats[i] = raw_quality_stats+i*no_of_qualities;
			run_stats[i] = raw_run_stats+i*max_run_len;
		}
		for (uint32 i = 0; i < no_of_qualities*no_of_qualities; ++i)
		{
			raw_quality_stats[i] = 0;
		}
		for (uint32 i = 0; i < max_run_len*no_of_qualities; ++i)
		{
			raw_run_stats[i] = 0;
		}
	}
	else
	{
		quality_stats = new uint32*[max_quality_length+1];
		raw_quality_stats = new uint32[(max_quality_length+1)*no_of_qualities];
		for (uint32 i = 0; i <= max_quality_length; ++i)
		{
			quality_stats[i] = raw_quality_stats+i*no_of_qualities;
		}
		for (uint32 i = 0; i < (max_quality_length+1)*no_of_qualities; ++i)
		{
			raw_quality_stats[i] = 0;
		}
	}	
}

// ********************************************************************************************
void Superblock::AnalyzeDelta()
{
	bool is_delta = false;
	bool is_delta_constant = true;
	bool has_no_begin_nuc = false;
	fastq_flags &= ~(FLAG_USE_DELTA | FLAG_DELTA_CONSTANT | FLAG_DELTA_NO_BEGIN_NUC);

	const FastqRecord& any_rec = blocks[0]->GetRawRecord(0);

	sequence_start = any_rec.sequence[0];
	quality_start = any_rec.quality[0];

	is_delta = any_rec.sequence[1] >= '0' && any_rec.sequence[1] <= '3';

	if (sequence_start <= '3' && sequence_start >= '0')
	{
		has_no_begin_nuc = true;
		is_delta_constant = false;
	}

	if (is_delta && !has_no_begin_nuc)
	{
		for (uint32 i = 0; i < b_count; ++i)
		{
			std::vector<FastqRecord>& records = blocks[i]->GetRawRecords();
			for (uint32 j = 0; j < blocks[i]->GetRecordCount(); ++j)
			{
				is_delta_constant &= records[j].sequence[0] == sequence_start;
				is_delta_constant &= records[j].quality[0] == quality_start;	
			}

			if (!is_delta_constant)
				break;
		}
	}

	if (is_delta)
		fastq_flags |= FLAG_USE_DELTA;

	if (is_delta_constant)
		fastq_flags |= FLAG_DELTA_CONSTANT;

	if (has_no_begin_nuc)
		fastq_flags |= FLAG_DELTA_NO_BEGIN_NUC;
}

/*
// ********************************************************************************************
void Superblock::MakeUndelta()
{
	const bool is_delta_constant = (fastq_flags & FLAG_DELTA_CONSTANT) != 0;
	const bool has_no_begin_nuc = (fastq_flags & FLAG_DELTA_NO_BEGIN_NUC) != 0;

	fill_n(dna_occ.begin(), 256, 0);

	for (uint32 i = 0; i < b_count; ++i)
	{
		std::vector<FastqRecord>& records = blocks[i]->GetRawRecords();
		for (uint32 j = 0; j < blocks[i]->GetRecordCount(); ++j)
		{
			Superblock::UnDeltaRecord(records[j], dna_occ, is_delta_constant, has_no_begin_nuc);
		}
	}
}

// ********************************************************************************************
void Superblock::MakeDelta(int32 block_id)
{
	const bool has_no_begin_nuc = (fastq_flags & FLAG_DELTA_NO_BEGIN_NUC) != 0;

	uchar *seq_buffer = new uchar[global_max_sequence_length+2];
	uchar *qua_buffer = new uchar[max_quality_length+2];

	uint32 i_start = 0;
	uint32 i_stop  = b_count;

	if (block_id >= 0)
	{
		i_start = block_id;
		i_stop  = i_start+1;
	}

	if ((fastq_flags & FLAG_DELTA_CONSTANT) != 0)
	{
		for (uint32 i = i_start; i < i_stop; ++i)
		{
			std::vector<FastqRecord>& records = blocks[i]->GetRawRecords();
			for (uint32 j = 0; j < blocks[i]->GetRecordCount(); ++j)
			{
				Superblock::DeltaRecord(records[j], true, sequence_start, quality_start, has_no_begin_nuc);
			}
		}
	}
	else
	{
		for (uint32 i = i_start; i < i_stop; ++i)
		{
			std::vector<FastqRecord>& records = blocks[i]->GetRawRecords();
			for (uint32 j = 0; j < blocks[i]->GetRecordCount(); ++j)
			{
				Superblock::DeltaRecord(records[j], false, records[j].sequence[0], records[j].quality[0], has_no_begin_nuc);
			}
		}
	}

	delete[] seq_buffer;
	delete[] qua_buffer;
}
*/

// ********************************************************************************************
void Superblock::ComputeDNAHuffman()
{
	my_assert(sym_huf_codes == NULL);
	my_assert(Huffman_sym == NULL);

	sym_huf_codes = new HuffmanEncoder::Code[symbols.size()];
	Huffman_sym   = new HuffmanEncoder((uint32) symbols.size());

	for (uint32 i = 0; i < symbols.size(); ++i)
	{
		Huffman_sym->Insert(sym_stats[i]);
	}

	HuffmanEncoder::Code* codes = Huffman_sym->Complete();
	for (uint32 i = 0; i < symbols.size(); ++i)
	{
		sym_huf_codes[i] = codes[i];
	}
}

// ********************************************************************************************
void Superblock::ComputeQualityPlainHuffman()
{
	my_assert(qua_huf_codes == NULL);
	my_assert(raw_qua_huf_codes == NULL);

	qua_huf_codes = new HuffmanEncoder::Code*[max_quality_length+1];
	raw_qua_huf_codes = new HuffmanEncoder::Code[(max_quality_length+1)*qualities.size()];
	for (uint32 i = 0; i <= max_quality_length; ++i)
	{
		qua_huf_codes[i] = &raw_qua_huf_codes[i*qualities.size()];
	}

	for (uint32 i = 0; i <= max_quality_length; ++i)
	{
		HuffmanEncoder *huf;
		Huffman_qua.push_back(huf = new HuffmanEncoder((uint32) qualities.size()));
		//huf->Restart();
		for (uint32 j = 0; j < qualities.size(); ++j)
		{
			huf->Insert(quality_stats[i][j]);
		}

		HuffmanEncoder::Code* codes = huf->Complete();
		for (uint32 j = 0; j < qualities.size(); ++j)
		{
			qua_huf_codes[i][j] = codes[j];
		}
	}
}

// ********************************************************************************************
void Superblock::ComputeQualityRLEHuffman()
{
	my_assert(qua_huf_codes == NULL);
	my_assert(raw_qua_huf_codes == NULL);
	my_assert(run_huf_codes == NULL);
	my_assert(raw_run_huf_codes == NULL);

	qua_huf_codes = new HuffmanEncoder::Code*[qualities.size()];
	raw_qua_huf_codes = new HuffmanEncoder::Code[(qualities.size())*qualities.size()];
	for (uint32 i = 0; i < qualities.size(); ++i)
	{
		qua_huf_codes[i] = &raw_qua_huf_codes[i*qualities.size()];
	}

	run_huf_codes = new HuffmanEncoder::Code*[(qualities.size())];
	raw_run_huf_codes = new HuffmanEncoder::Code[max_run_len*qualities.size()];
	for (uint32 i = 0; i < qualities.size(); ++i)
	{
		run_huf_codes[i] = &raw_run_huf_codes[i*max_run_len];
	}

	for (uint32 i = 0; i < qualities.size(); ++i)
	{
		HuffmanEncoder *huf;
		Huffman_qua.push_back(huf = new HuffmanEncoder((uint32) qualities.size()));
		//huf->Restart();
		for (uint32 j = 0; j < qualities.size(); ++j)
		{
			huf->Insert(quality_stats[i][j]);
		}

		HuffmanEncoder::Code* codes = huf->Complete();
		for (uint32 j = 0; j < qualities.size(); ++j)
		{
			qua_huf_codes[i][j] = codes[j];
		}
	}

	for (uint32 i = 0; i < qualities.size(); ++i)
	{
		HuffmanEncoder *huf;
		Huffman_run.push_back(huf = new HuffmanEncoder(max_run_len));
		//huf->Restart();
		for (uint32 j = 0; j < max_run_len; ++j)
		{
			huf->Insert(run_stats[i][j]);
		}

		HuffmanEncoder::Code* codes = huf->Complete();
		for (uint32 j = 0; j < max_run_len; ++j)
		{
			run_huf_codes[i][j] = codes[j];
		}
	}
}

// ********************************************************************************************
void Superblock::AnalyzeTitles()
{
	const char *c_separators = " ._,=:/-";
	const std::vector<uchar> separators(c_separators, c_separators+strlen(c_separators)+1);
	fields.clear();

	FastqRecord &rec_zero = blocks[0]->GetRawRecord(0);
	uint32 start_pos = 0;

	n_field = 0;

	// Find fields in 0th record;
	for (uint32 i = 0; i <= rec_zero.title_len; ++i)
	{
		if (!count(separators.begin(), separators.end(), rec_zero.title[i]))
			continue;

		fields.push_back(Field());

		fields[n_field].data			  = new uchar[i-start_pos+1];
		//memcpy(fields[n_field].data, rec_zero.title+start_pos, i-start_pos);
		std::copy(rec_zero.title+start_pos, rec_zero.title+i, fields[n_field].data);
		fields[n_field].data[i-start_pos] = '\0';
		fields[n_field].len               = i - start_pos;
		fields[n_field].max_len			  = fields[n_field].len;
		fields[n_field].min_len			  = fields[n_field].len;
		fields[n_field].sep               = rec_zero.title[i];
		fields[n_field].is_constant	      = true;
		fields[n_field].is_len_constant   = true;
		fields[n_field].is_numeric        = fields[n_field].IsNum();
		fields[n_field].Ham_mask          = new bool[fields[n_field].len];

		if (fields[n_field].is_numeric)
		{
			fields[n_field].min_value = fields[n_field].ToNum();
			fields[n_field].max_value = fields[n_field].min_value;
			fields[n_field].num_values[fields[n_field].min_value]++;
		}

		for (uint32 j = 0; j < fields[n_field].len; ++j)
		{
			fields[n_field].Ham_mask[j] = true;
		}
		fields[n_field].block_desc.clear();

		start_pos = i+1;
		n_field++;
	}
	std::vector<int32> prev_value;
	prev_value.resize(n_field);
	uint32 r_no = 0;

	// Analyze fields in all records in superblock
	fastq_flags |= FLAG_CONST_NUM_FIELDS;
	for (uint32 i = 0; i < b_count; ++i)
	{
		std::vector<FastqRecord>& records = blocks[i]->GetRawRecords();
		for (uint32 j = 0; j < blocks[i]->GetRecordCount(); ++j)
		{
			FastqRecord &rec = records[j];
			uint32 c_field = 0;
			uint32 start_pos = 0;

			uint32 k;
			for (k = 0; k <= rec.title_len && c_field < n_field; ++k)
			{
				if (rec.title[k] != fields[c_field].sep && k < rec.title_len)
						continue;

				if (k - start_pos > fields[c_field].max_len)
				{
					fields[c_field].max_len = k - start_pos;
				}
				else if (k - start_pos < fields[c_field].min_len)
				{
					fields[c_field].min_len = k - start_pos;
				}

				// Check whether field in a block is constant
				if (j > 0)
				{
					if (fields[c_field].block_str_len != k-start_pos)
					{
						fields[c_field].block_desc.back().is_block_constant = false;
					}
					else if (fields[c_field].block_desc.back().is_block_constant)
					{
						fields[c_field].block_desc.back().is_block_constant = std::equal(rec.title+start_pos, rec.title+k,
							records[0].title+fields[c_field].block_str_start);
					}
				}
				else
				{
					fields[c_field].block_str_start = start_pos;
					fields[c_field].block_str_len   = k-start_pos;
					fields[c_field].block_desc.push_back(Field::BlockDesc(true, true, true, 0));
				}

				fields[c_field].chars.resize(fields[c_field].max_len);
				uint32 chars_len = MIN(MAX_FIELD_STAT_LEN, k-start_pos);

				for (uint32 x = 0; x < chars_len; ++x)
				{
					fields[c_field].chars[x][rec.title[start_pos+x]]++;
				}
				for (uint32 x = MAX_FIELD_STAT_LEN; x < k-start_pos; ++x)
				{
					fields[c_field].chars[MAX_FIELD_STAT_LEN][rec.title[start_pos+x]]++;
				}
				
				if (fields[c_field].is_constant)
				{
					if (k - start_pos != fields[c_field].len)
					{
						fields[c_field].is_constant = false;
					}
					else
					{
						fields[c_field].is_constant = std::equal(fields[c_field].data, fields[c_field].data + fields[c_field].len, rec.title+start_pos);
					}
				}

				if (fields[c_field].is_len_constant)
				{
					fields[c_field].is_len_constant = fields[c_field].len == k-start_pos;
				}
				if (fields[c_field].is_numeric)
				{
					fields[c_field].is_numeric = utils::is_num(rec.title+start_pos, k-start_pos);
					if (fields[c_field].is_numeric)
					{
						int32 value = utils::to_num(rec.title+start_pos, k-start_pos);
						if (value < fields[c_field].min_value)
						{
							fields[c_field].min_value = value;
						}
						else if (value > fields[c_field].max_value)
						{
							fields[c_field].max_value = value;
						}

						if (j > 0)
						{
							if (fields[c_field].block_value != value)
								fields[c_field].block_desc.back().is_block_value_constant = false;

							if (j > 1)
							{
								if (value - prev_value[c_field] != fields[c_field].block_delta)
									fields[c_field].block_desc.back().is_block_delta_constant = false;
							}
							else // j == 1
							{
								fields[c_field].block_delta = value - prev_value[c_field];
								fields[c_field].block_desc.back().block_delta_constant = value - prev_value[c_field];
							}
						}
						else
						{
							fields[c_field].block_value = value;
						}

						if (r_no >= 1)
						{
							if (r_no > 1)
							{
								if (value - prev_value[c_field] > fields[c_field].max_delta)
								{
									fields[c_field].max_delta = value - prev_value[c_field];
								}
								if (value - prev_value[c_field] < fields[c_field].min_delta)
								{
									fields[c_field].min_delta = value - prev_value[c_field];
								}
							}
							else // r_no == 1
							{
								fields[c_field].max_delta = value - prev_value[c_field];
								fields[c_field].min_delta = value - prev_value[c_field];
							}

							fields[c_field].delta_values[value - prev_value[c_field]]++;
							if (fields[c_field].delta_values.size() > MAX_NUM_VAL_HUF)
							{
								fields[c_field].delta_values.clear();
							}
						}

						if (fields[c_field].num_values.size())
						{
							fields[c_field].num_values[value]++;
							if (fields[c_field].num_values.size() > MAX_NUM_VAL_HUF)
							{
								fields[c_field].num_values.clear();
							}
						}

						prev_value[c_field] = value;
					}
				}
				if (!fields[c_field].is_constant)
				{
					for (uint32 p = 0; p < k - start_pos && p < fields[c_field].len; ++p)
					{
						fields[c_field].Ham_mask[p] &= fields[c_field].data[p] == rec.title[p+start_pos];
					}
				}
				start_pos = k+1;
				c_field++;
			}

			// Absent fields are not constant
			if ((c_field != n_field) || (k != rec.title_len+1))
				fastq_flags &= ~FLAG_CONST_NUM_FIELDS;

			rec.no_of_fields = c_field;

			if (j != 0)
			{
				for (; c_field < n_field; ++c_field)
				{
					fields[c_field].is_constant     = false;
					fields[c_field].is_len_constant = false;
					fields[c_field].is_numeric      = false;
				}
			}
			else
			{
				for (; c_field < n_field; ++c_field)
				{
					fields[c_field].is_constant     = false;
					fields[c_field].is_len_constant = false;
					fields[c_field].is_numeric      = false;
					fields[c_field].block_desc.push_back(Field::BlockDesc(true, true, true, 0));

				}
			}
			
			++r_no;
		}
	}

	// Find better encoding of numeric values
	for (uint32 i = 0; i < n_field; ++i)
	{
		if (!fields[i].is_numeric)
		{
			if (!fields[i].is_constant)
			{
				fields[i].chars.resize(MIN(fields[i].max_len, MAX_FIELD_STAT_LEN+1));
				fields[i].no_of_bits_per_len = BitStream::BitLength(fields[i].max_len - fields[i].min_len);
			}
			continue;
		}

		int32 diff;
		if (fields[i].max_value - fields[i].min_value < fields[i].max_delta - fields[i].min_delta)
		{
			fields[i].is_delta_coding = false;
			diff = fields[i].max_value - fields[i].min_value;
		}
		else
		{
			fields[i].is_delta_coding = true;
			diff = fields[i].max_delta - fields[i].min_delta;
		}

		fields[i].no_of_bits_per_num = BitStream::BitLength(diff);
		diff = fields[i].max_value - fields[i].min_value;
		fields[i].no_of_bits_per_value = BitStream::BitLength(diff);
	}
}

// ********************************************************************************************

void Superblock::StoreDNA(BitStream &bit_stream)
{
	bit_stream.FlushPartialWordBuffer();

	// DNA symbols
	for (uint32 i = 0; i < symbols.size(); ++i)
	{
		bit_stream.PutByte(symbols[i]);
	}
	bit_stream.FlushPartialWordBuffer();

	if ((fastq_flags & FLAG_DNA_PLAIN) == 0)
	{
		HuffmanEncoder::StoreTree(bit_stream, *Huffman_sym);
	}
}

// ********************************************************************************************
void Superblock::StoreQualityPlain(BitStream &bit_stream)
{
	bit_stream.FlushPartialWordBuffer();

	// store qualities
	for (uint32 i = 0; i < qualities.size(); ++i)
	{
		bit_stream.PutByte(qualities[i]);
	}
	bit_stream.FlushPartialWordBuffer();

	// store huff qualities
	my_assert(Huffman_qua.size() == max_quality_length+1);
	for (uint32 i = 0; i <= max_quality_length; ++i)
	{
		HuffmanEncoder::StoreTree(bit_stream, *Huffman_qua[i]);
	}
	bit_stream.FlushPartialWordBuffer();
}

// ********************************************************************************************
void Superblock::StoreQualityRLE(BitStream &bit_stream)
{
	bit_stream.FlushPartialWordBuffer();

	// store qualities
	for (uint32 i = 0; i < qualities.size(); ++i)
	{
		bit_stream.PutByte(qualities[i]);
	}
	bit_stream.FlushPartialWordBuffer();

	// store huff qualities
	for (uint32 i = 0; i < qualities.size(); ++i)
	{
		HuffmanEncoder::StoreTree(bit_stream, *Huffman_qua[i]);
	}
	bit_stream.FlushPartialWordBuffer();

	// store huff runs
	for (uint32 i = 0; i < qualities.size(); ++i)
	{
		HuffmanEncoder::StoreTree(bit_stream, *Huffman_run[i]);
	}
	bit_stream.FlushPartialWordBuffer();
}

// ********************************************************************************************
void Superblock::StoreTitle(BitStream &bit_stream)
{
	bit_stream.PutWord(n_field);

	for (uint32 i = 0; i < n_field; ++i)
	{
		bit_stream.PutByte(fields[i].sep);
		bit_stream.PutByte(fields[i].is_constant);
		if (fields[i].is_constant)
		{
			bit_stream.PutWord(fields[i].len);
			bit_stream.PutBytes(fields[i].data, fields[i].len);
			continue;
		}

		bit_stream.PutByte(fields[i].is_numeric);
		if (fields[i].is_numeric)
		{
			bit_stream.PutWord(fields[i].min_value);
			bit_stream.PutWord(fields[i].max_value);
			bit_stream.PutWord(fields[i].min_delta);
			bit_stream.PutWord(fields[i].max_delta);

			int32 diff, base;
			std::map<int32, int32> &map_stats = fields[i].num_values;
			if (fields[i].max_value-fields[i].min_value < fields[i].max_delta-fields[i].min_delta)
			{
				diff = fields[i].max_value - fields[i].min_value;
				base = fields[i].min_value;
			}
			else
			{
				diff = fields[i].max_delta - fields[i].min_delta;
				base = fields[i].min_delta;
				map_stats = fields[i].delta_values;
			}

			diff++;
			if (diff <= (int32)MAX_NUM_VAL_HUF && map_stats.size())			// few values, so use Huffman for them
			{
				HuffmanEncoder* huf = fields[i].Huffman_global = new HuffmanEncoder(Field::HUF_GLOBAL_SIZE);
				//huf->Restart();
				for (uint32 j = 0; j < (uint32)diff; ++j)
				{
					huf->Insert(map_stats[base+j]);
				}
				huf->Complete();
				HuffmanEncoder::StoreTree(bit_stream, *huf);
			}

			continue;
		}

		bit_stream.PutByte(fields[i].is_len_constant);
		bit_stream.PutWord(fields[i].len);
		bit_stream.PutWord(fields[i].max_len);
		bit_stream.PutWord(fields[i].min_len);
		bit_stream.PutBytes(fields[i].data, fields[i].len);

		for (uint32 j = 0; j < fields[i].len; ++j)
		{
			bit_stream.PutBit(fields[i].Ham_mask[j]);
		}
		fields[i].Huffman_local.resize(MIN(fields[i].max_len+1, MAX_FIELD_STAT_LEN+1));

		for (uint32 j = 0; j < MIN(fields[i].max_len, MAX_FIELD_STAT_LEN); ++j)
		{
			fields[i].Huffman_local[j] = NULL;
			if (j >= fields[i].len || !fields[i].Ham_mask[j])
			{
				HuffmanEncoder* huf = fields[i].Huffman_local[j] = new HuffmanEncoder(Field::HUF_LOCAL_SIZE);
				for (uint32 k = 0; k < Field::HUF_LOCAL_SIZE; ++k)
				{
					huf->Insert(fields[i].chars[j][k]);
				}
				huf->Complete(true);
				HuffmanEncoder::StoreTree(bit_stream, *huf);
			}
		} 
		if (fields[i].max_len >= MAX_FIELD_STAT_LEN)
		{
			HuffmanEncoder* huf = fields[i].Huffman_local[MAX_FIELD_STAT_LEN] = new HuffmanEncoder(Field::HUF_LOCAL_SIZE);
			for (uint32 k = 0; k < Field::HUF_LOCAL_SIZE; ++k)
			{
				huf->Insert(fields[i].chars[(uchar) MAX_FIELD_STAT_LEN][k]);
			}
			huf->Complete(true);
			HuffmanEncoder::StoreTree(bit_stream, *huf);
		}

		bit_stream.FlushPartialWordBuffer();
	}
}

// ********************************************************************************************
void Superblock::ReadDNA(BitStream &bit_stream)
{
	uint32 tmp;

	// DNA symbols
	symbols.resize(no_of_symbols);
	for (uint32 i = 0; i < no_of_symbols; ++i)
	{
		bit_stream.GetByte(tmp);
		my_assert(tmp < 256);
		symbols[i] = (uchar) tmp;
	}

	if ((fastq_flags & FLAG_DNA_PLAIN) == 0)
	{
		if (Huffman_sym)
			delete Huffman_sym;
		Huffman_sym = new HuffmanEncoder((uint32) symbols.size());

		HuffmanEncoder::LoadTree(bit_stream, *Huffman_sym);	
	}
}

// ********************************************************************************************
void Superblock::ReadQualityPlain(BitStream &bit_stream)
{
	uint32 tmp;
	HuffmanEncoder* huf;

	// Quality symbols
	qualities.resize(no_of_qualities);
	for (uint32 i = 0; i < qualities.size(); ++i)
	{
		bit_stream.GetByte(tmp);
		my_assert(tmp < 256);
		qualities[i] = (uchar) tmp;
	}

	// Quality Huffman codes
	for (uint32 i = 0; i <= max_quality_length; ++i)
	{
		Huffman_qua.push_back(huf = new HuffmanEncoder((uint32) qualities.size()));
		HuffmanEncoder::LoadTree(bit_stream, *huf);
	}

	bit_stream.FlushInputWordBuffer();
}

// ********************************************************************************************
void Superblock::ReadQualityRLE(BitStream &bit_stream)
{
	uint32 tmp;
	HuffmanEncoder* huf;

	// read qualities
	bit_stream.FlushInputWordBuffer();

	qualities.resize(no_of_qualities);
	for (uint32 i = 0; i < qualities.size(); ++i)
	{
		bit_stream.GetByte(tmp);
		my_assert(tmp < 256);
		qualities[i] = (uchar) tmp;
	}
	bit_stream.FlushInputWordBuffer();

	for (uint32 i = 0; i < qualities.size(); ++i)
	{
		Huffman_qua.push_back(huf = new HuffmanEncoder((uint32) qualities.size()));
		HuffmanEncoder::LoadTree(bit_stream, *huf);
	}
	bit_stream.FlushInputWordBuffer();

	for (uint32 i = 0; i < qualities.size(); ++i)
	{
		Huffman_run.push_back(huf = new HuffmanEncoder(max_run_len));
		HuffmanEncoder::LoadTree(bit_stream, *huf);
	}
	bit_stream.FlushInputWordBuffer();
}

// ********************************************************************************************
void Superblock::ReadTitle(BitStream &bit_stream)
{
	uint32 tmp;

	bit_stream.GetWord(n_field);
	fields.resize(n_field);

	for (uint32 i = 0; i < n_field; ++i)
	{
		bit_stream.GetByte(tmp);
		my_assert(tmp < 256);

		fields[i].sep = (uchar) tmp;
		bit_stream.GetByte(tmp);
		fields[i].is_constant = tmp != 0;

		if (fields[i].is_constant)
		{
			bit_stream.GetWord(tmp);
			fields[i].len = tmp;
			fields[i].data = new uchar[fields[i].len+1];
			bit_stream.GetBytes(fields[i].data, fields[i].len);
			continue;
		}

		bit_stream.GetByte(tmp);
		fields[i].is_numeric = tmp != 0;
		if (fields[i].is_numeric)
		{
			bit_stream.GetWord(tmp);
			fields[i].min_value = tmp;
			bit_stream.GetWord(tmp);
			fields[i].max_value = tmp;
			my_assert(fields[i].min_value <= fields[i].max_value);

			bit_stream.GetWord(tmp);
			fields[i].min_delta = (int32) tmp;
			bit_stream.GetWord(tmp);
			fields[i].max_delta = tmp;
			my_assert(fields[i].min_delta <= fields[i].max_delta);

			int32 diff;
			std::map<int32, int32> &map_stats = fields[i].num_values;
			if (fields[i].max_value - fields[i].min_value < fields[i].max_delta - fields[i].min_delta)
			{
				fields[i].is_delta_coding = false;
				diff = fields[i].max_value - fields[i].min_value;
			}
			else
			{
				fields[i].is_delta_coding = true;
				diff = fields[i].max_delta - fields[i].min_delta;
				map_stats = fields[i].delta_values;
			}

			fields[i].no_of_bits_per_num = BitStream::BitLength(diff);
			int32 v_diff = fields[i].max_value - fields[i].min_value;
			fields[i].no_of_bits_per_value = BitStream::BitLength(v_diff);

			diff++;
			if (diff <= (int32)MAX_NUM_VAL_HUF)			// a few values, so use Huffman for them
			{	
				fields[i].Huffman_global = new HuffmanEncoder();
				HuffmanEncoder::LoadTree(bit_stream, *fields[i].Huffman_global);
				bit_stream.FlushInputWordBuffer();
			}

			continue;
		}

		bit_stream.GetByte(tmp);
		fields[i].is_len_constant = tmp != 0;
		bit_stream.GetWord(tmp);
		fields[i].len = tmp;
		bit_stream.GetWord(tmp);
		fields[i].max_len = tmp;
		bit_stream.GetWord(tmp);
		fields[i].min_len = tmp;
		fields[i].no_of_bits_per_len = BitStream::BitLength(fields[i].max_len - fields[i].min_len);
		fields[i].data = new uchar[fields[i].len+1];
		bit_stream.GetBytes(fields[i].data, fields[i].len);
		fields[i].Ham_mask = new bool[fields[i].len+1];

		for (uint32 j = 0; j < fields[i].len; ++j)
		{
			bit_stream.GetBits(tmp, 1);
			fields[i].Ham_mask[j] = tmp != 0;
		}
		fields[i].Huffman_local.resize(MIN(fields[i].max_len, MAX_FIELD_STAT_LEN+1));

		for (uint32 j = 0; j < MIN(fields[i].max_len, MAX_FIELD_STAT_LEN); ++j)
		{
			fields[i].Huffman_local[j] = NULL;
			if (j >= fields[i].len || !fields[i].Ham_mask[j])
			{
				fields[i].Huffman_local[j] = new HuffmanEncoder(Field::HUF_LOCAL_SIZE);
				HuffmanEncoder::LoadTree(bit_stream, *fields[i].Huffman_local[j]);
			}
		}
		if (fields[i].max_len >= MAX_FIELD_STAT_LEN)
		{
			fields[i].Huffman_local[MAX_FIELD_STAT_LEN] = new HuffmanEncoder(Field::HUF_LOCAL_SIZE);
			HuffmanEncoder::LoadTree(bit_stream, *fields[i].Huffman_local[MAX_FIELD_STAT_LEN]);		
		}
		bit_stream.FlushInputWordBuffer();
	}
}

// ********************************************************************************************
uint32 Superblock::ChoosequenceualityMethod()
{
	double rle_len = 0;
	double raw_len = 0;
	double th_len  = 0;
	
	for (uint32 i = 0; i < b_count; i++)
	{
		raw_len += blocks[i]->GetRawRecord(0).quality_len;
		th_len  += Superblock::TruncHashLength(blocks[i]->GetRawRecord(0).quality, blocks[i]->GetRawRecord(0).quality_len);
		rle_len += Superblock::RLELength(blocks[i]->GetRawRecord(0).quality, blocks[i]->GetRawRecord(0).quality_len);
	}
	
	if (th_len / rle_len > 1.25)		// RLE
		return QUALITY_RLE;	
	
	if (raw_len - th_len < 3 * b_count)
		return QUALITY_PLAIN;			// Plain
	
	return QUALITY_PLAIN_TRUNC;			// Plain with truncate hashes
}
 
// ********************************************************************************************
void Superblock::ResetSize(uint32 _sb_size, uint32 _block_size)
{
	my_assert(_sb_size > 0);
	my_assert(_block_size > 0);
	my_assert(blocks.size()  > 0);

	uint32 new_bno = _sb_size / _block_size;
	uint32 cur_bno = sb_size / block_size;

	if (new_bno > cur_bno)
	{
		blocks.resize(new_bno);
		if (!blocks[0])	// Empty blocks list
		{
			for (uint32 i = cur_bno; i < new_bno; ++i)
			{
				blocks[i] = NULL;
			}
		}
		else
		{
			uint64 idx = sb_start_rec_no;
			for (uint32 i = 0; i < cur_bno; ++i)
			{
				blocks[i]->Resize(_block_size);
				blocks[i]->Reset(idx);
				idx += _block_size;
			}
			for (uint32 i = cur_bno; i < new_bno; ++i)
			{
				blocks[i] = new Block(_block_size, idx);
				blocks[i]->Reset(idx);
				idx += _block_size;
			}
		}
	}
	else
	{
		if (blocks[0])	// Non-empty blocks list
		{
			uint64 idx = sb_start_rec_no;
			for (uint32 i = 0; i < new_bno; ++i)
			{
				blocks[i]->Resize(_block_size);
				blocks[i]->Reset(idx);
				idx += _block_size;
			}
			for (uint32 i = new_bno; i < cur_bno; ++i)
			{
				my_assert(blocks[i] != NULL);
				delete blocks[i];
			}
		}

		blocks.resize(new_bno);
	}

	sb_size = _sb_size;
	block_size = _block_size;

	b_count = 0;
}

// ********************************************************************************************
bool Superblock::ExtractionPostProcess(FastqRecord& rec, bool force_const_delta, 
	uint32 forced_seq_start, uint32 forced_qua_start)
{
	if ((fastq_flags & FLAG_USE_DELTA) != 0)
	{
		bool use_const_delta_encoding = (fastq_flags & (FLAG_USE_DELTA | FLAG_DELTA_CONSTANT)) == (FLAG_USE_DELTA | FLAG_DELTA_CONSTANT);
		bool has_no_begin_nuc = (fastq_flags & (FLAG_USE_DELTA | FLAG_DELTA_NO_BEGIN_NUC)) == (FLAG_USE_DELTA | FLAG_DELTA_NO_BEGIN_NUC);

		uchar seq_start;
		uchar qua_start;

		if (forced_seq_start != 0)
			seq_start = forced_seq_start;
		else if (use_const_delta_encoding)
			seq_start = sequence_start;
		else
			seq_start = rec.sequence[0];

		if (forced_qua_start != 0)
			qua_start = forced_qua_start;
		else if (use_const_delta_encoding)
			qua_start = quality_start;
		else
			qua_start = rec.quality[0];

		AmbCodes::UnTransfer(rec);

		Superblock::DeltaRecord(rec, force_const_delta | use_const_delta_encoding, seq_start, qua_start, has_no_begin_nuc);
	}
	else
	{
		AmbCodes::UnTransfer(rec);
	}

	return true;
}
