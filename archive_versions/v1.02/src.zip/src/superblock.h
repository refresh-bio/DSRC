/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/
#ifndef _SUPERBLOCK_H
#define _SUPERBLOCK_H

#include "block.h"
#include "huffman.h"
#include "lz.h"
#include <vector>

// ********************************************************************************************
//
// ********************************************************************************************
class Superblock 
{
public:
	static const uint32 DEFAULT_SIZE		= (1 << 14);
	static const uint32 MAX_FIELD_STAT_LEN	= 128;
	static const uint32 MAX_NUM_VAL_HUF		= 512;

	Superblock(uint32 sb_size = Superblock::DEFAULT_SIZE, uint32 block_size = Block::DEFAULT_SIZE, 
		uint64 _sb_start_rec_no = 0, uint32 _global_max_sequence_length = 0);
	~Superblock();

	inline void InsertRecord(const FastqRecord &rec);
	inline bool ReadNextRawRecord(FastqRecord &rec);

	inline bool ReadNextRawRecord(FastqRecord &rec, uint64 &lz_rec_id, uint32 &lz_rec_offset, 
		uint32 &lz_match_len);

	inline bool ExtractRawRecord(FastqRecord &rec, uint64 rec_id, uint64 &lz_rec_id, 
		uint32 &lz_rec_offset, uint32 &lz_match_len);

	bool ExtractionPostProcess(FastqRecord& rec, bool force_const_delta = false, 
		uint32 forced_seq_start = 0, uint32 forced_qua_start = 0);
	
	void Process(BitStream &bit_stream, LzMatcher &lz_matcher, bool _try_lz);
	bool Read(BitStream &bit_stream, LzMatcher &lz_matcher, int32 block_id = -1, uint64 file_pos = 0, 
		bool extraction = false);
	void Reset(uint64 _sb_start_rec_no = 0, int32 _global_max_sequence_length = 0, int32 single_block = -1);

	uint32 GetRecordCount() const { return rec_count; }
	uint32 GetBlockCount() const { return b_count; }
	uint32 GetCurrentRecordId() const { return rec_no; }
	uint32 GetCurrentBlockId() const { return b_no; }

	uint32 GetSuperblockSize() const { return sb_size; }
	uint32 GetBlockSize() const { return block_size; }
	void ResetSize(uint32 sb_size, uint32 block_size);

	uint64 GetFilePos() const { return sb_file_pos; }
	const std::vector<uint32>& GetBlocksFilePos() const { return file_pos; }

	bool IsSetFlag(uint32 flag) const {return (fastq_flags & flag) == flag;}

	uchar GetDeltaSequenceStart() const {return sequence_start;}
	uchar GetDeltaQualityStart() const {return quality_start;}

	static inline void DeltaRecord(FastqRecord& rec, bool use_const_delta, uchar seq_start, uchar qua_start, bool no_seq_begin = false);
	static inline void UnDeltaRecord(FastqRecord& rec, std::vector<uint32>& dna_occ, bool use_const_delta, bool no_seq_begin = false);
	static inline uint32 TruncHashLength(uchar *str, uint32 len);
	static inline uint32 RLELength(uchar *str, uint32 len);

private:

#if (D_RESERVE_BYTES_PER_SUPERBLOCK)
	static const uint32 RESERVED_BYTES = 8;
#endif

	std::vector<Block*> blocks;
	uint32 b_count;
	uint32 b_no;
	uint32 rec_count;
	uint32 rec_no;
	uint64 sb_start_rec_no;
	uint32 sb_size;
	uint32 block_size;

	uint32 fastq_flags;

	std::vector<Field> fields;
	uint32 n_field;

	uint32 no_of_symbols;
	uint32 no_of_qualities;
	uint32 quality_stats_mode;
	uint32 min_quality_len;
	uint32 max_quality_length;
	uint32 min_sequence_length;
	uint32 max_sequence_length;
	uint32 max_run_len;
	uint32 global_max_sequence_length;
	uchar sequence_start;
	uchar quality_start;

	std::vector<uchar> symbols;
	std::vector<uchar> qualities;

	uchar sym_code[256];
	uchar qua_code[256];
	HuffmanEncoder::Code *sym_huf_codes;
	HuffmanEncoder *Huffman_sym;
	HuffmanEncoder::Code **qua_huf_codes;
	HuffmanEncoder::Code *raw_qua_huf_codes;
	std::vector<HuffmanEncoder*> Huffman_qua;
	HuffmanEncoder::Code **run_huf_codes;
	HuffmanEncoder::Code *raw_run_huf_codes;
	std::vector<HuffmanEncoder*> Huffman_run;

	uint32 **quality_stats;
	uint32 *raw_quality_stats;
	uint32 *sym_stats;

	uint32 **run_stats;
	uint32 *raw_run_stats;

	std::vector<uint32> dna_occ;
	std::vector<uint32> quality_occ;

	uint64 sb_file_pos;
	std::vector<uint32> file_pos;

	void AnalyzeDelta();
	//void MakeUndelta();
	//void MakeDelta(int32 block_id = -1);
	void AnalyzeDeltaAndTransferAmb();
	void UndeltaAndUntransferAmb(int32 block_id = -1);

	void AnalyzeTitles();

	void ComputeStatsDNAandPlus();
	void ComputeStatsQualityPlain();
	void ComputeStatsQualityRLE();
	void AllocateStats();
	void ComputeDNAHuffman();
	void ComputeQualityPlainHuffman();
	void ComputeQualityRLEHuffman();

	uint32 ChoosequenceualityMethod();

	void StoreDNA(BitStream &bit_stream);
	void StoreQualityPlain(BitStream &bit_stream);
	void StoreQualityRLE(BitStream &bit_stream);
	void StoreTitle(BitStream &bit_stream);

	void ReadDNA(BitStream &bit_stream);
	void ReadQualityPlain(BitStream &bit_stream);
	void ReadQualityRLE(BitStream &bit_stream);
	void ReadTitle(BitStream &bit_stream);
};

// ********************************************************************************************
uint32 Superblock::TruncHashLength(uchar *str, uint32 len)
{
	uint32 r = 0;
	for (uint32 i = 0; i < len; ++i)
	{
		if (str[i] != '#')
			r = i;
	}
	return r;
}

// ********************************************************************************************
uint32 Superblock::RLELength(uchar *str, uint32 len)
{
	uint32 r = 0;
	uchar prev = 0;

	for (uint32 i = 0; i < len; ++i)
	{
		if (str[i] != prev)
			r++;
		prev = str[i];
	}
	if (prev == '#')
	{
		r--;
	}
	return r;
}

// ********************************************************************************************
void Superblock::InsertRecord(const FastqRecord &rec)
{
	if (rec_count % block_size == 0)
		b_count++;

	blocks[b_count-1]->InsertRecord(rec);

	if (rec.plus_len != 1)
		fastq_flags &= ~FLAG_PLUS_ONLY;

	rec_count++;
}

// ********************************************************************************************
bool Superblock::ReadNextRawRecord(FastqRecord &rec)
{
	if (rec_no % block_size == 0)
		b_no++;

	if (rec_no >= rec_count)
		return false;

	rec.Set(blocks[b_no-1]->GetRawRecord(rec_no % block_size));
	rec_no++;

	return true;
}

// ********************************************************************************************
bool Superblock::ReadNextRawRecord(FastqRecord &rec, uint64 &lz_rec_id, uint32 &lz_rec_offset, uint32 &lz_match_len)
{
	if (rec_no % block_size == 0)
		b_no++;

	if (rec_no >= rec_count)
		return false;

	rec.Set(blocks[b_no-1]->GetRawRecord(rec_no % block_size));

	const LzMatch lz = blocks[b_no-1]->GetLzMatch(rec_no % block_size);
	if (lz.length)
	{
		lz_rec_id = lz.rec_no;
		lz_rec_offset = lz.rec_offset;
	}
	lz_match_len = lz.length;

	rec_no++;

	return true;
}

// ********************************************************************************************
bool Superblock::ExtractRawRecord(FastqRecord &rec, uint64 rec_id, uint64 &lz_rec_id, 
	uint32 &lz_rec_offset, uint32 &lz_match_len)
{
	uint64 rec_id_in_sb = rec_id % sb_size;
	uint32 b_id_in_sb = (uint32) (rec_id_in_sb / block_size);
	uint32 rec_id_in_b = (uint32) (rec_id_in_sb % block_size);

	if (rec_id_in_sb >= rec_count)
		return false;

	rec.Set(blocks[b_id_in_sb]->GetRawRecord(rec_id_in_b % block_size));

	const LzMatch lz = blocks[b_id_in_sb]->GetLzMatch(rec_id_in_b);

	lz_match_len = lz.length;
	if (lz_match_len)
	{
		lz_rec_id = lz.rec_no;
		lz_rec_offset = lz.rec_offset;
	}
	else
	{
		lz_rec_id = 0;
		lz_rec_offset = 0;
	}

	return true;
}

// ********************************************************************************************
void Superblock::DeltaRecord(FastqRecord& rec, bool use_const_delta, uchar seq_start, uchar qua_start, 
	bool no_seq_begin)
{
	static const char delta_A[] = {'N', 'N', 'A', 'C', 'G', 'T'};
	static const char delta_C[] = {'N', 'N', 'C', 'A', 'T', 'G'};
	static const char delta_G[] = {'N', 'N', 'G', 'T', 'A', 'C'};
	static const char delta_T[] = {'N', 'N', 'T', 'G', 'C', 'A'};

	const uint32 MAX_BUF_SIZE = 1024;

	my_assert(rec.sequence_len < MAX_BUF_SIZE);
	my_assert(rec.quality_len < MAX_BUF_SIZE);

	uchar seq_buffer[MAX_BUF_SIZE];
	uchar qua_buffer[MAX_BUF_SIZE];

	const uint32 translation = (uint32)use_const_delta;
	const uint32 offset = (uint32)no_seq_begin;
	uchar symbol;
	
	if (!no_seq_begin)
	{
		symbol = seq_buffer[0] = seq_start;		//:TODO: analyze case when CONST DELTA && NO SEQ BEGIN
		qua_buffer[0] = qua_start;
	}
	else
	{
		symbol = 'A';
		my_assert(use_const_delta == false);
	}

	const char* delta_select = delta_A;
	
	uint32 k = 1-translation-offset;				//:^
	for ( ; k < rec.sequence_len; ++k)
	{
		switch (symbol)
		{
			case 'A':	delta_select = delta_A;	break;
			case 'C':	delta_select = delta_C;	break;
			case 'G':	delta_select = delta_G; break;
			case 'T':	delta_select = delta_T;	break;
			case 'N':	// use previous symbol matrix
			default:	break;
		}
		seq_buffer[k+translation] = (uchar) (std::find(delta_select, delta_select+6, rec.sequence[k]) - delta_select) + '.';
		qua_buffer[k+translation] = rec.quality[k];
		symbol = rec.sequence[k];
	}

	for ( ; k < rec.quality_len; ++k)
	{
		qua_buffer[k+translation] = rec.quality[k];
	}
	
	std::copy(seq_buffer, seq_buffer+rec.sequence_len+translation, rec.sequence);
	std::copy(qua_buffer, qua_buffer+rec.quality_len+translation, rec.quality);

	if (use_const_delta)
	{
		rec.sequence[++rec.sequence_len] = 0;
		rec.quality[++rec.quality_len] = 0;
	}
}

// ********************************************************************************************
void Superblock::UnDeltaRecord(FastqRecord& rec, std::vector<uint32>& dna_occ,
	bool use_const_delta, bool no_seq_begin)
{
	static const char delta_A[] = {'N', 'N', 'A', 'C', 'G', 'T'};
	static const char delta_C[] = {'N', 'N', 'C', 'A', 'T', 'G'};
	static const char delta_G[] = {'N', 'N', 'G', 'T', 'A', 'C'};
	static const char delta_T[] = {'N', 'N', 'T', 'G', 'C', 'A'};

	const uint32 translation = (uint32)use_const_delta;
	const char* last_matrix = delta_A;

	uchar symbol;
	if (!no_seq_begin)
	{
		symbol = rec.sequence[0];				//:TODO: analyze case when CONST DELTA && NO SEQ BEGIN
		dna_occ[symbol]++;
	}
	else
	{
		symbol = 'A';
		my_assert(use_const_delta == false);
	}
	
	uint32 k = 1 - (uint32)no_seq_begin;
	for ( ; k < rec.sequence_len; ++k)
	{
		switch (symbol)
		{
			case 'A': last_matrix = delta_A; break;
			case 'C': last_matrix = delta_C; break;
			case 'G': last_matrix = delta_G; break;
			case 'T': last_matrix = delta_T; break;
			case 'N': // symbol undefined/error, use previous valid symbol matrix
			default: break;
		}
		symbol = last_matrix[rec.sequence[k]-'.'];
		my_assert(symbol =='A' || symbol == 'C' || symbol == 'G' || symbol == 'T' || symbol == 'N');
		dna_occ[symbol]++;

		rec.sequence[k-translation] = symbol;
		rec.quality[k-translation] = rec.quality[k];
	}
	
	for ( ; k < rec.quality_len; ++k)
	{
		rec.quality[k-translation] = rec.quality[k];
	}

	rec.sequence_len -= translation;
	rec.quality_len -= translation;
	rec.sequence[rec.sequence_len] = 0;
	rec.quality[rec.quality_len] = 0;
}


#endif

