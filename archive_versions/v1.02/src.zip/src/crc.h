/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/

#ifndef _CRC_H
#define _CRC_H

#include "defs.h"
#include <vector>

// ********************************************************************************************
//
// ********************************************************************************************
class Crc32Hasher	// CRC32 LSB
{
	uint32 polynomial;
	uint32 crc;
	std::vector<uchar> lookup_table;

	void FillLookupTable()
	{
		lookup_table[0] = 0;
		for (uint32 i = 1; i < 256; ++i)
		{
			uint32 h = i;
			for (uint32 j = 0; j < 8; ++j)
			{
				if (h & 1)
				{
					h = polynomial ^ (h >> 1);
				}
				else
				{
					h >>= 1;
				}
			}
			lookup_table[i] = (uchar)h;
		}
	}

public:
	Crc32Hasher(uint32 polynomial = 0xEDB88320, uint32 seed = 0xFFFFFFFF)
		:	polynomial(polynomial)
		,	crc(seed)
	{
		lookup_table.resize(256);
		FillLookupTable();
	}

	const std::vector<uchar>& GetLookupTable() const
	{
		return lookup_table;
	}

	void UpdateCrc(uchar c)
	{
		crc = (crc >> 8) ^ lookup_table[(c ^ crc) & 0xFF];
	}

	void UpdateCrc(const uchar* str, uint32 len)
	{
		for (uint32 i = 0; i < len; ++i)
		{
			UpdateCrc(str[i]);
		}
	}

	uint32 GetHash() const
	{
		return crc ^ 0xFFFFFFFF;
	}

	void Reset(uint32 polynomial = 0xEDB88320, uint32 seed = 0xFFFFFFFF)
	{
		if (polynomial != polynomial)
		{
			polynomial = polynomial;
			FillLookupTable();
		}
		crc = seed;
	}

	static uint32 ComputeHash(const std::string& str)
	{
		return Crc32Hasher::ComputeHash((const uchar*)str.c_str(), (uint32)str.length());
	}

	static uint32 ComputeHash(const uchar* arr, uint32 len)
	{
		static Crc32Hasher crc;
		my_assert(arr != NULL);

		crc.Reset();
		for (uint32 i = 0; i < len; ++i)
		{
			crc.UpdateCrc(arr[i]);
		}
		return crc.GetHash();
	}
};

#endif
