/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/
#ifndef _PY_COMPRESSOR_H
#define _PY_COMPRESSOR_H

#include "py_base.h"
#include "compressor.h"

namespace pydsrc
{

// ********************************************************************************************
//
// ********************************************************************************************
class PyCompressor	// a pure wrapper for C+++ Compressor
{
public:
	PyCompressor() : compressor(std::cout, err_stream) {}
	~PyCompressor() {}

	void Compress(const char* file_in, const char* file_out)
	{
		TryExecute(compressor.Compress(file_in, file_out)); 
	}

	void Decompress(const char* file_in, const char* file_out)
	{
		TryExecute(compressor.Decompress(file_in, file_out)); 
	}

	void ExtractRecord(const char* file_in, const char* file_out, uint64 rec_id)
	{
		TryExecute(compressor.ExtractRecord(file_in, file_out, rec_id)); 
	}

	void ExtractRange(const char* file_in, const char* file_out, py::list& rec_ids)
	{
		std::vector<uint64> ids = list_to_vector<uint64>(rec_ids);
		TryExecute(compressor.ExtractRange(file_in, file_out, ids));
	}

	VerboseLevel GetVerboseLevel() const
	{
		return (VerboseLevel)compressor.GetVerboseLevel(); 
	}
	void SetVerboseLevel(VerboseLevel level)
	{
		TryExecute(compressor.SetVerboseLevel((uint32)level)); 
	}

	bool IsCrc32Checking() const 
	{
		return compressor.IsCrc32Checking(); 
	}
	void SetCrc32Checking(bool state) 
	{
		TryExecute(compressor.SetCrc32Checking(state)); 
	}

	bool IsLzMatching() const 
	{
		return compressor.IsLzMatching(); 
	}
	void SetLzMatching(bool lz) 
	{
		TryExecute(compressor.SetLzMatching(lz)); 
	}
	uint32 GetLzMemorySize() const 
	{
		return compressor.GetLzMemorySize(); 
	}
	void SetLzMemorySize(uint32 lz_mem) 
	{
		TryExecute(compressor.SetLzMemorySize(lz_mem)); 
	}

#if !(FEATURE_DISABLED_IN_V_100)
	void SetLzCompressionLevel(LzCompressionLevel lz_lvl) 
	{ 
		TryExecute(compressor.SetLzCompressionLevel((uint32)lz_lvl)); 
	}
	LzCompressionLevel GetLzCompressionLevel() const 
	{
		return (LzCompressionLevel)compressor.GetLzCompressionLevel(); 
	}
#endif

private:
	Compressor compressor;
	std::ostringstream err_stream;

	void TryExecute(bool val)
	{
		if (!val)
		{
			PyException ex(err_stream.str());
			err_stream.str("");
			err_stream.clear();
			throw ex;
		}
	}

	// no assign operator and copy ctor
	PyCompressor& operator=(const PyCompressor& ) {}
	PyCompressor(const PyCompressor& ) {}
};

}

#endif
