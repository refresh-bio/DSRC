/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/
#include "defs.h"
#include "fastq.h"
#include <algorithm>

// ********************************************************************************************
FastqRecord::FastqRecord(const FastqRecord& x) 
	:	title_len(x.title_len)
	,	title_size(x.title_size)
	,	sequence_len(x.sequence_len)
	,	sequence_size(x.sequence_size)
	,	plus_len(x.plus_len)
	,	plus_size(x.plus_size)
	,	quality_len(x.quality_len)
	,	quality_size(x.quality_size)
	,	rec_th_len(x.rec_th_len)
	,	no_of_fields(x.no_of_fields)
	,	lz_inserted(x.lz_inserted)
	,	sequence_breaks(NULL)
	,	quality_breaks(NULL)
{
	title = new uchar[title_size+1];
	sequence = new uchar[sequence_size+1];
	plus = new uchar[plus_size+1];
	quality = new uchar[quality_size+1];

	std::copy(x.title, x.title+title_len+1, title);
	std::copy(x.sequence, x.sequence+sequence_len+1, sequence);
	std::copy(x.plus, x.plus+plus_len+1, plus);
	std::copy(x.quality, x.quality+quality_len+1, quality);

	if (x.sequence_breaks)
		sequence_breaks = new std::vector<int>(x.sequence_breaks->begin(), x.sequence_breaks->end());

	if (x.quality_breaks)
		quality_breaks = new std::vector<int>(x.quality_breaks->begin(), x.quality_breaks->end());
};

// ********************************************************************************************
bool FastqRecord::Set(const FastqRecord &x)
{
	if (title_size < x.title_len+1)
	{
		delete[] title;
		title_len = x.title_len;
		title_size = title_len+1;
		title = new uchar[title_size+1];
	}
	else
	{
		title_len = x.title_len;
	}
	std::copy(x.title, x.title+title_len+1, title);

	if (sequence_size < x.sequence_len+1)
	{
		delete[] sequence;
		sequence_len = x.sequence_len;
		sequence_size = sequence_len+1;
		sequence = new uchar[sequence_size+1];
	}
	else
	{
		sequence_len = x.sequence_len;
	}
	std::copy(x.sequence, x.sequence+sequence_len+1, sequence);

	if (plus_size < x.plus_len+1)
	{
		delete[] plus;
		plus_len = x.plus_len;
		plus_size = plus_len+1;
		plus = new uchar[plus_size+1];
	}
	else
	{
		plus_len = x.plus_len;
	}
	std::copy(x.plus, x.plus+plus_len+1, plus);

	if (quality_size < x.quality_len+1)
	{
		delete[] quality;
		quality_len = x.quality_len;
		quality_size = quality_len+1;
		quality = new uchar[quality_size+1];
	}
	else
	{
		quality_len = x.quality_len;
	}
	std::copy(x.quality, x.quality+quality_len+1, quality);

	rec_th_len   = x.rec_th_len;
	no_of_fields = x.no_of_fields;
	lz_inserted  = x.lz_inserted;

	if (x.sequence_breaks)
		sequence_breaks = new std::vector<int>(x.sequence_breaks->begin(), x.sequence_breaks->end());
	else
		sequence_breaks = NULL;

	if (x.quality_breaks)
		quality_breaks = new std::vector<int>(x.quality_breaks->begin(), x.quality_breaks->end());
	else
		quality_breaks = NULL;

	return true;
}

// ********************************************************************************************
void FastqRecord::Reset()
{
	title_len = 0;
	sequence_len = 0;
	plus_len = 0;
	quality_len = 0;
	rec_th_len = 0;
	no_of_fields = 0;
	lz_inserted = false;

	if (sequence_breaks)
	{
		delete sequence_breaks;
		sequence_breaks	   = NULL;
	}

	if (quality_breaks)
	{
		delete quality_breaks;
		quality_breaks = NULL;
	}
}

// ********************************************************************************************
//
// ********************************************************************************************
AmbCodes::AmbCodes()
{
	using std::fill_n;

	fill_n(trans_amb_codes, 256, 0);
	trans_amb_codes['Y'] = 2;
	trans_amb_codes['R'] = 3;
	trans_amb_codes['W'] = 4;
	trans_amb_codes['S'] = 5;
	trans_amb_codes['K'] = 6;
	trans_amb_codes['M'] = 7;
	trans_amb_codes['D'] = 8;
	trans_amb_codes['V'] = 9;
	trans_amb_codes['H'] = 10;
	trans_amb_codes['B'] = 11;
	trans_amb_codes['N'] = 12;
	trans_amb_codes['X'] = 13;
	trans_amb_codes['U'] = 14;
	trans_amb_codes['.'] = 15;
	trans_amb_codes['-'] = 16;
	trans_amb_codes['A'] = 1;
	trans_amb_codes['C'] = 1;
	trans_amb_codes['T'] = 1;
	trans_amb_codes['G'] = 1;

	fill_n(untrans_amb_codes+128+ 0*8, 8, 'Y');
	fill_n(untrans_amb_codes+128+ 1*8, 8, 'R');
	fill_n(untrans_amb_codes+128+ 2*8, 8, 'W');
	fill_n(untrans_amb_codes+128+ 3*8, 8, 'S');
	fill_n(untrans_amb_codes+128+ 4*8, 8, 'K');
	fill_n(untrans_amb_codes+128+ 5*8, 8, 'M');
	fill_n(untrans_amb_codes+128+ 6*8, 8, 'D');
	fill_n(untrans_amb_codes+128+ 7*8, 8, 'V');
	fill_n(untrans_amb_codes+128+ 8*8, 8, 'H');
	fill_n(untrans_amb_codes+128+ 9*8, 8, 'B');
	fill_n(untrans_amb_codes+128+10*8, 8, 'N');
	fill_n(untrans_amb_codes+128+11*8, 8, 'X');
	fill_n(untrans_amb_codes+128+12*8, 8, 'U');
	fill_n(untrans_amb_codes+128+13*8, 8, '.');
	fill_n(untrans_amb_codes+128+14*8, 8, '-');
}

// ********************************************************************************************
bool AmbCodes::Transfer_Internal(uchar* sequence, uint32& sequence_len, uchar* quality, uint32& /*qua_len*/)
{
	uint32 i, j, tmp;

	// Check whether make transfer
	bool make_transfer = false;
	bool possible_transfer = true;
	for (i = 0; i < sequence_len; ++i)
	{
		if (trans_amb_codes[sequence[i]] == 1)
			continue;

		if (trans_amb_codes[sequence[i]] == 0)
		{
			possible_transfer = false;
			break;
		}
		else
		{
			if (quality[i] < 33 || quality[i] > 40)
			{
				possible_transfer = false;
				break;
			}
			make_transfer = true;
		}
	}

	if (!(make_transfer && possible_transfer))
		return false;

	for (i = j = 0; i < sequence_len; ++i)
	{
		if ((tmp = trans_amb_codes[sequence[i]]) > 1)
		{
			quality[i] = (uchar)(128 + (tmp << 3) - 16 + (quality[i] - 33));		// 33 ?
		}
		else
		{
			sequence[j++] = sequence[i];
		}
	}
	sequence_len = j;
	//sequence[j] = '\0';
	return true;
}

// ********************************************************************************************
bool AmbCodes::UnTransfer_Internal(uchar* sequence, uint32& sequence_len, uchar* quality, uint32& qua_len)
{
	int32 i = sequence_len-1;
	int32 j = qua_len-1;

	for (; j >= 0; --j)
	{
		if (quality[j] >= 128)
		{
			sequence[j] = untrans_amb_codes[quality[j]];
			quality[j] = 33 + (quality[j] & 7);
		}
		else
		{
			sequence[j] = sequence[i--];
		}
	}
	sequence_len = qua_len;
	return true;
}
