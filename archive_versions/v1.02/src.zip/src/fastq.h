/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/
#ifndef _FASTQ_H
#define _FASTQ_H

#include "defs.h"
#include "utils.h"
#include <vector>

// ********************************************************************************************
//
// ********************************************************************************************
struct FastqRecord 
{
	const static int32 DEFAULT_FIELD_SIZE = 32;

	uchar *title;
	uint32 title_len;
	uint32 title_size;

	uchar *sequence;
	uint32 sequence_len;
	uint32 sequence_size;

	uchar *plus;
	uint32 plus_len;
	uint32 plus_size;

	uchar *quality;
	uint32 quality_len;
	uint32 quality_size;

	uint32 rec_th_len;
	uint32 no_of_fields;
	bool lz_inserted;
	std::vector<int32> *sequence_breaks;
	std::vector<int32> *quality_breaks;

	inline FastqRecord();
	inline ~FastqRecord();

	FastqRecord(const FastqRecord& x);

	FastqRecord& operator=(const FastqRecord &x)
	{
		Set(x);
		return *this;
	};

	inline bool AppendTitle(uchar *str, uint32 len);
	inline bool AppendTitle(uchar c);

	bool Extend(uchar *&str, uint32 &size)
	{
		return utils::extend_string(str, size);
	}

	bool ExtendTo(uchar *&str, uint32 &size, uint32 new_size)
	{
		return utils::extend_string_to(str, size, new_size);
	}

	bool Set(const FastqRecord &x);
	void Reset();
};


// ********************************************************************************************
FastqRecord::FastqRecord()
	:	title_len(0)			// perform one big memset 0
	,	title_size(FastqRecord::DEFAULT_FIELD_SIZE)
	,	sequence_len(0)
	,	sequence_size(FastqRecord::DEFAULT_FIELD_SIZE)
	,	plus_len(0)
	,	plus_size(FastqRecord::DEFAULT_FIELD_SIZE)
	,	quality_len(0)
	,	quality_size(FastqRecord::DEFAULT_FIELD_SIZE)
	,	rec_th_len(0)
	,	no_of_fields(0)
	,	lz_inserted(false)
	,	sequence_breaks(NULL)
	,	quality_breaks(NULL)
{
	title = new uchar[title_size+1];
	sequence = new uchar[sequence_size+1];
	plus = new uchar[plus_size+1];		//TODO: plus only "1"
	quality = new uchar[quality_size+1];
};

// ********************************************************************************************
FastqRecord::~FastqRecord()
{
	delete[] title;
	delete[] sequence;
	delete[] plus;
	delete[] quality;

	if (sequence_breaks)
		delete sequence_breaks;
	if (quality_breaks)
		delete quality_breaks;
};

// ********************************************************************************************
bool FastqRecord::AppendTitle(uchar *str, uint32 len)
{
	if (title_len + len + 1 >= title_size)
		utils::extend_string(title, title_size);

	std::copy(str, str+len, title+title_len);
	title_len += len;

	return true;
}

// ********************************************************************************************
bool FastqRecord::AppendTitle(uchar c)
{
	if (title_len + 1 >= title_size)
		utils::extend_string(title, title_size);
	title[title_len++] = c;

	return true;
}

// ********************************************************************************************
//
// ********************************************************************************************
class AmbCodes
{
	uchar trans_amb_codes[256];
	uchar untrans_amb_codes[256];

	AmbCodes();
	bool Transfer_Internal(uchar* sequence, uint32& sequence_len, uchar* quality, uint32& qua_len);
	bool UnTransfer_Internal(uchar* sequence, uint32& sequence_len, uchar* quality, uint32& qua_len);

	static AmbCodes& GetSingleton()
	{
		static AmbCodes singleton;
		return singleton;
	}

public:
	static void Transfer(uchar* sequence, uint32& sequence_len, uchar* quality, uint32& qua_len)
	{
		if (GetSingleton().Transfer_Internal(sequence, sequence_len, quality, qua_len))
		{
			sequence[sequence_len] = '\0';
		}
	}

	static void UnTransfer(uchar* sequence, uint32& sequence_len, uint32& sequence_size, uchar* quality, uint32& qua_len, uint32& qua_size)
	{
		if (sequence_len == qua_len)
			return;

		if (sequence_size < qua_size)
			utils::extend_string_to(sequence, sequence_size, qua_size);

		GetSingleton().UnTransfer_Internal(sequence, sequence_len, quality, qua_len);
	}

	static void Transfer(std::vector<uchar>& sequence, std::vector<uchar>& qua)
	{
		uint32 sequence_len = (uint32)sequence.size();
		uint32 qua_len = (uint32)qua.size();
		if (GetSingleton().Transfer_Internal(&sequence[0], sequence_len, &qua[0], qua_len))
		{
			sequence.resize(sequence_len);
		}
	}

	static void UnTransfer(std::vector<uchar>& sequence, std::vector<uchar>& qua)
	{
		if (sequence.size() == qua.size())
			return;

		uint32 sequence_len = (uint32)sequence.size();
		uint32 qua_len = (uint32)sequence.size();
		sequence.resize(qua.size());

		GetSingleton().UnTransfer_Internal(&sequence[0], sequence_len, &qua[0], qua_len);
	}

	static void Transfer(FastqRecord& rec)
	{
		if (GetSingleton().Transfer_Internal(rec.sequence, rec.sequence_len, rec.quality, rec.quality_len))
		{
			rec.sequence[rec.sequence_len] = '\0';
		}
	}

	static void UnTransfer(FastqRecord& rec)
	{
		if (rec.sequence_len == rec.quality_len)
			return;

		if (rec.sequence_size < rec.quality_size)
			utils::extend_string_to(rec.sequence, rec.sequence_size, rec.quality_size);

		GetSingleton().UnTransfer_Internal(rec.sequence, rec.sequence_len, rec.quality, rec.quality_len);
	}
};

#endif
