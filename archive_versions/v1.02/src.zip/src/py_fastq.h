/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/
#ifndef _PY_FASTQ_H
#define _PY_FASTQ_H

#include "py_base.h"
#include "fastq.h"

namespace pydsrc
{

// ********************************************************************************************
//
// ********************************************************************************************
struct PyFastqRecord
{
	std::vector<uchar> title, sequence, plus, quality;
	std::vector<int32> sequence_breaks, quality_breaks;

	//uint32 rec_len;
	uint32 rec_th_len;
	bool lz_inserted;
	uint32 no_of_fields;

	inline PyFastqRecord();
	~PyFastqRecord() {}

	bool Import(const FastqRecord& rec);
	bool Export(FastqRecord& rec) const;
	bool Check(const FastqRecord& rec, bool full = false) const;		// for debug purposes
};

// ********************************************************************************************
PyFastqRecord::PyFastqRecord()
	:	rec_th_len(0)
	,	no_of_fields(0)
	,	lz_inserted(false)
{
	title.reserve(FastqRecord::DEFAULT_FIELD_SIZE);
	sequence.reserve(FastqRecord::DEFAULT_FIELD_SIZE);
	plus.reserve(FastqRecord::DEFAULT_FIELD_SIZE);
	quality.reserve(FastqRecord::DEFAULT_FIELD_SIZE);
}

} // pydsrc

#endif
