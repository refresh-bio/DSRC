/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/
#include "py_base.h"
#include "py_fastq.h"
#include "py_fastq_file.h"
#include "py_dsrc_file.h"
#include "py_compressor.h"

#include <boost/python/module.hpp>
#include <boost/python/class.hpp>
#include <boost/python/def.hpp>
#include <boost/python/enum.hpp>
#include <boost/python/exception_translator.hpp>
#include <boost/python/suite/indexing/vector_indexing_suite.hpp>

namespace pydsrc
{
// define DSRC Python wrapper interace

BOOST_PYTHON_MODULE(pydsrc)
{
	py::register_exception_translator<PyException>(&PyException::translate);

	py::class_<std::vector<unsigned char> >("array_uc8")
		.def(py::vector_indexing_suite<std::vector<unsigned char> >())
		;

	py::class_<std::vector<int32> >("array_i32")
		.def(py::vector_indexing_suite<std::vector<int32> >())
		;

	py::enum_<VerboseLevel>("VerboseLevel")
		.value("VERBOSE_NONE", VERBOSE_NONE)
		.value("VERBOSE_ERRORS", VERBOSE_ERRORS)
		.value("VERBOSE_WARNINGS", VERBOSE_WARNINGS)
		.value("VERBOSE_INFO", VERBOSE_INFO)
		.export_values()
		;

#if !(FEATURE_DISABLED_IN_V_100)
	py::enum_<LzCompressionLevel>("LzCompressionLevel")
		.value("LZ_LEVEL_1", LZ_LEVEL_1)
		.value("LZ_LEVEL_2", LZ_LEVEL_2)
		.value("LZ_LEVEL_3", LZ_LEVEL_3)
		.export_values()
		;
#endif

	py::def("to_array_uc8", list_to_vector<uchar>);
	py::def("to_array_i32", list_to_vector<int32>);
	py::def("to_list_uc8", vector_to_list<uchar>);
	py::def("to_list_i32", vector_to_list<int32>);

	py::class_<PyFastqRecord>("FastqRecord")
		// data fields
		.def_readwrite("Title", &PyFastqRecord::title)
		.def_readwrite("sequence", &PyFastqRecord::sequence)
		.def_readwrite("Plus", &PyFastqRecord::plus)
		.def_readwrite("Quality", &PyFastqRecord::quality)
#if 0
		.def_readonly("sequenceBreaks", &PyFastqRecord::sequenceBreaks)
		.def_readonly("QualityBreaks", &PyFastqRecord::qualityBreaks)
		.def_readonly("RecordTruncHashLength", &PyFastqRecord::truncHashLen)
		.def_readonly("LzInserted", &PyFastqRecord::lzInserted)
		.def_readonly("FieldsNum", &PyFastqRecord::fieldsNum)
#endif
		;

	py::class_<PyFastqFile, boost::noncopyable>("FastqFile")
		// main file operations - from FastqFile
		.def("Open", &PyFastqFile::Open)
		.def("Create", &PyFastqFile::Create)
		.def("Close", &PyFastqFile::Close)
		// record read/write - from PyFastqFile
		.def("ReadNextRecord", &PyFastqFile::ReadNextRecord)
		.def("WriteRecord", &PyFastqFile::WriteRecord)
		// properties
		.add_property("Size", &PyFastqFile::GetFileSize)
		.add_property("Position", &PyFastqFile::GetFilePos)
		.add_property("Eof", &PyFastqFile::Eof)
		.add_property("Crc32Checking", &PyFastqFile::IsCrc32Checking, &PyFastqFile::SetCrc32Checking)
		.add_property("FileCrc32Hash", &PyFastqFile::GetFileCrc32Hash)
		.add_property("RecordsCrc32Hash", &PyFastqFile::GetRecordsCrc32Hash)
		;

	py::class_<PyDsrcFile, boost::noncopyable>("DsrcFile")
		// main methods
		.def("StartCompress", &PyDsrcFile::StartCompress)
		.def("WriteRecord", &PyDsrcFile::WriteRecord)
		.def("FinishCompress", &PyDsrcFile::FinishCompress)
		.def("StartDecompress", &PyDsrcFile::StartDecompress)
		.def("ReadNextRecord", &PyDsrcFile::ReadNextRecord)
		.def("FinishDecompress", &PyDsrcFile::FinishDecompress)
		.def("StartExtract", &PyDsrcFile::StartExtract)
		.def("ExtractRecord", &PyDsrcFile::ExtractRecord)
		.def("FinishExtract", &PyDsrcFile::FinishExtract)
		.def("Reset", &PyDsrcFile::Reset)
		// properties
		.add_property("LzMatching", &PyDsrcFile::IsLzMatching, &PyDsrcFile::SetLzMatching)
		.add_property("LzMemorySize", &PyDsrcFile::GetLzMemorySize, &PyDsrcFile::SetLzMemorySize)
#if !(FEATURE_DISABLED_IN_V_100)
		.add_property("LzCompressionLevel", &PyDsrcFile::GetLzCompressionLevel, &PyDsrcFile::SetLzCompressionLevel)
		.add_property("SuperblockSize", &PyDsrcFile::GetSuperblockSize, &PyDsrcFile::SetSuperblockSize)
		.add_property("BlockSize", &PyDsrcFile::GetBlockSize, &PyDsrcFile::SetBlockSize)
#endif
		.add_property("Position", &PyDsrcFile::GetFilePos)
		.add_property("Size", &PyDsrcFile::GetFileSize)
		;

	py::class_<PyCompressor, boost::noncopyable>("Compressor")
		// main methods
		.def("Compress", &PyCompressor::Compress)
		.def("Decompress", &PyCompressor::Decompress)
		.def("ExtractRecord", &PyCompressor::ExtractRecord)
		.def("ExtractRange", &PyCompressor::ExtractRange)
		// properties
		.add_property("VerboseLevel", &PyCompressor::GetVerboseLevel, &PyCompressor::SetVerboseLevel)
		.add_property("LzMatching", &PyCompressor::IsLzMatching, &PyCompressor::SetLzMatching)
		.add_property("LzMemorySize", &PyCompressor::GetLzMemorySize, &PyCompressor::SetLzMemorySize)
#if !(FEATURE_DISABLED_IN_V_100)
		.add_property("LzCompressionLevel", &PyCompressor::GetLzCompressionLevel, &PyCompressor::SetLzCompressionLevel)
		.add_property("SuperblockSize", &PyCompressor::GetSuperblockSize, &PyCompressor::SetSuperblockSize)
		.add_property("BlockSize", &PyCompressor::GetBlockSize, &PyCompressor::SetBlockSize)
#endif
		.add_property("Crc32Checking", &PyCompressor::IsCrc32Checking, &PyCompressor::SetCrc32Checking)
		;

} // BOOST

} // pydsrc
