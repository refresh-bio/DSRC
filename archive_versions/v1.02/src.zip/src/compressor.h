/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/
#ifndef _COMPRESSOR_H
#define _COMPRESSOR_H

#include "defs.h"
#include "fastq.h"
#include "fastq_file.h"
#include "dsrc_file.h"
#include <iostream>

// ********************************************************************************************
//
// ********************************************************************************************
class Compressor
{
public:
	Compressor(std::ostream& _log_stream = std::cout, std::ostream& _err_stream = std::cerr);
	~Compressor();

	bool Compress(const char *in_file_name, const char *out_file_name);
	bool Decompress(const char *in_file_name, const char *out_file_name);
	bool ExtractRecord(const char *in_file_name, const char *out_file_name, uint64 rec_id);
	bool ExtractRange(const char *in_file_name, const char *out_file_name, std::vector<uint64> rec_ids);

	bool IsCrc32Checking() const { return check_crc32; }
	bool SetCrc32Checking(bool state);

	int32 GetVerboseLevel() const { return verbose_level;}
	bool SetVerboseLevel(int32 level) { verbose_level = level; return true; }

	bool SetLzMatching(bool lz);
	bool IsLzMatching() const { return dsrc_file.IsLzMatching(); }

	bool SetLzMemorySize(uint32 lz_mem);
	uint32 GetLzMemorySize() const { return dsrc_file.GetLzMemorySize(); }

#if !(FEATURE_DISABLED_IN_V_100)
	bool SetLzCompressionLevel(uint32 level);
	uint32 GetLzCompressionLevel() const { return dsrc_file.GetLzCompressionLevel(); }
	bool SetSuperblockSize(uint32 sb_size);
	uint32 GetSuperblockSize() const { return dsrc_file.GetSuperblockSize(); }
	bool SetBlockSize(uint32 block_size);
	uint32 GetBlockSize() const { return dsrc_file.GetBlockSize(); }
#endif

	std::ostream& GetLogStream() { return log_stream; }
	std::ostream& GetErrorStream() { return err_stream; }

private:
	DsrcFile dsrc_file;
	FastqFile fastq_file;
	FastqCrc32OutStream crc_buffer;

	std::ostream& log_stream;
	std::ostream& err_stream;

	bool check_crc32;
	int32 verbose_level;

	// no assign operator
	Compressor& operator=(const Compressor& ) {return *this;}

	bool IsVerboseLevel(int32 level)
	{
		return (verbose_level & level) == level;
	}
};

#endif
