/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/

#ifndef _MAIN_H
#define _MAIN_H

#include "compressor.h"

enum TaskSelect
{
	TASK_COMPRESS,
	TASK_DECOMPRESS,
	TASK_EXTRACT
};

union Param
{
	uint64 par64;
	uint32 par32;
};

// ********************************************************************************************
int main(int argc, char* argv[]);
bool parse_params(int argc, char* argv[]);
bool run_dsrc(int argc, char* argv[]);

void usage();

#endif
