/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/
#include "py_fastq_file.h"

namespace pydsrc
{

// ********************************************************************************************
bool PyFastqFile::ReadNextRecord(PyFastqRecord &rec)
{
	if (GetMode() != FILE_MODE_READ)
		throw PyException("Cannot read data in non-read mode.");

	if (!ReadTitle(rec) || !Readsequence(rec) || !ReadPlus(rec) || !ReadQuality(rec))
		return false;

	if (check_crc32)
	{
		records_crc.UpdateCrc(&rec.title[0], rec.title.size());
		records_crc.UpdateCrc(&rec.sequence[0], rec.sequence.size());
		records_crc.UpdateCrc(&rec.plus[0], rec.plus.size());
		records_crc.UpdateCrc(&rec.quality[0], rec.quality.size());
	}

	//TransferAmbCodes(rec); // moved internally to Block
	return true;
}

// ********************************************************************************************
bool PyFastqFile::WriteRecord(PyFastqRecord &rec)
{
	if (GetMode() != FILE_MODE_WRITE)
		throw PyException("Cannot write data in non-write mode");

	//UnTransferAmbCodes(rec);	// moved internally to DsrcFile

	if (   !Puts(rec.title) || !Puts(rec.sequence, rec.sequence_breaks)
		|| !Puts(rec.plus)  || !Puts(rec.quality, rec.quality_breaks))
		return false;

	if (check_crc32)
	{
		records_crc.UpdateCrc(&rec.title[0], rec.title.size());
		records_crc.UpdateCrc(&rec.sequence[0], rec.sequence.size());
		records_crc.UpdateCrc(&rec.plus[0], rec.plus.size());
		records_crc.UpdateCrc(&rec.quality[0], rec.quality.size());
	}

	return true;
}

// ********************************************************************************************
bool PyFastqFile::ReadTitle(PyFastqRecord &rec)
{
	int32 c, i = 0;
	rec.title.clear();

	for (;;)
	{
		c = Getc();
		if (c == EOF)
			break;

		if (c != '\n' && c != '\r')
		{
			rec.title.push_back(c);
			++i;
		}
		else if (i > 0)
		{
			break;
		}
	}

	return i > 0 && rec.title[0] == '@';
}

// ********************************************************************************************
bool PyFastqFile::Readsequence(PyFastqRecord &rec)
{
	int32 c, i = 0;
	uint32 last_eol_pos = 0;
	uint32 sequence_break = 0;

	rec.sequence.clear();
	rec.sequence_breaks.clear();
	for (;;)
	{
		c = Peek();
		if (c == '+')
			break;

		Getc();
		if (c == EOF)
			break;

		if (c != '\n' && c != '\r')
		{
			rec.sequence.push_back(c);
			++i;
		}
		else
		{
			if (last_eol_pos != i)
			{
				if (sequence_break)
				{
					rec.sequence_breaks.push_back(sequence_break);
				}
				else
				{
					sequence_break = i - last_eol_pos;
				}
				last_eol_pos = i;
			}
		}
	}

	return true;
}

// ********************************************************************************************
// Todo: Verify (plus[1]+ == title)
bool PyFastqFile::ReadPlus(PyFastqRecord &rec)
{
	int32 c, i = 0;

	rec.plus.clear();
	for (;;)
	{
		c = Getc();
		if (c == EOF)
			break;

		if (c != '\n' && c != '\r')
		{
			rec.plus.push_back(c);
			++i;
		}
		else if (i > 0)
		{
			break;
		}
	}

	return i > 0;
}

// ********************************************************************************************
bool PyFastqFile::ReadQuality(PyFastqRecord &rec)
{
	int32 c, i = 0;
	uint32 last_eol_pos = 0;

	rec.quality.clear();
	rec.quality_breaks.clear();
	while (i < rec.sequence.size())
	{
		c = Getc();
		if (c == EOF)
			break;

		if (c != '\n' && c != '\r')
		{
			rec.quality.push_back(c);
			++i;
		}
		else
		{
			if (last_eol_pos != i)
			{
				rec.quality_breaks.push_back(i - last_eol_pos);
				last_eol_pos = i;
			}
		}
	}

	return (i == rec.sequence.size());
}

} // pydsrc
