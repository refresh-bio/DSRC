/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/
#ifndef _FASTQ_FILE_H
#define _FASTQ_FILE_H

#include "defs.h"
#include "fastq.h"
#include "crc.h"
#include <vector>

// ********************************************************************************************
//
// ********************************************************************************************
class FastqFile
{
public:
	FastqFile();
	~FastqFile();

	bool Open(const char *file_name);
	bool Create(const char *file_name);
	bool Close();

	inline bool ReadNextRecord(FastqRecord &rec);
	inline bool WriteRecord(const FastqRecord &rec);

	bool Eof() { return io_eof; }
	int64 GetFileSize() { return file_size; }
	int64 GetFilePos() { return file_pos; }
	FileModeEnum GetMode() const { return file_mode; }

	uint32 GetFileCrc32Hash() const { return file_crc.GetHash(); }
	uint32 GetRecordsCrc32Hash() const { return records_crc.GetHash(); }

	bool IsCrc32Checking() const {return check_crc32;}
	inline bool SetCrc32Checking(bool check);

protected:
	enum Indicators
	{
		FILE_EOF = -1
	};
	
	Crc32Hasher file_crc;
	Crc32Hasher records_crc;
	bool check_crc32;

	inline int32 Getc();
	inline int32 Peek();
	inline void UnGetc();
	inline bool Putc(uchar c);
	inline bool Puts(const uchar *str, const uint32 len, bool eol = true);
	inline bool Puts(const uchar *str, const uint32 len, std::vector<int> *line_breaks);

	bool ReadTitle(FastqRecord &rec);
	bool ReadPlus(FastqRecord &rec);
	bool Readsequence(FastqRecord &rec);
	bool ReadQuality(FastqRecord &rec);

private:
	static const int32 IO_BUFFER_SIZE = 1 << 20;

	FILE *file;
	int64 file_pos;
	int64 file_size;
	uchar *io_buffer;
	int32 io_buffer_pos;
	int32 io_buffer_size;
	FileModeEnum file_mode;
	bool io_eof;

	bool ReadBuffer();
	bool WriteBuffer();
};

// ********************************************************************************************
int32 FastqFile::Getc()
{
	int32 c = Peek();
	if (c != FILE_EOF)
	{
		file_pos++;
		if (++io_buffer_pos >= IO_BUFFER_SIZE)
			io_buffer_pos = -1;

		if (check_crc32)
		{
			file_crc.UpdateCrc((uchar)c);
		}
	}

	return c;
}

// ********************************************************************************************
int32 FastqFile::Peek()
{
	if (io_eof)
		return FILE_EOF;

	if (io_buffer_pos == -1)
	{
		if (!ReadBuffer())
			return FILE_EOF;
	}

	if (io_buffer_pos >= io_buffer_size)
	{
		io_eof = true;
		return FILE_EOF;
	}

	return io_buffer[io_buffer_pos];
}

// ********************************************************************************************
void FastqFile::UnGetc()
{
	if (io_eof)
		return;

	if (io_buffer_pos == -1)
		io_buffer_pos = IO_BUFFER_SIZE-1;
	else
		io_buffer_pos--;
	file_pos--;
}

// ********************************************************************************************
bool FastqFile::Putc(uchar c)
{
	if (io_buffer_pos == IO_BUFFER_SIZE)
	{
		if (!WriteBuffer())
			return false;
	}
	io_buffer[io_buffer_pos++] = c;
	file_pos++;

	if (check_crc32)
	{
		file_crc.UpdateCrc(c);
	}

	return true;
}

// ********************************************************************************************
bool FastqFile::Puts(const uchar *str, const uint32 len, bool eol)
{
	for (uint32 i = 0; i < len; ++i)
		Putc(str[i]);
	if (eol)
		Putc('\n');

	return true;
}

// ********************************************************************************************
bool FastqFile::Puts(const uchar *str, const uint32 len, std::vector<int> *line_breaks)
{
	uint32 j = 0;
	uint32 k = 0;
	uint32 lb_size = 0;

	if (line_breaks)
	{
		lb_size = (uint32) line_breaks->size();
	}

	if (!lb_size)
	{
		j = (uint32) -1;
	}
	else
	{
		j = (*line_breaks)[k++];
	}

	for (uint32 i = 0; i < len; ++i)
	{
		if (i == j)
		{
			if (k+1 < lb_size)
			{
				j = j + (*line_breaks)[k++];
			}
			else
			{
				j = (uint32) -1;
			}
			Putc('\n');
		}
		Putc(str[i]);
	}
	Putc('\n');

	return true;
}

// ********************************************************************************************
bool FastqFile::ReadNextRecord(FastqRecord &rec)
{
	if (file_mode != FILE_MODE_READ)
		return false;

	if(!ReadTitle(rec) || !Readsequence(rec) || !ReadPlus(rec) || !ReadQuality(rec))
		return false;

	if (check_crc32)
	{
		records_crc.UpdateCrc(rec.title, rec.title_len);
		records_crc.UpdateCrc(rec.sequence, rec.sequence_len);
		records_crc.UpdateCrc(rec.plus, rec.plus_len);
		records_crc.UpdateCrc(rec.quality, rec.quality_len);
	}

	return true;
}

// ********************************************************************************************
bool FastqFile::WriteRecord(const FastqRecord &rec)
{
	if (file_mode != FILE_MODE_WRITE)
		return false;

	bool r = Puts(rec.title, rec.title_len);
	r &= Puts(rec.sequence, rec.sequence_len, rec.sequence_breaks);
	r &= Puts(rec.plus, rec.plus_len);
	r &= Puts(rec.quality, rec.quality_len, rec.quality_breaks);

	if (check_crc32)	// && r ??
	{
		records_crc.UpdateCrc(rec.title, rec.title_len);
		records_crc.UpdateCrc(rec.sequence, rec.sequence_len);
		records_crc.UpdateCrc(rec.plus, rec.plus_len);
		records_crc.UpdateCrc(rec.quality, rec.quality_len);
	}
	return r;
}

// ********************************************************************************************
bool FastqFile::SetCrc32Checking(bool check)
{ 
	if (file_mode == FILE_MODE_NONE)
		check_crc32 = check;
	return check_crc32 == check;
}


// ********************************************************************************************
//
// ********************************************************************************************
class FastqCrc32OutStream // for CRC32 check only
{
	Crc32Hasher file_crc;
	Crc32Hasher records_crc;

	inline void Putc(uchar c);

	// these could be done using Putc() virtual function and FastqFile
	inline void Puts(const uchar *str, const uint32 len, bool eol = true);
	inline void Puts(const uchar *str, const uint32 len, std::vector<int> *line_breaks);

public:
	void Open()
	{
		file_crc.Reset();
		records_crc.Reset();
	};

	void Close() {};

	inline void WriteRecord(const FastqRecord &rec);

	uint32 GetFileCrc32Hash() const { return file_crc.GetHash(); }
	uint32 GetRecordsCrc32Hash() const { return records_crc.GetHash(); }
};

void FastqCrc32OutStream::WriteRecord(const FastqRecord &rec)
{
	Puts(rec.title, rec.title_len);
	Puts(rec.sequence, rec.sequence_len, rec.sequence_breaks);
	Puts(rec.plus, rec.plus_len);
	Puts(rec.quality, rec.quality_len, rec.quality_breaks);

	records_crc.UpdateCrc(rec.title, rec.title_len);
	records_crc.UpdateCrc(rec.sequence, rec.sequence_len);
	records_crc.UpdateCrc(rec.plus, rec.plus_len);
	records_crc.UpdateCrc(rec.quality, rec.quality_len);

}


// ********************************************************************************************
void FastqCrc32OutStream::Puts(const uchar *str, const uint32 len, bool eol)
{
	for (uint32 i = 0; i < len; ++i)
	{
		Putc(str[i]);
	}
	if (eol)
		Putc('\n');
}


void FastqCrc32OutStream::Putc(uchar c)
{
	// dummy flush
	file_crc.UpdateCrc(c);
}

// ********************************************************************************************
void FastqCrc32OutStream::Puts(const uchar *str, const uint32 len, std::vector<int> *line_breaks)
{
	uint32 j = 0;
	uint32 k = 0;
	uint32 lb_size = 0;

	if (line_breaks)
	{
		lb_size = (uint32) line_breaks->size();
	}

	if (!lb_size)
	{
		j = (uint32) -1;
	}
	else
	{
		j = (*line_breaks)[k++];
	}

	for (uint32 i = 0; i < len; ++i)
	{
		if (i == j)
		{
			if (k+1 < lb_size)
			{
				j = j + (*line_breaks)[k++];
			}
			else
			{
				j = (uint32) -1;
			}
			Putc('\n');
		}
		Putc(str[i]);
	}
	Putc('\n');
}


#endif
