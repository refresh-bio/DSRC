/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/
#include "defs.h"
#include "dsrc_file.h"
#include <algorithm>
#include <string.h>

const uint32 DsrcFile::LZ_LEVEL_SEQ_LENGTH[] = {	LzMatcher::LEVEL_SEQ_LENGTH[0],	// 0 is invalid
													LzMatcher::LEVEL_SEQ_LENGTH[1], 
													LzMatcher::LEVEL_SEQ_LENGTH[2], 
													LzMatcher::LEVEL_SEQ_LENGTH[3],
												};

// ********************************************************************************************
DsrcFile::DsrcFile()
	:	bit_stream()
	,	lz_matcher()
	,	opened(false)
	,	file_mode(FILE_MODE_NONE)
	,	superblock(NULL)
	,	superblock_lz(NULL)
	,	rec_count(0)
	,	sb_count(0)
	,	sb_size(DsrcFile::DEFAULT_SB_SIZE)
	,	block_size(DsrcFile::DEFAULT_BLOCK_SIZE)
	,	ext_cur_sb_id((uint64)-1)
	,	try_lz(false)
	,	lz_max_memory_size(DsrcFile::DEFAULT_LZ_MEMORY_SIZE_MB)
	,	lz_compression_level(DsrcFile::DEFAULT_LZ_COMPRESSION_LEVEL)
	,	is_error(false)
	,	error_msg("")
	,	header_pos(0)
	,	header_sb_count(0)
	,	header_b_count(0)
	,	block_offset_bit_len(0)
{
	sb_file_pos.reserve(1000);
	block_file_pos.reserve(10000);
}

// ********************************************************************************************
DsrcFile::~DsrcFile()
{
	bit_stream.Close();
	
	if (superblock)
		delete superblock;

	if (superblock_lz)
		delete superblock_lz;
}

// ********************************************************************************************
bool DsrcFile::StartCompress(const char* file_name)
{
	if (IsError())
		return false;

	if (!bit_stream.Create(file_name))
	{
		SetError("Cannot create output file");
		return false;
	}

	// Write essential compression parameters
	std::string version = DsrcFile::GetVersionString();
	bit_stream.PutBytes((uchar*)version.c_str(), (int32)(version.length()+1));
	bit_stream.PutWord(0xAA);		// tmp
	bit_stream.PutWord(sb_size);	
	bit_stream.PutWord(block_size);
	bit_stream.PutWord(lz_compression_level);

#if (RESERVE_BYTES_PER_DSRCFILE)
	{
		uchar bytes[DsrcFile::HEADER_RESERVED_BYTES];
		std::fill(bytes, bytes+DsrcFile::HEADER_RESERVED_BYTES, INVALID_BYTE);
		bit_stream.PutBytes(bytes, DsrcFile::HEADER_RESERVED_BYTES);
	}
#endif

	opened = true;
	file_mode = FILE_MODE_WRITE;

	if (superblock && (superblock->GetSuperblockSize() != sb_size || superblock->GetBlockSize() != block_size))
	{
		delete superblock;
		superblock = NULL;
	}

	if (superblock == NULL)
		superblock = new Superblock(sb_size, block_size);
	else
		superblock->Reset();

	if (try_lz)
	{
		lz_matcher.Reset();
		lz_matcher.SetCompressionLevel(lz_compression_level);
	}

	lz_matcher.SetMaxMemory(((uint64) lz_max_memory_size) << 20);

	return true;
}

// ********************************************************************************************
bool DsrcFile::WriteRecord(const FastqRecord &rec)
{
	if (IsError())
		return false;

	if (file_mode != FILE_MODE_WRITE)
	{
		SetError("Invalid compressor state");
		return false;
	}

	if (rec_count % sb_size == 0)
	{
		if (rec_count)
		{
			superblock->Process(bit_stream, lz_matcher, try_lz);
			sb_file_pos.push_back(superblock->GetFilePos());
			block_file_pos.insert(block_file_pos.end(), superblock->GetBlocksFilePos().begin(), superblock->GetBlocksFilePos().end());
		}

		superblock->Reset(rec_count, -1);	
		sb_count++;
	}

	superblock->InsertRecord(rec);
	rec_count++;

	return true;
}

// ********************************************************************************************
bool DsrcFile::FinishCompress()
{
	if (rec_count && !IsError())
	{
		superblock->Process(bit_stream, lz_matcher, try_lz);

		sb_file_pos.push_back(superblock->GetFilePos());
		block_file_pos.insert(block_file_pos.end(), superblock->GetBlocksFilePos().begin(), superblock->GetBlocksFilePos().end());
		block_offset_bit_len = BitStream::BitLength(*max_element(block_file_pos.begin(), block_file_pos.end()));
	}
	else
	{
		block_offset_bit_len = 0;
	}

	// Save data for random access
	uint64 header_pos = bit_stream.GetPos();
	for (uint32 i = 0; i < sb_file_pos.size(); ++i)
	{
		bit_stream.PutDWord(sb_file_pos[i]);
	}
	for (uint32 i = 0; i < block_file_pos.size(); ++i)
	{
		bit_stream.PutBits(block_file_pos[i], block_offset_bit_len);
	}
	bit_stream.FlushPartialWordBuffer();
	bit_stream.PutByte((uchar)block_offset_bit_len);
	bit_stream.PutDWord(sb_file_pos.size());
	bit_stream.PutDWord(block_file_pos.size());
	bit_stream.PutDWord(header_pos);

	rec_count = 0;
	sb_count = 0;

	sb_file_pos.clear();
	block_file_pos.clear();

	file_mode = FILE_MODE_NONE;
	opened = false;

	if (try_lz)
		lz_matcher.Reset();
	
	return bit_stream.Close();
}

// ********************************************************************************************
bool DsrcFile::StartDecompress(const char* file_name)
{
	if (IsError())
		return false;

	if (!bit_stream.Open(file_name))
	{
		SetError("Cannot open input file");
		return false;
	}

	opened = true;
	file_mode = FILE_MODE_READ;

	// Check version info and read essential config
	std::string version = DsrcFile::GetVersionString();
	uint32 vlen = (uint32)version.length();
	char buf[32];
	bit_stream.GetBytes((uchar*)buf, vlen+1);
	if (strcmp(buf, version.c_str()) != 0)		// unsupported version
	{
		std::string err = "File version: \'";
		err += buf;
		err += "\'; DSRC version: \'";
		err += version;
		err += "\'; ";
		SetError(("Invalid file or unsupported DSRC version.\n" + err).c_str());
		return false;
	}

	bit_stream.GetWord(sb_size);		// 0xAA
	bit_stream.GetWord(sb_size);
	bit_stream.GetWord(block_size);
	bit_stream.GetWord(lz_compression_level);

#if (RESERVE_BYTES_PER_DSRCFILE)
	{
		uchar bytes[DsrcFile::HEADER_RESERVED_BYTES];
		bit_stream.GetBytes(bytes, DsrcFile::HEADER_RESERVED_BYTES);
		for (uint32 i = 0; i < DsrcFile::HEADER_RESERVED_BYTES; ++i)
		{
			my_assert(bytes[i] == INVALID_BYTE);		// secure debug check
		}
	}
#endif

	if (superblock == NULL)
	{
		superblock = new Superblock(sb_size, block_size);
	}
	if (superblock->GetSuperblockSize() != sb_size || superblock->GetBlockSize() != block_size)
	{
		superblock->ResetSize(sb_size, block_size);
	}
	
	superblock->Reset();
	
	try_lz = true;
	lz_matcher.Reset();
	lz_matcher.SetCompressionLevel(lz_compression_level);
	lz_matcher.SetMaxMemory(((uint64) DsrcFile::MAX_LZ_MEMORY_SIZE_MB) << 20);

	return true;
}

// ********************************************************************************************
bool DsrcFile::ReadNextRecord(FastqRecord &rec)
{
	if (IsError())
		return false;

	if (file_mode != FILE_MODE_READ)
	{
		SetError("Invalid compressor state");
		return false;
	}

	if (rec_count % sb_size == 0)
	{
		superblock->Reset(rec_count, -1);	
		superblock->Read(bit_stream, lz_matcher);
		sb_count++;
	}
	rec_count++;

	if(superblock->ReadNextRawRecord(rec))
	{
		//AmbCodes::UnTransfer(rec);				//:HACK moved from I/O, transferring in Block
		return true;
	}

	return false;
}

// ********************************************************************************************
bool DsrcFile::FinishDecompress()
{
	rec_count = 0;
	sb_count = 0;

	file_mode = FILE_MODE_NONE;
	opened = false;

	if (superblock)
		superblock->Reset();

	if (try_lz)
		lz_matcher.Reset();

	return bit_stream.Close();
}


// ********************************************************************************************
bool DsrcFile::StartExtract(const char* file_name)
{
	if (IsError())
		return false;

	if (!bit_stream.OpenRA(file_name))
	{
		SetError("Cannot open input file");
		return false;
	}

	opened = true;
	file_mode = FILE_MODE_READ_RA;

	// Check version info and read essential config
	std::string version = DsrcFile::GetVersionString();
	uint32 vlen = (uint32)version.length();
	char buf[32];
	bit_stream.GetBytes((uchar*)buf, vlen+1);
	if (strcmp(buf, version.c_str()) != 0)		// unsupported version
	{
		std::string err = "File version: \'";
		err += buf;
		err += "\'; DSRC version: \'";
		err += version;
		err += "\'; ";
		SetError(("Invalid file or unsupported DSRC version.\n" + err).c_str());
		return false;
	}

	bit_stream.GetWord(sb_size);	// 0xAA
	bit_stream.GetWord(sb_size);
	bit_stream.GetWord(block_size);
	bit_stream.GetWord(lz_compression_level);

	// Read header data
	bit_stream.SetPos(bit_stream.GetSize() - DsrcFile::ENDING_HEADER_OFFSET);
	bit_stream.GetByte(block_offset_bit_len);
	bit_stream.GetDWord(header_sb_count);
	bit_stream.GetDWord(header_b_count);
	bit_stream.GetDWord(header_pos);

	sb_file_pos.resize(header_sb_count);
	bit_stream.SetPos(header_pos);
	for (uint64 i = 0; i < header_sb_count; ++i)
	{
		uint64 tmp;
		bit_stream.GetDWord(tmp);
		sb_file_pos[i] = tmp;
	}

	block_file_pos.resize(header_b_count);
	for (uint64 i = 0; i < header_b_count; ++i)
	{
		uint32 tmp;
		bit_stream.GetBits(tmp, block_offset_bit_len);
		block_file_pos[i] = tmp;
	}
	bit_stream.FlushInputWordBuffer();

	if (superblock == NULL)
	{
		superblock = new Superblock(sb_size, block_size);
	}
	if (superblock->GetSuperblockSize() != sb_size || superblock->GetBlockSize() != block_size)
	{
		superblock->ResetSize(sb_size, block_size);
	}
	superblock->Reset();
	

	if (superblock_lz == NULL)
	{
		superblock_lz = new Superblock(sb_size, block_size);
	}
	if (superblock_lz->GetSuperblockSize() != sb_size || superblock_lz->GetBlockSize() != block_size)
	{
		superblock_lz->ResetSize(sb_size, block_size);
	}
	superblock_lz->Reset();
	

	try_lz = true;
	lz_matcher.Reset();
	lz_matcher.SetCompressionLevel(lz_compression_level);
	lz_matcher.SetMaxMemory(((uint64) DsrcFile::MAX_LZ_MEMORY_SIZE_MB) << 20);

	ext_cur_sb_id = (uint32)~0;

	return true;
}

// ********************************************************************************************
bool DsrcFile::ExtractRecord(FastqRecord &rec, uint64 rec_id)
{
	if (IsError())
		return false;

	if (file_mode != FILE_MODE_READ_RA)
	{
		SetError("Invalid compressor state");
		return false;
	}

	// Find positions in compressed file
	uint64 sb_id = rec_id / sb_size;

	// Check whether sb is already in memory
	if (ext_cur_sb_id != sb_id)
	{
		ext_cur_sb_id = sb_id;

		uint64 b_id = rec_id / block_size;
		//uint32 b_in_sb_id = (uint32) ((rec_id % sb_size) / block_size);
		uint64 sb_start_pos = sb_file_pos[sb_id];
		uint64 b_start_pos = sb_start_pos + block_file_pos[b_id];
		uint64 sb_rec_start = sb_id * sb_size;

		// Read superblock header and selected block
		if (b_start_pos >= (bit_stream.GetSize() - DsrcFile::ENDING_HEADER_OFFSET) || !bit_stream.SetPos(sb_start_pos))
		{
			SetError("Record no. exceeds maximum records number");
			return false;
		}

		superblock->Reset(sb_rec_start);
		superblock->Read(bit_stream, lz_matcher, -1, 0, true); // read all, wo lz decompression
	}


	// Read record
	uint64 lz_rec_id;
	uint32 lz_rec_offset;
	uint32 lz_match_len;
	if (!superblock->ExtractRawRecord(rec, rec_id, lz_rec_id, lz_rec_offset, lz_match_len))
	{
		SetError("Record no. exceeds maximum records number");
		return false;
	}

	bool force_const_delta_encoding = false;
	uint32 force_seq_start = 0;
	uint32 force_qua_start = 0;

	if (lz_match_len)
	{
		FastqRecord lz_rec;
		if (!ExtractLzRecord(lz_rec, lz_rec_id))
		{
			SetError("Error while extracting LZ record");
			return false;
		}

		std::copy(lz_rec.sequence+lz_rec_offset, lz_rec.sequence+lz_rec_offset+lz_match_len, rec.sequence);	

		if (lz_rec_offset == 0)
		{
			force_const_delta_encoding = superblock_lz->IsSetFlag(FLAG_USE_DELTA | FLAG_DELTA_CONSTANT);
			if (force_const_delta_encoding)
			{
				force_seq_start = superblock_lz->GetDeltaSequenceStart();
				force_qua_start = superblock_lz->GetDeltaQualityStart();
			}
			else
			{
				force_seq_start = lz_rec.sequence[0];
				force_qua_start = lz_rec.quality[0];
			}
		}
	}

	superblock->ExtractionPostProcess(rec, force_const_delta_encoding, force_seq_start, force_qua_start);

	return true;
}

// ********************************************************************************************
bool DsrcFile::ExtractLzRecord(FastqRecord &rec, uint64 rec_id)
{
	if (IsError())
		return false;

	if (file_mode != FILE_MODE_READ_RA)
	{
		SetError("Invalid compressor state");
		return false;
	}

	// Find positions in compressed file
	uint64 sb_id = rec_id / sb_size;
	uint64 b_id = rec_id / block_size;
	uint32 b_in_sb_id = (uint32) ((rec_id % sb_size) / block_size);
	uint64 sb_start_pos;
	uint64 b_start_pos;

	sb_start_pos = sb_file_pos[sb_id];
	b_start_pos = sb_start_pos + block_file_pos[b_id];

	// Read superblock header and selected block
	if (b_start_pos >= (bit_stream.GetSize() - DsrcFile::ENDING_HEADER_OFFSET) || !bit_stream.SetPos(sb_start_pos))
	{
		SetError("Record no. exceeds maximum records number");
		return false;
	}

	superblock_lz->Reset(sb_id * sb_size, -1, b_in_sb_id);
	superblock_lz->Read(bit_stream, lz_matcher, b_in_sb_id, b_start_pos, true);
	
	// Read record
	uint64 lz_rec_id;
	uint32 lz_rec_offset;
	uint32 lz_match_len;
	if (!superblock_lz->ExtractRawRecord(rec, rec_id, lz_rec_id, lz_rec_offset, lz_match_len))
	{
		SetError("Error while extracting LZ record");
		return false;
	}

	return true;
}

// ********************************************************************************************
bool DsrcFile::FinishExtract()
{
	rec_count = 0;
	sb_count = 0;

	file_mode = FILE_MODE_NONE;
	opened = false;

	sb_file_pos.clear();
	block_file_pos.clear();

	if (superblock)
		superblock->Reset();

	if (superblock_lz)
		superblock_lz->Reset();

	if (try_lz)
		lz_matcher.Reset();

	return bit_stream.Close();
}

// ********************************************************************************************
void DsrcFile::Reset(bool resetSb)
{
	if (opened)
	{
		opened = false;
		bit_stream.Close();
	}

	file_mode = FILE_MODE_NONE;

	rec_count = 0;
	sb_count = 0;

	if (resetSb)
	{
		if (superblock)
			superblock->Reset();

		if (superblock_lz)
			superblock_lz->Reset();
	}

	ClearError();
}

// ********************************************************************************************
bool DsrcFile::SetLzMatching(bool lz_match)
{
	if (opened)
	{
		SetError("Cannot set while processing");
		return false;
	}

	try_lz = lz_match;
	return true;
}

// ********************************************************************************************
bool DsrcFile::SetLzMemorySize(uint32 max_mem)
{
	if (opened)
	{
		SetError("Cannot set while processing");
		return false;
	}

	if (max_mem < DsrcFile::MIN_LZ_MEMORY_SIZE_MB || max_mem > DsrcFile::MAX_LZ_MEMORY_SIZE_MB)
	{
		char minval[16], maxval[16];
		utils::to_string((uchar*)minval, DsrcFile::MIN_LZ_MEMORY_SIZE_MB);
		utils::to_string((uchar*)maxval, DsrcFile::MAX_LZ_MEMORY_SIZE_MB);
		std::string err("Size exceeds available boundaries - min: ");
		err += minval;
		err += "; max: ";
		err += maxval;
		SetError(err.c_str());
		return false;
	}

	lz_max_memory_size = max_mem;
	return true;
}

#if !(FEATURE_DISABLED_IN_V_100)
// ********************************************************************************************
bool DsrcFile::SetLzCompressionLevel(uint32 level)
{
	if (opened)
	{
		SetError("Cannot set while processing");
		return false;
	}

	if (level < DsrcFile::MIN_LZ_COMPRESSION_LEVEL || level > DsrcFile::MAX_LZ_COMPRESSION_LEVEL)
	{
		char minval[16], maxval[16];
		utils::to_string((uchar*)minval, DsrcFile::MIN_LZ_COMPRESSION_LEVEL);
		utils::to_string((uchar*)maxval, DsrcFile::MAX_LZ_COMPRESSION_LEVEL);
		std::string err("Invalid compression level specified - min: ");
		err += minval;
		err += "; max: ";
		err += maxval;
		SetError(err.c_str());
		return false;
	}

	lz_compression_level = level;
	return true;
}

// ********************************************************************************************
bool DsrcFile::SetSuperblockSize(uint32 _sb_size)
{
	if (opened)
	{
		SetError("Cannot set while processing");
		return false;
	}

	if (_sb_size & (_sb_size - 1))	// not a power of 2
	{
		SetError("Size must be power of two");
		return false;
	}

	if (_sb_size < DsrcFile::MIN_SB_SIZE || _sb_size > DsrcFile::MAX_SB_SIZE)
	{
		char minval[16], maxval[16];
		utils::to_string((uchar*)minval, DsrcFile::MIN_SB_SIZE);
		utils::to_string((uchar*)maxval, DsrcFile::MAX_SB_SIZE);
		std::string err("Size exceeds available boundaries - min: ");
		err += minval;
		err += "; max: ";
		err += maxval;
		SetError(err.c_str());
		return false;
	}

	sb_size = _sb_size;
	return true;
}

// ********************************************************************************************
bool DsrcFile::SetBlockSize(uint32 _block_size)
{
	if (opened)
	{
		SetError("Cannot set while processing");
		return false;
	}

	if (_block_size & (_block_size - 1))	// not a power of 2
	{
		SetError("Size must be power of two");
		return false;
	}

	if (_block_size < DsrcFile::MIN_BLOCK_SIZE || _block_size > DsrcFile::MAX_BLOCK_SIZE)
	{
		char minval[16], maxval[16];
		utils::to_string((uchar*)minval, DsrcFile::MIN_BLOCK_SIZE);
		utils::to_string((uchar*)maxval, DsrcFile::MAX_BLOCK_SIZE);
		std::string err("Size exceeds available boundaries - min: ");
		err += minval;
		err += "; max: ";
		err += maxval;
		SetError(err.c_str());
		return false;
	}

	block_size = _block_size;
	return true;
}

#endif
