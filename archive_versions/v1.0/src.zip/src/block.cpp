/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/

#include "defs.h"
#include "block.h"
#include "superblock.h"
#include <algorithm>

// ********************************************************************************************
void Block::Process(BitStream &bit_stream, LzMatcher &lz_matcher, std::vector<Field> &fields, uint32 /*n_fields*/,
	uint32 fastq_flags, uchar *sym_code, HuffmanEncoder::Code *sym_huf_codes, 
	uchar *qua_code, HuffmanEncoder::Code **qua_huf_codes, uint32 /*max_run_len*/, 
	HuffmanEncoder::Code **run_huf_codes, uint32 n_qualities, uint32 _global_max_sequence_length, 
	uint32 block_no, uint32 _quality_stats_mode)
{
	global_max_sequence_length  = _global_max_sequence_length;

#if (D_RESERVE_BYTES_PER_BLOCK)
	{
		uchar bytes[Block::RESERVED_BYTES];
		std::fill(bytes, bytes+Block::RESERVED_BYTES, INVALID_BYTE);
		bit_stream.PutBytes(bytes, Block::RESERVED_BYTES);
	}
#endif

	if ((fastq_flags & FLAG_PLUS_ONLY) == 0)
	{
		for (uint32 i = 0; i < rec_count; ++i)
		{
			bit_stream.PutBit(records[i].plus_len == 1);
		}
	}
	uint32 quality_len_bits = BitStream::BitLength(global_max_sequence_length);

	if ((fastq_flags & FLAG_VARIABLE_LENGTH) != 0)
	{
		for (uint32 i = 0; i < rec_count; ++i)
		{
			bit_stream.PutBits(records[i].quality_len, quality_len_bits);
		}
	}

	if ((fastq_flags & FLAG_LINE_BREAKS) != 0)
	{
		uint32 max_line_break_len = 0;
		for (uint32 i = 0; i < rec_count; ++i)
		{
			if (records[i].sequence_breaks)
			{
				for (uint32 j = 0; j < records[i].sequence_breaks->size(); ++j)
				{
					if ((*records[i].sequence_breaks)[j] > (int32) max_line_break_len)
					{
						max_line_break_len = (*records[i].sequence_breaks)[j];
					}
				}
			}
			if (records[i].quality_breaks)
			{
				for (uint32 j = 0; j < records[i].quality_breaks->size(); ++j)
				{
					if ((*records[i].quality_breaks)[j] > (int32) max_line_break_len)
					{
						max_line_break_len = (*records[i].quality_breaks)[j];
					}
				}
			}
		}

		uint32 line_breaks_bits = BitStream::BitLength(max_line_break_len);
		bit_stream.PutBits(line_breaks_bits, 5);

		for (uint32 i = 0; i < rec_count; ++i)
		{
			if (records[i].sequence_breaks)
			{
				for (uint32 j = 0; j < records[i].sequence_breaks->size(); ++j)
				{
					bit_stream.PutBits((*records[i].sequence_breaks)[j], line_breaks_bits);
				}
			}
			bit_stream.PutBits(0, line_breaks_bits);

			if (records[i].quality_breaks)
			{
				for (uint32 j = 0; j < records[i].quality_breaks->size(); ++j)
				{
					bit_stream.PutBits((*records[i].quality_breaks)[j], line_breaks_bits);
				}
			}
			bit_stream.PutBits(0, line_breaks_bits);
		}
	}
	bit_stream.FlushPartialWordBuffer();

	bool is_num_field_constant = (fastq_flags & FLAG_CONST_NUM_FIELDS) != 0;
	StoreTitle(bit_stream, fields, block_no, is_num_field_constant);

	if (_quality_stats_mode == QUALITY_RLE)
	{
		StoreQualityRLE(bit_stream, qua_code, qua_huf_codes, run_huf_codes, n_qualities);
	}
	else
	{
		bool use_trunc_hash = _quality_stats_mode == QUALITY_PLAIN_TRUNC;
		StoreQualityPlain(bit_stream, qua_code, qua_huf_codes, n_qualities, use_trunc_hash);
	}

	bool try_lz = (fastq_flags & FLAG_TRY_LZ) != 0;
	if ((fastq_flags & FLAG_DNA_PLAIN) != 0)
	{
		StoreDNAPlain(bit_stream, lz_matcher, sym_code, try_lz);
	}
	else
	{
		StoreDNAHuf(bit_stream, lz_matcher, sym_code, sym_huf_codes, try_lz);
	}

#if (D_COMPUTE_RECORDS_CRC_PER_BLOCK)
	uint32 hash = ComputeRecordsCrc32();
	bit_stream.PutWord(hash);
#endif
}

// ********************************************************************************************
void Block::Read(BitStream &bit_stream, LzMatcher &lz_matcher, std::vector<Field> &fields, uint32 n_fields,
	uint32 fastq_flags, std::vector<uchar> &symbols, HuffmanEncoder *Huffman_sym,
	std::vector<uchar> &qualities, std::vector<HuffmanEncoder*> &Huffman_qua, 
	uint32 max_run_len, std::vector<HuffmanEncoder*> &Huffman_run, uint32 n_qualities, uint32 block_no, 
	uint32 _quality_stats_mode, bool extracting)
{

#if (D_RESERVE_BYTES_PER_BLOCK)
	{
		uchar bytes[Block::RESERVED_BYTES];
		bit_stream.GetBytes(bytes, Block::RESERVED_BYTES);
		for (uint32 i = 0; i < Block::RESERVED_BYTES; ++i)
		{
			my_assert(bytes[i] == INVALID_BYTE);
		}
	}
#endif

	no_of_amb.resize(rec_count);
	for (uint32 i = 0; i < rec_count; ++i)
	{
		records[i].Reset();
		no_of_amb[i] = 0;
	}

	int32 quality_len_bits = BitStream::BitLength(global_max_sequence_length);
	if ((fastq_flags & FLAG_PLUS_ONLY) == 0)
	{
		for (uint32 i = 0; i < rec_count; ++i)
		{
			bit_stream.GetBit(records[i].plus_len);
		}
	}
	else
	{
		for (uint32 i = 0; i < rec_count; ++i)
		{
			records[i].plus_len = 1;
		}
	}

	if ((fastq_flags & FLAG_VARIABLE_LENGTH) != 0)
	{
		uint32 tmp;
		for (uint32 i = 0; i < rec_count; ++i)
		{
			FastqRecord& rec = records[i];
			bit_stream.GetBits(tmp, quality_len_bits);
			rec.quality_len = tmp;
			rec.ExtendTo(rec.quality, rec.quality_size, tmp+2);
			rec.sequence_len = tmp;
			rec.ExtendTo(rec.sequence, rec.sequence_size, tmp+2);
		}
	}
	else
	{
		for (uint32 i = 0; i < rec_count; ++i)
		{
			FastqRecord& rec = records[i];
			rec.quality_len = global_max_sequence_length;
			rec.ExtendTo(rec.quality, rec.quality_size, global_max_sequence_length+2);
			rec.sequence_len = global_max_sequence_length;
			rec.ExtendTo(rec.sequence, rec.sequence_size, global_max_sequence_length+2);
		}
	}

	if ((fastq_flags & FLAG_LINE_BREAKS) != 0)
	{
		uint32 line_breaks_bits;
		bit_stream.GetBits(line_breaks_bits, 5);
		uint32 tmp;

		for (uint32 i = 0; i < rec_count; ++i)
		{
			FastqRecord& rec = records[i];
			if (rec.sequence_breaks)
			{
				delete rec.sequence_breaks;
				rec.sequence_breaks = NULL;
			}

			bit_stream.GetBits(tmp, line_breaks_bits);
			while (tmp != 0)
			{
				if (!rec.sequence_breaks)
				{
					rec.sequence_breaks = new std::vector<int>;
				}
				rec.sequence_breaks->push_back(tmp);

				bit_stream.GetBits(tmp, line_breaks_bits);
			}


			if (rec.quality_breaks)
			{
				delete rec.quality_breaks;
				rec.quality_breaks = NULL;
			}
			bit_stream.GetBits(tmp, line_breaks_bits);
			while (tmp != 0)
			{
				if (!rec.quality_breaks)
				{
					rec.quality_breaks = new std::vector<int>;
				}
				rec.quality_breaks->push_back(tmp);

				bit_stream.GetBits(tmp, line_breaks_bits);
			}
		}
	}
	bit_stream.FlushInputWordBuffer();


	bool is_num_fields_constant = (fastq_flags & FLAG_CONST_NUM_FIELDS) != 0;
	ReadTitle(bit_stream, fields, n_fields, block_no, is_num_fields_constant);

	if (_quality_stats_mode == QUALITY_RLE)
	{
		ReadQualityRLE(bit_stream, qualities, Huffman_qua, n_qualities, Huffman_run, max_run_len);
		MakeUnRLE();
	}
	else
	{
		bool use_trunc_h = _quality_stats_mode == QUALITY_PLAIN_TRUNC;
		bool uses_const_delta = (fastq_flags & (FLAG_USE_DELTA | FLAG_DELTA_CONSTANT)) ==  (FLAG_USE_DELTA | FLAG_DELTA_CONSTANT);
		ReadQualityPlain(bit_stream, qualities, Huffman_qua, n_qualities, use_trunc_h, uses_const_delta);
	}

	bool try_lz = (fastq_flags & FLAG_TRY_LZ) != 0;
	if ((fastq_flags & FLAG_DNA_PLAIN) != 0)
	{
		ReadDNAPlain(bit_stream, lz_matcher, symbols, try_lz, extracting);
	}
	else
	{
		ReadDNAHuf(bit_stream, lz_matcher, symbols, Huffman_sym, try_lz, extracting);	// lz_matches not supported when Huffman encoding
	}

#if (D_COMPUTE_RECORDS_CRC_PER_BLOCK)
	uint32 hash;
	bit_stream.GetWord(hash);
	my_assert(hash == ComputeRecordsCrc32());
#endif
}

// ********************************************************************************************
void Block::StoreTitle(BitStream &bit_stream, std::vector<Field> &fields, int32 block_no, bool is_num_fields_constant)
{
	uint32 n_fields = (uint32) fields.size();
	uint32 n_fields_bits = BitStream::BitLength(n_fields);
	prev_value.resize(n_fields);

	for (uint32 i = 0; i < n_fields; ++i)
	{
		if (fields[i].is_constant)
			continue;

		Field::BlockDesc& block_desc = fields[i].block_desc[block_no];
		prev_value[i] = 0;
		if (!fields[i].is_numeric)
		{
			bit_stream.PutBit(block_desc.is_block_constant);
		}

		if (fields[i].is_numeric)
		{
			block_desc.is_block_delta_constant &= (int32)block_desc.block_delta_constant == fields[i].min_delta;
			if (fields[i].is_delta_coding)
			{
				bit_stream.PutBit(block_desc.is_block_delta_constant);
			}
			else
			{
				bit_stream.PutBit(block_desc.is_block_value_constant);
			}
		}		
	}

	for (uint32 i = 0; i < rec_count; ++i)
	{
		uint32 c_field = 0;
		uint32 start_pos = 0;
		FastqRecord &rec = records[i];

		if (!is_num_fields_constant)
		{
			bit_stream.PutBits(rec.no_of_fields, n_fields_bits);
		}

		for (uint32 k = 0; k <= rec.title_len; ++k)
		{
			Field &cur_field = fields[c_field];

			if (rec.title[k] != cur_field.sep && k < rec.title_len)
				continue;

			if (cur_field.is_constant)
			{
				start_pos = k+1;
				c_field++;
				continue;
			}

			if (cur_field.is_numeric)
			{
				int32 value = utils::to_num(rec.title+start_pos, k-start_pos);
				if (i == 0)
				{
					bit_stream.PutBits(value-cur_field.min_value, cur_field.no_of_bits_per_value);
				}
				else if ((cur_field.is_delta_coding && !cur_field.block_desc[block_no].is_block_delta_constant) ||
					(!cur_field.is_delta_coding && !cur_field.block_desc[block_no].is_block_value_constant))
				{
					int32 to_store;
					if (cur_field.is_delta_coding)
					{
						to_store = value - prev_value[c_field] - cur_field.min_delta;
					}
					else
					{
						to_store = value - cur_field.min_value;
					}

					if (cur_field.Huffman_global)
					{
						const HuffmanEncoder::Code* codes = cur_field.Huffman_global->GetCodes();
						bit_stream.PutBits(codes[to_store].code, codes[to_store].len);
					}
					else
					{
						bit_stream.PutBits(to_store, cur_field.no_of_bits_per_num);
					}
				}

				prev_value[c_field] = value;
				start_pos = k+1;
				c_field++;
				continue;
			}
			if (i > 0 && cur_field.block_desc[block_no].is_block_constant)
			{
				start_pos = k+1;
				c_field++;
				continue;
			}
			if (!cur_field.is_len_constant)
			{
				bit_stream.PutBits(k-start_pos - cur_field.min_len, cur_field.no_of_bits_per_len);
			}

			for (uint32 j = 0; j < k-start_pos; ++j)
			{
				if (j >= cur_field.len || !cur_field.Ham_mask[j])
				{
					uchar c = rec.title[start_pos+j];
					const HuffmanEncoder::Code* codes = cur_field.Huffman_local[MIN(j, Superblock::MAX_FIELD_STAT_LEN)]->GetCodes();
					bit_stream.PutBits(codes[c].code, codes[c].len);
				}
			}

			start_pos = k+1;
			c_field++;
		}
	}
	bit_stream.FlushPartialWordBuffer();
}

// ********************************************************************************************
void Block::StoreQualityPlain(BitStream &bit_stream, uchar *qua_code, HuffmanEncoder::Code **qua_huf_codes, int32 /*n_qualities*/, bool use_truc_hash)
{
	// Quality data
	if (!use_truc_hash)
	{
		for (uint32 i = 0; i < rec_count; ++i)
		{
			uchar *cur_quality = records[i].quality; 
			uint32 cur_quality_len = records[i].quality_len;
			for (uint32 j = 0; j < cur_quality_len; ++j)
			{
				int32 qua = qua_code[cur_quality[j]];
				bit_stream.PutBits(qua_huf_codes[j+1][qua].code, qua_huf_codes[j+1][qua].len);
			}
		}
	}
	else
	{
		for (uint32 i = 0; i < rec_count; ++i)
		{
			uchar *cur_quality = records[i].quality; 
			uint32 cur_quality_len = records[i].quality_len;
			uint32 cur_quality_len_th = records[i].rec_th_len;
			
			bit_stream.PutBits(cur_quality_len_th != cur_quality_len, 1);
			if (cur_quality_len_th != cur_quality_len)
			{
				bit_stream.PutBits(cur_quality_len - cur_quality_len_th, BitStream::BitLength(cur_quality_len));
			}
			
			for (uint32 j = 0; j < cur_quality_len_th; ++j)
			{
				int32 qua = qua_code[cur_quality[j]];
				bit_stream.PutBits(qua_huf_codes[j+1][qua].code, qua_huf_codes[j+1][qua].len);
			}
		}
	}

	bit_stream.FlushPartialWordBuffer();
}

// ********************************************************************************************
void Block::StoreQualityRLE(BitStream &bit_stream, uchar *qua_code, HuffmanEncoder::Code **qua_huf_codes, HuffmanEncoder::Code **run_huf_codes, int32 /*n_qualities*/)
{
	// Quality data
	uchar prev = 0;
	uint32 pos = 0;

	for (uint32 i = 0; i < qua_stream_len; ++i)
	{
		uchar qua = qua_code[qua_stream[i]];
		uchar len = run_stream[i];
		bit_stream.PutBits(qua_huf_codes[prev][qua].code, qua_huf_codes[prev][qua].len);
		bit_stream.PutBits(run_huf_codes[qua][len].code, run_huf_codes[qua][len].len);
		prev = qua;
		pos += len+1;
	}

	bit_stream.FlushPartialWordBuffer();
}

// ********************************************************************************************
void Block::StoreLzMatches(BitStream &bit_stream, LzMatcher &lz_matcher)
{
	for (uint32 i = 0; i < rec_count; ++i)
	{
		bit_stream.PutBit(lz_matches[i].length != 0);
		if (lz_matches[i].length == 0)
		{
			bit_stream.PutBit(records[i].lz_inserted);
		}
	}
	bit_stream.FlushPartialWordBuffer();

	// DNA data
	uint32 rec_no_bits = BitStream::BitLength(b_start_rec_no + rec_count - 1);
	uint32 length_bits;

	uint32 offset_bits = (uint32)MAX(0, (int32)global_max_sequence_length - (int32)lz_matcher.GetMinMatchLen());
	if (offset_bits)
	{
		offset_bits = BitStream::BitLength(global_max_sequence_length - lz_matcher.GetMinMatchLen());
	}

	for (uint32 i = 0; i < rec_count; ++i)
	{
		if (lz_matches[i].length > 0)
		{
			length_bits = BitStream::BitLength(MAX(0, MIN((int32)records[i].sequence_len - (int32)lz_matcher.GetMinMatchLen(), 255)));

			bit_stream.PutBits(lz_matches[i].rec_no, rec_no_bits);
			if (length_bits > 0)
				bit_stream.PutBits(lz_matches[i].length - lz_matcher.GetMinMatchLen(), length_bits);

			if (offset_bits)
				bit_stream.PutBits(lz_matches[i].rec_offset, offset_bits);
		}
	}
	bit_stream.FlushPartialWordBuffer();
}

// ********************************************************************************************
void Block::StoreDNAPlain(BitStream &bit_stream, LzMatcher &lz_matcher, uchar *sym_code, bool try_lz)
{
	// Info about LZ matches
	if (try_lz)
	{
		FindLzMatches(lz_matcher);

		StoreLzMatches(bit_stream, lz_matcher);

		for (uint32 i = 0; i < rec_count; ++i)
		{
			uint32 cur_sequence_len = records[i].sequence_len;
			uchar *cur_sequence = records[i].sequence;
			for (uint32 j = lz_matches[i].length; j < cur_sequence_len; ++j)
			{
				bit_stream.Put2Bits(sym_code[cur_sequence[j]]);
			}
		}
	}
	else
	{
		for (uint32 i = 0; i < rec_count; ++i)
		{
			uint32 cur_sequence_len = records[i].sequence_len;
			uchar *cur_sequence = records[i].sequence;
			for (uint32 j = 0; j < cur_sequence_len; ++j)
			{
				bit_stream.Put2Bits(sym_code[cur_sequence[j]]);
			}
		}
	}

	bit_stream.FlushPartialWordBuffer();
}

// ********************************************************************************************
void Block::StoreDNAHuf(BitStream &bit_stream, LzMatcher &lz_matcher, uchar *sym_code, HuffmanEncoder::Code *sym_huf_codes, bool try_lz)
{
	// Info about LZ matches
	if (try_lz)
	{
		FindLzMatches(lz_matcher);

		StoreLzMatches(bit_stream, lz_matcher);

		for (uint32 i = 0; i < rec_count; ++i)
		{
			uint32 cur_sequence_len = records[i].sequence_len;
			uchar *cur_sequence = records[i].sequence;
			for (uint32 j = lz_matches[i].length; j < cur_sequence_len; ++j)
			{
				bit_stream.PutBits(sym_huf_codes[sym_code[cur_sequence[j]]].code, sym_huf_codes[sym_code[cur_sequence[j]]].len);
			}
		}
	}
	else
	{
		for (uint32 i = 0; i < rec_count; ++i)
		{
			uint32 cur_sequence_len = records[i].sequence_len;
			uchar *cur_sequence = records[i].sequence;
			for (uint32 j = 0; j < cur_sequence_len; ++j)
			{
				bit_stream.PutBits(sym_huf_codes[sym_code[cur_sequence[j]]].code, sym_huf_codes[sym_code[cur_sequence[j]]].len);
			}
		}
	}

	bit_stream.FlushPartialWordBuffer();
}

// ********************************************************************************************
void Block::ReadTitle(BitStream &bit_stream, std::vector<Field> &fields, uint32 n_fields, int32 block_no, bool is_num_fields_constant)
{
	prev_value.resize(n_fields);
	uint32 n_fields_bits = BitStream::BitLength(n_fields);

	uint32 tmp = 0;
	for (uint32 i = 0; i < n_fields; ++i)
	{
		if (fields[i].is_constant)
			continue;

		prev_value[i] = 0;
		if (!fields[i].is_numeric)
		{
			bit_stream.GetBit(tmp);
			fields[i].block_desc[block_no].is_block_constant = tmp != 0;
		}
		else
		{
			bit_stream.GetBit(tmp);
			if (fields[i].is_delta_coding)
			{
				fields[i].block_desc[block_no].is_block_delta_constant = tmp != 0;
			}
			else
			{
				fields[i].block_desc[block_no].is_block_value_constant = tmp != 0;
			}
		}		
	}

	for (uint32 i = 0; i < rec_count; ++i)
	{
		FastqRecord& cur_rec = records[i];

		uint32 cn_fields = n_fields;
		if (!is_num_fields_constant)
		{
			bit_stream.GetBits(tmp, n_fields_bits);
			cn_fields = tmp;
		}

		for (uint32 j = 0; j < cn_fields; ++j)
		{
			Field &cur_field = fields[j];
			if (cur_field.is_constant)
			{
				cur_rec.AppendTitle(cur_field.data, cur_field.len);
				cur_rec.AppendTitle(cur_field.sep);
				continue;
			}
			if (cur_field.is_numeric)
			{
				uint32 num_val = 0;

				if (cur_rec.title_len + 10 >= cur_rec.title_size)
				{
					cur_rec.Extend(cur_rec.title, cur_rec.title_size);
				}
				if (i == 0)
				{
					bit_stream.GetBits(num_val, cur_field.no_of_bits_per_value);
					num_val += cur_field.min_value;
					cur_rec.title_len += utils::to_string(cur_rec.title+cur_rec.title_len, num_val);
					prev_value[j] = num_val;
				}
				else
				{
					if ((cur_field.is_delta_coding && !cur_field.block_desc[block_no].is_block_delta_constant) ||
						(!cur_field.is_delta_coding && !cur_field.block_desc[block_no].is_block_value_constant))
					{
						if (cur_field.no_of_bits_per_num > 0)
						{
							if (cur_field.Huffman_global)
							{
								uint32 bit;
								int32 h_tmp;

								bit_stream.GetBits(bit, cur_field.Huffman_global->GetMinLen());
								h_tmp = cur_field.Huffman_global->DecodeFast(bit);

								while (h_tmp < 0)
								{
									bit_stream.GetBit(bit);
									h_tmp = cur_field.Huffman_global->Decode(bit);
								};

								num_val = h_tmp;
							}
							else
							{
								bit_stream.GetBits(num_val, cur_field.no_of_bits_per_num);
							}
						}
						else
						{
							num_val = 0;
						}
					}
					else
					{
						if (cur_field.is_delta_coding)
						{
							num_val = 0;
						}
						else
						{
							num_val = prev_value[j] - cur_field.min_value;
						}
					}

					if (cur_field.is_delta_coding)
					{
						num_val += prev_value[j] + cur_field.min_delta;
					}
					else
					{
						num_val += cur_field.min_value;
					}

					cur_rec.title_len += utils::to_string(cur_rec.title+cur_rec.title_len, num_val);
					prev_value[j] = num_val;
				}
				cur_rec.AppendTitle(cur_field.sep);

				continue;
			}

			if (i > 0 && cur_field.block_desc[block_no].is_block_constant)
			{
				cur_rec.AppendTitle(records[0].title+cur_field.block_str_start, cur_field.block_str_len);
				cur_rec.AppendTitle(cur_field.sep);
				continue;
			}

			uint32 field_len;
			if (!cur_field.is_len_constant)
			{
				bit_stream.GetBits(field_len, cur_field.no_of_bits_per_len);			
				field_len += cur_field.min_len;
			}
			else
			{
				field_len = cur_field.len;
			}
			
			for (uint32 k = 0; k < field_len; ++k)
			{
				if (k < cur_field.len && cur_field.Ham_mask[k])
				{
					cur_rec.AppendTitle(cur_field.data[k]);
				}
				else
				{
					uint32 bit;
					int32 h_tmp;
					HuffmanEncoder *cur_huf = cur_field.Huffman_local[MIN(k, Superblock::MAX_FIELD_STAT_LEN)]; 

					bit_stream.GetBits(bit, cur_huf->GetMinLen());
					h_tmp = cur_huf->DecodeFast(bit);

					while (h_tmp < 0)
					{
						bit_stream.GetBit(bit);
						h_tmp = cur_huf->Decode(bit);
					};

					tmp = h_tmp;
					cur_rec.AppendTitle((uchar) tmp);
				}
			}
			if (i == 0 && cur_field.block_desc[block_no].is_block_constant)
			{
				cur_field.block_str_start = cur_rec.title_len - field_len;
				cur_field.block_str_len = field_len;
			}

			cur_rec.AppendTitle(cur_field.sep);
		}

		cur_rec.title_len--;			// do not count last '\0' symbols
		cur_rec.plus[0] = '+';
		if (cur_rec.plus_len == 1)
		{
			cur_rec.plus[1] = '\0';
		}
		else
		{
			cur_rec.plus_len = cur_rec.title_len;
			cur_rec.ExtendTo(cur_rec.plus, cur_rec.plus_size, cur_rec.title_len+2);
			std::copy(cur_rec.title+1, cur_rec.title+cur_rec.title_len, cur_rec.plus+1);
		}
	}
	bit_stream.FlushInputWordBuffer();
}

// ********************************************************************************************
void Block::ReadQualityPlain(BitStream &bit_stream, std::vector<uchar> &qualities, 
	std::vector<HuffmanEncoder*> &Huffman_qua, int32 /*n_qualities*/, bool trucated_hashes, bool /*uses_const_delta*/)
{
	// Quality data
	for (uint32 i = 0; i < rec_count; ++i)
	{
		no_of_amb[i] = 0;
		uchar *cur_quality = records[i].quality; 
		uint32 cur_quality_len = records[i].quality_len;
		uint32 trunc_len = 0;

		if (trucated_hashes)			// Truncate #
		{
			uint32 is_truncated(0);		// skip warning...
			bit_stream.GetBit(is_truncated);
			if (is_truncated)
			{
				bit_stream.GetBits(trunc_len, BitStream::BitLength(cur_quality_len));
			}
		}

		for (uint32 j = 0; j < cur_quality_len-trunc_len; ++j)
		{
			uint32 bit;
			int32 h_tmp;

			bit_stream.GetBits(bit, Huffman_qua[j+1]->GetMinLen());
			h_tmp = Huffman_qua[j+1]->DecodeFast(bit);

			while (h_tmp < 0)
			{
				bit_stream.GetBit(bit);
				h_tmp = Huffman_qua[j+1]->Decode(bit);
			};

			if ((cur_quality[j] = qualities[h_tmp]) >= 128)
			{
				no_of_amb[i]++;
			}
		}

		for (uint32 j = cur_quality_len-trunc_len; j < cur_quality_len; ++j)
		{
			cur_quality[j] = '#';
		}
	}
	bit_stream.FlushInputWordBuffer();
}

// ********************************************************************************************
void Block::ReadQualityRLE(BitStream &bit_stream, std::vector<uchar> &qualities, 
std::vector<HuffmanEncoder*> &Huffman_qua, int32 /*n_qualities*/, std::vector<HuffmanEncoder*> &Huffman_run, int32 /*max_run_len*/)
{
	int32 max_len = 0;
	uint32 i = 0;
	for (; i < rec_count; ++i)
	{
		max_len += records[i].quality_len;
	}

	qua_stream_len = run_stream_len = max_len;
	qua_stream = new uchar[max_len];
	run_stream = new uchar[max_len];


	uint32 prev = 0;
	i = 0;
	for (uint32 j = 0; j < qua_stream_len; ++i)
	{
		int32 h_tmp;
		uint32 bit;

		// Quality data
		bit_stream.GetBits(bit, Huffman_qua[prev]->GetMinLen());
		h_tmp = Huffman_qua[prev]->DecodeFast(bit);

		while (h_tmp < 0)
		{
			bit_stream.GetBit(bit);
			h_tmp = Huffman_qua[prev]->Decode(bit);
		};

		my_assert(h_tmp < (int32)qualities.size());
		qua_stream[i] = qualities[h_tmp];
		prev = h_tmp;

		// Run data
		bit_stream.GetBits(bit, Huffman_run[prev]->GetMinLen());
		h_tmp = Huffman_run[prev]->DecodeFast(bit);

		while (h_tmp < 0)
		{
			bit_stream.GetBit(bit);
			h_tmp = Huffman_run[prev]->Decode(bit);
		};

		run_stream[i] = (uchar) h_tmp;

		j += h_tmp+1;
	}

	bit_stream.FlushInputWordBuffer();
}

// ********************************************************************************************
void Block::ReadLzMatches(BitStream &bit_stream, LzMatcher &lz_matcher)
{
	for (uint32 i = 0; i < rec_count; ++i)
	{
		uint32 tmp(0);			// remove warning...
		bit_stream.GetBit(tmp);
		lz_matches[i].length = tmp;
		if (!lz_matches[i].length)
		{
			bit_stream.GetBit(tmp);
			records[i].lz_inserted = tmp != 0;
		}
	}
	bit_stream.FlushInputWordBuffer();

	// DNA data
	uint32 rec_no_bits = BitStream::BitLength(b_start_rec_no + rec_count - 1);
	uint32 length_bits;
	uint32 offset_bits = (uint32)MAX(0, (int32)global_max_sequence_length - (int32)lz_matcher.GetMinMatchLen());

	if (offset_bits)
	{
		offset_bits = BitStream::BitLength(offset_bits);
	}

	for (uint32 i = 0; i < rec_count; ++i)
	{
		if (lz_matches[i].length > 0)
		{
			uint32 tmp;
			bit_stream.GetBits(tmp, rec_no_bits);
			lz_matches[i].rec_no = tmp;

			length_bits = (uint32)MAX(0, MIN((int32)records[i].sequence_len - (int32)lz_matcher.GetMinMatchLen(), 255));
			if (length_bits)
			{
				length_bits = BitStream::BitLength(length_bits);
				bit_stream.GetBits(tmp, length_bits);
			}
			else
			{
				tmp = 0;
			}
			lz_matches[i].length = tmp + lz_matcher.GetMinMatchLen();

			if (offset_bits)
			{
				bit_stream.GetBits(tmp, offset_bits);
			}
			else
			{
				tmp = 0;
			}
			lz_matches[i].rec_offset = tmp;
		}
	}
	bit_stream.FlushInputWordBuffer();
}

// ********************************************************************************************
void Block::ReadDNAPlain(BitStream &bit_stream, LzMatcher &lz_matcher, std::vector<uchar> &symbols, bool try_lz, bool extracting)
{
	// Info about LZ matches
	lz_matches.resize(rec_count);
	
	for (uint32 i = 0; i < rec_count; ++i)
	{
		records[i].sequence_len = records[i].quality_len - no_of_amb[i];
	}

	if (try_lz)
	{
		ReadLzMatches(bit_stream, lz_matcher);

		for (uint32 i = 0; i < rec_count; ++i)
		{
			if (!extracting)
				DecodeLzMatches(lz_matcher, i);

			uint32 cur_sequence_len = records[i].sequence_len;
			uchar *cur_sequence = records[i].sequence;
			my_assert(lz_matches[i].length <= cur_sequence_len);
			for (uint32 j = lz_matches[i].length; j < cur_sequence_len; ++j)
			{
				uint32 tmp(0);	// remove warning...
				bit_stream.Get2Bits(tmp);
				cur_sequence[j] = symbols[tmp];
			}	
			cur_sequence[cur_sequence_len] = '\0';

			if (!extracting)
				DecodeLzMatches_Insert(lz_matcher, i);
		}
	}
	else
	{
		for (uint32 i = 0; i < rec_count; ++i)
		{
			lz_matches[i].length = 0;
			uint32 cur_sequence_len = records[i].sequence_len;
			uchar *cur_sequence = records[i].sequence;

			for (uint32 j = 0; j < cur_sequence_len; ++j)
			{
				uint32 tmp(0);			// reduce warning...
				bit_stream.Get2Bits(tmp);
				cur_sequence[j] = symbols[tmp];
			}	
			cur_sequence[cur_sequence_len] = '\0';
		}
	}

	bit_stream.FlushInputWordBuffer();
}

// ********************************************************************************************
void Block::ReadDNAHuf(BitStream &bit_stream, LzMatcher &lz_matcher, std::vector<uchar> &symbols, HuffmanEncoder *Huffman_sym, bool try_lz, bool extracting)
{
	// Info about LZ matches
	lz_matches.resize(rec_count);
	
	for (uint32 i = 0; i < rec_count; ++i)
	{
		records[i].sequence_len = records[i].quality_len - no_of_amb[i];
	}

	if (try_lz)
	{
		ReadLzMatches(bit_stream, lz_matcher);

		for (uint32 i = 0; i < rec_count; ++i)
		{
			if (!extracting)
				DecodeLzMatches(lz_matcher, i);

			uint32 cur_sequence_len = records[i].sequence_len;
			uchar *cur_sequence = records[i].sequence;
			for (uint32 j = lz_matches[i].length; j < cur_sequence_len; ++j)
			{
				// Symbols
				uint32 bit;
				bit_stream.GetBits(bit, Huffman_sym->GetMinLen());
				int32 h_tmp = Huffman_sym->DecodeFast(bit);
				while (h_tmp < 0)
				{
					bit_stream.GetBit(bit);
					h_tmp = Huffman_sym->Decode(bit);
				};

				cur_sequence[j] = symbols[h_tmp];
			}	
			cur_sequence[cur_sequence_len] = '\0';

			if (!extracting)
				DecodeLzMatches_Insert(lz_matcher, i);
		}
	}
	else
	{
		for (uint32 i = 0; i < rec_count; ++i)
		{
			lz_matches[i].length = 0;
			uint32 cur_sequence_len = records[i].sequence_len;
			uchar *cur_sequence = records[i].sequence;
			for (uint32 j = lz_matches[i].length; j < cur_sequence_len; ++j)
			{
				// Symbols
				uint32 bit;
				bit_stream.GetBits(bit, Huffman_sym->GetMinLen());
				int32 h_tmp = Huffman_sym->DecodeFast(bit);
				while (h_tmp < 0)
				{
					bit_stream.GetBit(bit);
					h_tmp = Huffman_sym->Decode(bit);
				};

				cur_sequence[j] = symbols[h_tmp];
			}	
			cur_sequence[cur_sequence_len] = '\0';
		}
	}
	bit_stream.FlushInputWordBuffer();
}

// ********************************************************************************************
void Block::FindLzMatches(LzMatcher &lz_matcher)
{
	lz_matches.resize(rec_count);

	for (uint32 i = 0; i < rec_count; ++i)
	{
		uint32 rec_no;
		uint32 rec_offset;
		uint32 match_len;
		FastqRecord& cur_rec = records[i];
		LzMatch& cur_lz = lz_matches[i];

		bool match_found = lz_matcher.FindMatch(cur_rec.sequence, cur_rec.sequence_len, cur_rec.quality, cur_rec.quality_len, 
			rec_no, rec_offset, match_len);

		if (match_found)
		{
			cur_lz.rec_no = rec_no;
			cur_lz.rec_offset = rec_offset;
			cur_lz.length = match_len;
			cur_rec.lz_inserted = false;
		}
		else
		{
			cur_lz.length = 0;
			cur_rec.lz_inserted = lz_matcher.InsertEncoding(b_start_rec_no+i, cur_rec.sequence, cur_rec.sequence_len, cur_rec.quality, cur_rec.quality_len);
		}
	}
}

// ********************************************************************************************
void Block::MakeRLE()
{
	uint32 tot_qua_len = 0;

	for (uint32 i = 0; i < rec_count; ++i)
	{
		tot_qua_len += records[i].quality_len;
	}

	qua_stream = new uchar[tot_qua_len];
	run_stream = new uchar[tot_qua_len];

	uchar prev = 0;
	uint32 run_len = 0;
	uint32 qua_idx = 0;
	uint32 run_idx = 0;

	for (uint32 i = 0; i < rec_count; ++i)
	{
//		run_len = 0;
		uchar *cur_quality = records[i].quality;
		for (uint32 j = 0; j < (const uint32)records[i].quality_len; ++j)
		{
			if (cur_quality[j] == prev && run_len < 254)
			{
				++run_len;
			}
			else
			{
				if (prev)
				{
					qua_stream[qua_idx++] = prev;
					run_stream[run_idx++] = (uchar) run_len;
				}

				run_len = 0;
				prev = cur_quality[j];
			}
		}
	}
	qua_stream[qua_idx++] = prev;
	run_stream[run_idx++] = (uchar) run_len;

	qua_stream_len = qua_idx;
	run_stream_len = run_idx;
}

// ********************************************************************************************
void Block::MakeUnRLE()
{
	uint32 tot_qua_len = 0;
	
	for (uint32 i = 0; i < rec_count; ++i)
	{
		tot_qua_len += records[i].quality_len;
	}

	uint32 run_len = 0;
	uchar qua = 0;
	uint32 qua_idx = 0;
	for (uint32 i = 0; i < rec_count; ++i)
	{
		no_of_amb[i] = 0;
		uchar *cur_quality = records[i].quality;
		for (uint32 j = 0; j < (const uint32)records[i].quality_len; ++j)
		{
			if (run_len == 0)
			{
				qua = qua_stream[qua_idx];
				run_len = run_stream[qua_idx]+1;
				qua_idx++;
			}
			cur_quality[j] = qua;
			--run_len;	
			if (qua >= 128)
			{
				no_of_amb[i]++;
			}
		}
	}
}

#if (D_COMPUTE_RECORDS_CRC_PER_BLOCK)

uint32 Block::ComputeRecordsCrc32()
{
	crc_hasher.Reset();
	for (uint32 i = 0; i < rec_count; ++i)
	{
		const FastqRecord& rec = records[i];
		crc_hasher.UpdateCrc(rec.title, rec.title_len);
		crc_hasher.UpdateCrc(rec.sequence, rec.sequence_len);
		crc_hasher.UpdateCrc(rec.plus, rec.plus_len);
		crc_hasher.UpdateCrc(rec.quality, rec.quality_len);
	}
	return crc_hasher.GetHash();
}

#endif