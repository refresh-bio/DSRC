/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/
#include "py_base.h"
#include "py_fastq.h"

namespace pydsrc
{

// ********************************************************************************************
bool PyFastqRecord::Import(const FastqRecord& rec)
{
	title.assign(rec.title, rec.title+rec.title_len);
	sequence.assign(rec.sequence, rec.sequence+rec.sequence_len);
	plus.assign(rec.plus, rec.plus+rec.plus_len);
	quality.assign(rec.quality, rec.quality+rec.quality_len);

	if (rec.sequence_breaks)
		sequence_breaks.assign(rec.sequence_breaks->begin(), rec.sequence_breaks->end());
	else if (sequence_breaks.size())
		sequence_breaks.clear();

	if (rec.quality_breaks)
		quality_breaks.assign(rec.quality_breaks->begin(), rec.quality_breaks->end());
	else if (quality_breaks.size())
		quality_breaks.clear();

	lz_inserted = rec.lz_inserted;
	rec_th_len = rec.rec_th_len;
	no_of_fields = rec.no_of_fields;

	return true;
}

// ********************************************************************************************
bool PyFastqRecord::Export(FastqRecord& rec) const
{
	// extract title/sequence/plus/quality data from python strings
	// TODO: find direct memory data-copy solution
	uint32 datalen = title.size();
	if (datalen+1 > rec.title_size)
	{
		my_assert(rec.title);
		delete[] rec.title;

		rec.title_len = datalen;
		rec.title_size = datalen;
		rec.title = new uchar[datalen+1];
	}
	else
	{
		rec.title_len = datalen;
	}
	std::copy(title.begin(), title.end(), rec.title);
	rec.title[datalen] = '\0';

	datalen = sequence.size();
	if (datalen+1 > rec.sequence_size)
	{
		my_assert(rec.sequence);
		delete[] rec.sequence;

		rec.sequence_len = datalen;
		rec.sequence_size = datalen;
		rec.sequence = new uchar[datalen+1];
	}
	else
	{
		rec.sequence_len = datalen;
	}
	std::copy(sequence.begin(), sequence.end(), rec.sequence);
	rec.sequence[datalen] = '\0';

	datalen = plus.size();
	if (datalen+1 > rec.plus_size)
	{
		my_assert(rec.plus);
		delete[] rec.plus;

		rec.plus_len = datalen;
		rec.plus_size = datalen;
		rec.plus = new uchar[datalen+1];
	}
	else
	{
		rec.plus_len = datalen;
	}
	std::copy(plus.begin(), plus.end(), rec.plus);
	rec.plus[datalen] = '\0';

	datalen = quality.size();
	if (datalen+1 > rec.quality_size)
	{
		my_assert(rec.quality);
		delete[] rec.quality;

		rec.quality_len = datalen;
		rec.quality_size = datalen;
		rec.quality = new uchar[datalen+1];
	}
	else
	{
		rec.quality_len = datalen;
	}
	std::copy(quality.begin(), quality.end(), rec.quality);
	rec.quality[datalen] = '\0';

	// extract sequence/qua line breaks from python lists
	if (sequence_breaks.size() > 0)
	{
		if (!rec.sequence_breaks)
			rec.sequence_breaks = new std::vector<int32>(sequence_breaks.size());
		else
			rec.sequence_breaks->clear();
		rec.sequence_breaks->assign(sequence_breaks.begin(), sequence_breaks.end());
	}
	else if (!rec.sequence_breaks)
	{
		delete rec.sequence_breaks;
		rec.sequence_breaks = NULL;
	}

	if (quality_breaks.size() > 0)
	{
		if (!rec.quality_breaks)
			rec.quality_breaks = new std::vector<int32>(quality_breaks.size());
		else
			rec.quality_breaks->clear();
		rec.quality_breaks->assign(quality_breaks.begin(), quality_breaks.end());
	}
	else if (!rec.quality_breaks)
	{
		delete rec.quality_breaks;
		rec.quality_breaks = NULL;
	}

	rec.lz_inserted = lz_inserted;
	rec.rec_th_len = rec_th_len;
	rec.no_of_fields = no_of_fields;

	return true;
}

} // pydsrc
