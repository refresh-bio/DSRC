/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/

#ifndef _MAIN_PY_H
#define _MAIN_PY_H

#include "py_compressor.h"

enum TaskSelect
{
	TASK_COMPRESS,
	TASK_DECOMPRESS,
	TASK_EXTRACT
};

union Param
{
	uint64 par64;
	uint32 par32;
};

// ********************************************************************************************
int main(int argc, char* argv[]);
void parse_params(int argc, char* argv[]);
void run_dsrc(int argc, char* argv[]);

void usage();

void Compress(const char* in_file_name, const char* out_file_name);
void Decompress(const char* in_file_name, const char* out_file_name);

#endif
