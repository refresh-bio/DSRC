/*
  This file is a part of DSRC software distributed under GNU GPL 2 licence.
  The homepage of the DSRC project is http://sun.aei.polsl.pl/dsrc
  
  Authors: Sebastian Deorowicz and Szymon Grabowski
  Contributions: Lucas Roguski
  
  Version: 1.00
*/

#include "defs.h"
#include "bit_stream.h"
#include <algorithm>
#include <stdio.h>


// ********************************************************************************************
BitStream::BitStream()
	:	IO_BUFFER_SIZE(0)
	,	file(NULL)
	,	file_pos(0)
	,	file_size(0)
	,	io_buffer(NULL)
	,	io_buffer_pos(0)
	,	io_buffer_size(0)
	,	word_buffer(0)
	,	word_buffer_pos(0)
	,	word_buffer_size(32)
	,	mode(FILE_MODE_NONE)
{
	for (int32 i = 0; i < 32; ++i)
	{
		n_bit_mask[i] = (1u << i) - 1;
	}
}

// ********************************************************************************************
BitStream::~BitStream()
{
	delete[] io_buffer;

	if (file)
		fclose(file);
}

// ********************************************************************************************
bool BitStream::WriteBuffer()
{
	my_assert(file != NULL);
	if ((int32)fwrite(io_buffer, 1, (size_t)io_buffer_pos, file) != io_buffer_pos)
		return false;

	io_buffer_pos = 0;
	return true;
}

// ********************************************************************************************
bool BitStream::ReadBuffer()
{
	my_assert(file != NULL);
	io_buffer_size = (int32) fread(io_buffer, 1, IO_BUFFER_SIZE, file);
	io_buffer_pos = 0;
	my_assert(io_buffer_size > 0);
	return io_buffer_size > 0;
}

// ********************************************************************************************
bool BitStream::Create(const char *file_name)
{
	if (file)
		fclose(file);
	if ((file = my_fopen(file_name, "wb")) != NULL)
		mode = FILE_MODE_WRITE;

	IO_BUFFER_SIZE = BitStream::DEFAULT_IO_BUFFER_SIZE_W;
	io_buffer = new uchar[IO_BUFFER_SIZE];
	io_buffer_size = IO_BUFFER_SIZE;

	word_buffer_size = 32;
	io_buffer_pos = 0;
	file_pos = 0;

	return mode == FILE_MODE_WRITE;	
}

// ********************************************************************************************
bool BitStream::Open(const char *file_name)
{
	if (file)
		fclose(file);
	if ((file = my_fopen(file_name, "rb")) != NULL)
		mode = FILE_MODE_READ;

	IO_BUFFER_SIZE = BitStream::DEFAULT_IO_BUFFER_SIZE_R;
	io_buffer = new uchar[IO_BUFFER_SIZE];
	io_buffer_size = IO_BUFFER_SIZE;

	word_buffer_size = 8;
	io_buffer_pos = IO_BUFFER_SIZE;
	file_pos = 0;

	if (mode == FILE_MODE_READ)
	{
		my_fseek(file, 0, SEEK_END);
		file_size = my_ftell(file);
		my_fseek(file, 0, SEEK_SET);
	} 
	
	return mode == FILE_MODE_READ;
}

// ********************************************************************************************
bool BitStream::OpenRA(const char *file_name)
{
	if (file)
		fclose(file);
	if ((file = my_fopen(file_name, "rb")) != NULL)
		mode = FILE_MODE_READ_RA;

	IO_BUFFER_SIZE = BitStream::DEFAULT_IO_BUFFER_SIZE_RA;
	io_buffer = new uchar[IO_BUFFER_SIZE];
	io_buffer_size = IO_BUFFER_SIZE;

	word_buffer_size = 8;
	io_buffer_pos = IO_BUFFER_SIZE;
	file_pos = 0;

	if (mode == FILE_MODE_READ_RA)
	{
		my_fseek(file, 0, SEEK_END);
		file_size = my_ftell(file);

		my_fseek(file, 0, SEEK_SET);
	} 
	
	return mode == FILE_MODE_READ_RA;
}

// ********************************************************************************************
bool BitStream::Close()
{
	if (!file)
		return true;

	if (mode == FILE_MODE_WRITE)
	{
		if (word_buffer_pos)
			FlushPartialWordBuffer();
		WriteBuffer();
	}

	fclose(file);
	file = NULL;
	mode = FILE_MODE_NONE;

	return true;
}

// ********************************************************************************************
bool BitStream::SetPos(uint64 pos)
{
	if (mode != FILE_MODE_READ && mode != FILE_MODE_READ_RA)
		return false;

	if (pos >= file_pos - io_buffer_pos && pos < file_pos - io_buffer_pos + io_buffer_size)
	{
		io_buffer_pos = (int32) (pos - (file_pos - io_buffer_pos));
	}
	else
	{
		if (my_fseek(file, pos, SEEK_SET) == EOF)
			return false;

		io_buffer_pos = IO_BUFFER_SIZE;
		file_pos = pos;
	}
	
	word_buffer_pos = 0;
	word_buffer = 0;

	return true;
}

