#include "main.h"
#include <dsrc.h>
#include <iostream>

int main(int argc, char** argv)
{
	compress_file();
	decompress_file();
	extract_records();

	return RET_OK;
}


int compress_file()
{
	const char* inFastqFiles[] = {"data/read1.fastq", "data/read2.fastq"};
	const char* outDsrcFiles[] = {"data/read1.dsrc", "data/read2.dsrc"};
	const char* outDsrcFileJoin = "data/readJ.dsrc";

	std::cout << "Example 1 : compression\n";
	// compress files using the easy method - Compressor object
	{
		Compressor compressor;

		// set additional parameters
		// eg. turn on on lz compression method and CRC32 checksum checking
		compressor.SetLzMatching(true);
		compressor.SetCrc32Checking(true);

		// compress files
		if (   !compressor.Compress(inFastqFiles[0], outDsrcFiles[0]) 
			|| !compressor.Compress(inFastqFiles[1], outDsrcFiles[1]))
		{
			return RET_ERR;
		}
	}

	// compress the files into one using DSRC module object
	//:IMPORTANT: reads need to be in the same format (SOLiD or LS454/SOLEXA)
	{
		DsrcFile dsrcFile;

		// check if files exists and open them for reading
		FastqFile fastqFiles[2];
		if (!fastqFiles[0].Open(inFastqFiles[0]))
		{
			std::cout << "Error opening input file: " << inFastqFiles[0] << "\n";
			return RET_ERR;
		}
		if (!fastqFiles[1].Open(inFastqFiles[1]))
		{
			fastqFiles[0].Close();

			std::cout << "Error opening input file: " << inFastqFiles[1] << "\n";
			return RET_ERR;
		}

		// set additional compression parameters
		// IMPORTANT: this is need to be done before starting compression
		dsrcFile.SetLzMatching(true);

		if (!dsrcFile.StartCompress(outDsrcFileJoin))
		{
			std::cout << "Error: cannot start compression\n";

			if (dsrcFile.IsError())
				std::cout << dsrcFile.GetError();

			fastqFiles[0].Close();
			fastqFiles[1].Close();

			return RET_ERR;
		}

		// read all records from files
		FastqRecord recordBuffer;
		while (fastqFiles[0].ReadNextRecord(recordBuffer))
			dsrcFile.WriteRecord(recordBuffer);

		fastqFiles[0].Close();
		while (fastqFiles[1].ReadNextRecord(recordBuffer))
			dsrcFile.WriteRecord(recordBuffer);

		dsrcFile.FinishCompress();
	}

	std::cout << "Success!\n";
	return RET_OK;
}

int decompress_file()
{
	const char* inDsrcFiles[] = {"data/read1.dsrc", "data/read2.dsrc"};
	const char* outFastqFiles[] = {"data/read1-out.fastq", "data/read2-out.fastq"};
	const char* outFastqFileJoin = "data/readJ.fastq";

	std::cout << "Example 2 : decompression\n";
	// decompress files using the easy method - Compressor object
	{
		Compressor compressor;

		// compress files
		if (   !compressor.Decompress(inDsrcFiles[1], outFastqFiles[1])
			|| !compressor.Decompress(inDsrcFiles[0], outFastqFiles[0]))
		{
			return RET_ERR;
		}
	}

	// decompress the files into one using DSRC module object
	{
		DsrcFile dsrcFile;

		// check if we can open DSRC file
		if (!dsrcFile.StartDecompress(inDsrcFiles[0]))
		{
			std::cout << "Error: cannot start decompression of file: " << inDsrcFiles[0] << "\n";

			if (dsrcFile.IsError())
				std::cout << dsrcFile.GetError();

			return RET_ERR;
		}

		// check if we can create out file
		FastqFile fastqFile;
		if (!fastqFile.Create(outFastqFileJoin))
		{
			std::cout << "Error creating output file: " << outFastqFileJoin << "\n";
			dsrcFile.FinishDecompress();
			return RET_ERR;
		}

		// read all records from file
		FastqRecord recordBuffer;
		while (dsrcFile.ReadNextRecord(recordBuffer))
			fastqFile.WriteRecord(recordBuffer);

		// finish decompression of the first file and start next
		dsrcFile.FinishDecompress();

		if (!dsrcFile.StartDecompress(inDsrcFiles[1]))
		{
			std::cout << "Error: cannot start decompression of file: " << inDsrcFiles[1] << "\n";

			if (dsrcFile.IsError())
				std::cout << dsrcFile.GetError();

			fastqFile.Close();

			return RET_ERR;
		}

		// read all records from file
		while (dsrcFile.ReadNextRecord(recordBuffer))
			fastqFile.WriteRecord(recordBuffer);

		dsrcFile.FinishDecompress();
		fastqFile.Close();
	}

	std::cout << "Success!\n";
	return RET_OK;
}

int extract_records()
{
	const char* inDsrcFiles[] = {"data/read1.dsrc", "data/read2.dsrc"};
	const char* outFastqFile = "data/read1-ext.fastq";

	const uint32 records_num = 10;
	std::vector<uint64> records;
	for (uint32 i = 0; i < records_num; ++i)
		records.push_back(i*1024);			// sample records' ids


	std::cout << "Example 3 : extraction\n";
	//  extract records using the easy method - Compressor object
	{
		Compressor compressor;
		compressor.ExtractRange(inDsrcFiles[1], outFastqFile, records);
	}


	// extract the records from two files and join them together
	{
		DsrcFile dsrcFile;

		// check if we can open DSRC file
		if (!dsrcFile.StartExtract(inDsrcFiles[1]))
		{
			std::cout << "Error: cannot start extraction of file: " << inDsrcFiles[0] << "\n";

			if (dsrcFile.IsError())
				std::cout << dsrcFile.GetError();
			return RET_ERR;
		}

		// check if we can create out file
		FastqFile fastqFile;
		if (!fastqFile.Create(outFastqFile))	// overwrites the original file
		{
			std::cout << "Error creating output file: " << outFastqFile << "\n";
			dsrcFile.FinishExtract();
			return RET_ERR;
		}

		// read all records from file
		FastqRecord recordBuffer;
		for (uint32 i = 0; i < records_num/2; ++i)
		{
			if (!dsrcFile.ExtractRecord(recordBuffer, records[i]))
				break;
			
			fastqFile.WriteRecord(recordBuffer);
		}

		// everything went fine?
		if (dsrcFile.IsError())
		{
			std::cout << "Error while extracting records...\n";
			std::cout << dsrcFile.GetError();
			dsrcFile.FinishExtract();
			fastqFile.Close();
			return RET_ERR;
		}

		// finish decompression of the first file and start next
		dsrcFile.FinishExtract();

		if (!dsrcFile.StartExtract(inDsrcFiles[1]))
		{
			std::cout << "Error: cannot start decompression of file: " << inDsrcFiles[1] << "\n";

			if (dsrcFile.IsError())
				std::cout << dsrcFile.GetError();

			fastqFile.Close();
			return RET_ERR;
		}

		// read all records from file
		for (uint32 i = records_num/2; i < records_num; ++i)
		{
			if (!dsrcFile.ExtractRecord(recordBuffer, records[i]))
				break;

			fastqFile.WriteRecord(recordBuffer);
		}

		dsrcFile.FinishExtract();
		fastqFile.Close();

		// everything went fine?
		if (dsrcFile.IsError())
		{
			std::cout << "Error while extracting records...\n";
			std::cout << dsrcFile.GetError();
			return RET_ERR;
		}
	}

	std::cout << "Success!\n";
	return RET_OK;
}

